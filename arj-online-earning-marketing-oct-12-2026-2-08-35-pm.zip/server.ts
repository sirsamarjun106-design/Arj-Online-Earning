import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { initializeApp, getApps } from 'firebase/app';
import {
  getFirestore,
  doc,
  setDoc
} from 'firebase/firestore';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Firebase Applet Configuration for Server-side Sync
let firestoreDb: any;
try {
  const appletConfig = JSON.parse(fs.readFileSync(path.join(__dirname, 'firebase-applet-config.json'), 'utf-8'));
  const fbApp = getApps().length > 0 ? getApps()[0] : initializeApp(appletConfig);
  firestoreDb = getFirestore(fbApp, appletConfig.firestoreDatabaseId);
} catch (e) {
  console.warn('Server Firestore sync initialization fallback:', e);
}

// Persistent Local Database Storage Directory
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'arj_database.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface LocalDB {
  tasks: Record<string, any>;
  task_submissions: Record<string, any>;
  wallets: Record<string, any>;
  transactions: Record<string, any>;
  referrals: Record<string, any>;
  withdrawals: Record<string, any>;
  spin_results: Record<string, any>;
  scratch_results: Record<string, any>;
  pending_scratch_cards: Record<string, any>;
  app_settings: Record<string, any>;
  check_ins: Record<string, any>;
}

// Canonical Default Tasks
const DEFAULT_CANONICAL_TASKS: Record<string, any> = {
  'task-1': {
    id: 'task-1',
    title: 'Welcome to ARJ Rewards! 🌟',
    description: 'Learn how to maximize your daily earnings with Spin & Watch.',
    category: 'story',
    rewardAmount: 10,
    watchDuration: 8,
    completionRequired: true,
    requiresAdminApproval: false,
    active: true,
    order: 1,
    mediaUrl: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=1080&q=80',
    mediaType: 'image',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=300&q=80',
    createdAt: Date.now()
  },
  'task-2': {
    id: 'task-2',
    title: 'Daily Spin Strategy 🎯',
    description: 'Claim up to 10 free spins daily and hit the ₹19 & ₹10 jackpot!',
    category: 'story',
    rewardAmount: 10,
    watchDuration: 8,
    completionRequired: true,
    requiresAdminApproval: false,
    active: true,
    order: 2,
    mediaUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=1080&q=80',
    mediaType: 'image',
    thumbnailUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=300&q=80',
    createdAt: Date.now()
  },
  'task-3': {
    id: 'task-3',
    title: 'Instant UPI Payouts ⚡',
    description: 'Withdraw your rewards directly to Google Pay, PhonePe, or Paytm.',
    category: 'story',
    rewardAmount: 10,
    watchDuration: 8,
    completionRequired: true,
    requiresAdminApproval: false,
    active: true,
    order: 3,
    mediaUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1080&q=80',
    mediaType: 'image',
    thumbnailUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=300&q=80',
    createdAt: Date.now()
  },
  'task-4': {
    id: 'task-4',
    title: 'Refer & Earn 👥',
    description: 'Invite your friends via WhatsApp and get ₹50 when they complete tasks.',
    category: 'story',
    rewardAmount: 10,
    watchDuration: 8,
    completionRequired: true,
    requiresAdminApproval: false,
    active: true,
    order: 4,
    mediaUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1080&q=80',
    mediaType: 'image',
    thumbnailUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=300&q=80',
    createdAt: Date.now()
  },
  'task-5': {
    id: 'task-5',
    title: 'KYC & Account Safety 🔒',
    description: 'Keep your account secure with government ID verification.',
    category: 'story',
    rewardAmount: 10,
    watchDuration: 8,
    completionRequired: true,
    requiresAdminApproval: false,
    active: true,
    order: 5,
    mediaUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1080&q=80',
    mediaType: 'image',
    thumbnailUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=300&q=80',
    createdAt: Date.now()
  }
};

// Also support legacy aliases like 'story-1', 'story-2', etc.
Object.keys(DEFAULT_CANONICAL_TASKS).forEach((k) => {
  const storyAlias = k.replace('task-', 'story-');
  DEFAULT_CANONICAL_TASKS[storyAlias] = { ...DEFAULT_CANONICAL_TASKS[k], id: storyAlias };
});

function loadLocalDB(): LocalDB {
  try {
    if (fs.existsSync(DB_FILE)) {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      // Ensure all collections exist
      return {
        tasks: parsed.tasks || { ...DEFAULT_CANONICAL_TASKS },
        task_submissions: parsed.task_submissions || {},
        wallets: parsed.wallets || {},
        transactions: parsed.transactions || {},
        referrals: parsed.referrals || {},
        withdrawals: parsed.withdrawals || {},
        spin_results: parsed.spin_results || {},
        scratch_results: parsed.scratch_results || {},
        pending_scratch_cards: parsed.pending_scratch_cards || {},
        check_ins: parsed.check_ins || {},
        app_settings: {
          appName: 'ARJ Online Earning Marketing',
          tagline: 'Earn • Watch • Refer • Rewards',
          minimumWithdrawal: 149,
          maximumWithdrawal: 100000,
          spinWheelEnabled: true,
          scratchCardsEnabled: true,
          dailySpinLimit: 10,
          dailyScratchLimit: 5,
          referralReward: 50,
          referralEligibility: 'first_task_completion',
          referrerRewardAmount: 50,
          refereeRewardAmount: 20,
          possibleSpinRewards: [1, 5, 8, 10, 12, 15, 17, 20],
          possibleScratchRewards: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
          dailyRewardBudget: 1500,
          totalRewardsCredited: 0,
          liveWithdrawalsDemoEnabled: true,
          updatedAt: Date.now(),
          ...(parsed.app_settings || {})
        }
      };
    }
  } catch (err) {
    console.error('Error reading local db file:', err);
  }

  const initial: LocalDB = {
    tasks: { ...DEFAULT_CANONICAL_TASKS },
    task_submissions: {},
    wallets: {},
    transactions: {},
    referrals: {},
    withdrawals: {},
    spin_results: {},
    scratch_results: {},
    pending_scratch_cards: {},
    check_ins: {},
    app_settings: {
      appName: 'ARJ Online Earning Marketing',
      tagline: 'Earn • Watch • Refer • Rewards',
      minimumWithdrawal: 149,
      maximumWithdrawal: 100000,
      spinWheelEnabled: true,
      scratchCardsEnabled: true,
      dailySpinLimit: 10,
      dailyScratchLimit: 5,
      referralReward: 50,
      referralEligibility: 'first_task_completion',
      referrerRewardAmount: 50,
      refereeRewardAmount: 20,
      possibleSpinRewards: [1, 5, 8, 10, 12, 15, 17, 20],
      possibleScratchRewards: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
      dailyRewardBudget: 1500,
      totalRewardsCredited: 0,
      liveWithdrawalsDemoEnabled: true,
      updatedAt: Date.now()
    }
  };
  saveLocalDB(initial);
  return initial;
}

function saveLocalDB(data: LocalDB) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving local db file:', err);
  }
}

// Memory database reference
let dbState = loadLocalDB();

// Helper: Format today key YYYY-MM-DD
function getTodayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// 7-Day Progressive Streak Bonus Rewards (₹1 to ₹10)
const DAILY_CHECKIN_REWARDS = [1, 2, 3, 4, 5, 7, 10];

function getDaysBetween(dateStr1: string, dateStr2: string): number {
  if (!dateStr1 || !dateStr2) return 999;
  const [y1, m1, d1] = dateStr1.split('-').map(Number);
  const [y2, m2, d2] = dateStr2.split('-').map(Number);
  const ut1 = Date.UTC(y1, m1 - 1, d1);
  const ut2 = Date.UTC(y2, m2 - 1, d2);
  const diffMs = ut2 - ut1;
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

async function startServer() {
  const app = express();
  const port = process.env.PORT || 3000;
  const isProduction = process.env.NODE_ENV === 'production';

  app.use(express.json());

  // ---------------------------------------------------------
  // 1. APP SETTINGS & CONFIGURATION
  // ---------------------------------------------------------
  app.get('/api/settings', (_req, res) => {
    res.json({ success: true, settings: dbState.app_settings });
  });

  app.post('/api/admin/settings', (req, res) => {
    try {
      const updates = req.body || {};
      dbState.app_settings = {
        ...dbState.app_settings,
        ...updates,
        updatedAt: Date.now()
      };
      saveLocalDB(dbState);
      res.json({ success: true, settings: dbState.app_settings });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error updating settings';
      res.status(500).json({ success: false, error: msg });
    }
  });

  // ---------------------------------------------------------
  // 2. TASK COMPLETION & REWARDS
  // ---------------------------------------------------------
  app.get('/api/tasks', (_req, res) => {
    const list = Object.values(dbState.tasks).filter((t: any) => t.active);
    list.sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
    res.json({ success: true, tasks: list });
  });

  app.post('/api/tasks/complete', async (req, res) => {
    try {
      const { uid, taskId, idempotencyKey } = req.body || {};

      if (!uid || typeof uid !== 'string' || !uid.trim()) {
        return res.status(400).json({ success: false, error: 'User UID is required and must be valid.' });
      }
      if (!taskId || typeof taskId !== 'string' || !taskId.trim()) {
        return res.status(400).json({ success: false, error: 'Task ID is required.' });
      }

      const cleanUid = uid.trim();
      const cleanTaskId = taskId.trim();
      const todayKey = getTodayKey();

      let task = dbState.tasks[cleanTaskId];
      if (!task) {
        const altId = cleanTaskId.startsWith('story-')
          ? cleanTaskId.replace('story-', 'task-')
          : cleanTaskId.replace('task-', 'story-');
        task = dbState.tasks[altId];
      }
      if (!task) task = DEFAULT_CANONICAL_TASKS[cleanTaskId];

      if (!task) {
        return res.status(404).json({ success: false, error: `Task '${cleanTaskId}' not found in database records.` });
      }

      if (!task.active) {
        return res.status(400).json({ success: false, error: 'This task is currently inactive or expired.' });
      }

      const submissionKey = `${cleanUid}_${cleanTaskId}_${todayKey}`;
      const existingSubmission = dbState.task_submissions[submissionKey];
      if (existingSubmission && existingSubmission.status === 'completed') {
        return res.status(409).json({
          success: false,
          error: 'You have already completed and claimed this task today!'
        });
      }

      if (idempotencyKey) {
        const existingTx = Object.values(dbState.transactions).find(
          (t: any) => t.idempotencyKey === idempotencyKey && t.status === 'completed'
        );
        if (existingTx) {
          return res.status(200).json({
            success: true,
            rewardAmount: existingTx.amount,
            message: `Reward already credited (Tx: ${existingTx.id}).`,
            wallet: dbState.wallets[cleanUid] || { availableBalance: existingTx.amount }
          });
        }
      }

      if (task.requiresAdminApproval) {
        const pendingSubmission = {
          id: submissionKey,
          taskId: cleanTaskId,
          uid: cleanUid,
          rewardAmount: Number(task.rewardAmount) || 10,
          status: 'pending',
          claimDate: todayKey,
          createdAt: Date.now(),
          requiresAdminApproval: true
        };
        dbState.task_submissions[submissionKey] = pendingSubmission;
        saveLocalDB(dbState);

        return res.json({
          success: true,
          pendingApproval: true,
          message: 'Task submitted for compliance verification. Reward will be added once approved.'
        });
      }

      const rewardAmount = Number(task.rewardAmount) || 10;
      const transactionId = `tx_task_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

      const existingWallet = dbState.wallets[cleanUid] || {
        uid: cleanUid,
        availableBalance: 0,
        pendingBalance: 0,
        totalEarnings: 0,
        taskEarnings: 0,
        spinEarnings: 0,
        scratchEarnings: 0,
        storyEarnings: 0,
        referralEarnings: 0,
        otherEarnings: 0,
        todayEarnings: 0,
        updatedAt: Date.now()
      };

      const newAvailable = Number(((existingWallet.availableBalance || 0) + rewardAmount).toFixed(2));
      const newTotal = Number(((existingWallet.totalEarnings || 0) + rewardAmount).toFixed(2));
      const newTaskEarnings = Number(((existingWallet.taskEarnings || existingWallet.storyEarnings || 0) + rewardAmount).toFixed(2));
      const newTodayEarnings = Number(((existingWallet.todayEarnings || 0) + rewardAmount).toFixed(2));

      const updatedWallet = {
        ...existingWallet,
        uid: cleanUid,
        availableBalance: newAvailable,
        totalEarnings: newTotal,
        taskEarnings: newTaskEarnings,
        storyEarnings: newTaskEarnings,
        todayEarnings: newTodayEarnings,
        updatedAt: Date.now()
      };
      dbState.wallets[cleanUid] = updatedWallet;

      const newTransaction = {
        id: transactionId,
        uid: cleanUid,
        amount: rewardAmount,
        type: 'credit',
        source: `Task Reward: ${task.title}`,
        status: 'completed',
        referenceId: cleanTaskId,
        idempotencyKey: idempotencyKey || submissionKey,
        timestamp: Date.now()
      };
      dbState.transactions[transactionId] = newTransaction;

      const newSubmission = {
        id: submissionKey,
        taskId: cleanTaskId,
        uid: cleanUid,
        rewardAmount: rewardAmount,
        status: 'completed',
        completedAt: Date.now(),
        claimDate: todayKey,
        transactionId: transactionId
      };
      dbState.task_submissions[submissionKey] = newSubmission;
      dbState.app_settings.totalRewardsCredited = (dbState.app_settings.totalRewardsCredited || 0) + rewardAmount;

      saveLocalDB(dbState);

      // Async sync to Firestore
      try {
        setDoc(doc(firestoreDb, 'wallets', cleanUid), updatedWallet, { merge: true }).catch(() => {});
        setDoc(doc(firestoreDb, 'transactions', transactionId), newTransaction).catch(() => {});
        setDoc(doc(firestoreDb, 'task_submissions', submissionKey), newSubmission).catch(() => {});
      } catch (_) {}

      return res.json({
        success: true,
        rewardAmount: rewardAmount,
        wallet: updatedWallet,
        transactionId: transactionId,
        message: `🎉 ₹${rewardAmount} credited to your wallet balance!`
      });
    } catch (err: unknown) {
      console.error('Server task completion error:', err);
      const msg = err instanceof Error ? err.message : 'Internal error processing task reward.';
      return res.status(500).json({ success: false, error: msg });
    }
  });

  // ---------------------------------------------------------
  // 3. SPIN WHEEL ENGINE (Rewards: ₹1, ₹5, ₹8, ₹10, ₹13, ₹15, ₹17, ₹19, ₹10)
  // ---------------------------------------------------------
  app.get('/api/spin/status/:uid', (req, res) => {
    const uid = req.params.uid;
    const today = getTodayKey();
    const userSpinsToday = Object.values(dbState.spin_results).filter(
      (s: any) => s.uid === uid && s.spinDate === today
    );
    const limit = dbState.app_settings.dailySpinLimit || 10;
    const remaining = Math.max(0, limit - userSpinsToday.length);
    res.json({
      success: true,
      enabled: dbState.app_settings.spinWheelEnabled !== false,
      dailyLimit: limit,
      spinsUsed: userSpinsToday.length,
      spinsRemaining: remaining,
      possibleRewards: dbState.app_settings.possibleSpinRewards || [1, 5, 8, 10, 13, 15, 17, 19, 10],
      history: userSpinsToday
    });
  });

  app.post('/api/spin/complete', (req, res) => {
    try {
      const { uid, rewardAmount, idempotencyKey } = req.body || {};
      if (!uid) {
        return res.status(400).json({ success: false, error: 'User UID is required.' });
      }

      if (dbState.app_settings.spinWheelEnabled === false) {
        return res.status(403).json({ success: false, error: 'Spin Wheel is currently disabled by administrator.' });
      }

      const cleanUid = uid.trim();
      const today = getTodayKey();

      // Check daily spin limit
      const userSpinsToday = Object.values(dbState.spin_results).filter(
        (s: any) => s.uid === cleanUid && s.spinDate === today
      );
      const spinLimit = dbState.app_settings.dailySpinLimit || 10;
      if (userSpinsToday.length >= spinLimit) {
        return res.status(400).json({ success: false, error: 'Daily spin limit reached! Please try again tomorrow.' });
      }

      const allowedPool = dbState.app_settings.possibleSpinRewards || [1, 5, 8, 10, 12, 15, 17, 20];
      const numReward = Number(rewardAmount);
      // Ensure reward is in authoritative pool
      const safeAmount = allowedPool.includes(numReward) ? numReward : allowedPool[Math.floor(Math.random() * allowedPool.length)];

      const spinId = `spin_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const spinTxId = `tx_spin_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

      const wallet = dbState.wallets[cleanUid] || {
        uid: cleanUid,
        availableBalance: 0,
        pendingBalance: 0,
        totalEarnings: 0,
        taskEarnings: 0,
        spinEarnings: 0,
        scratchEarnings: 0,
        storyEarnings: 0,
        referralEarnings: 0,
        otherEarnings: 0,
        todayEarnings: 0,
        updatedAt: Date.now()
      };

      wallet.availableBalance = Number(((wallet.availableBalance || 0) + safeAmount).toFixed(2));
      wallet.totalEarnings = Number(((wallet.totalEarnings || 0) + safeAmount).toFixed(2));
      wallet.spinEarnings = Number(((wallet.spinEarnings || 0) + safeAmount).toFixed(2));
      wallet.todayEarnings = Number(((wallet.todayEarnings || 0) + safeAmount).toFixed(2));
      wallet.updatedAt = Date.now();
      dbState.wallets[cleanUid] = wallet;

      const spinTx = {
        id: spinTxId,
        uid: cleanUid,
        amount: safeAmount,
        type: 'credit',
        source: 'Spin Wheel Reward',
        status: 'completed',
        referenceId: spinId,
        idempotencyKey,
        timestamp: Date.now()
      };
      dbState.transactions[spinTxId] = spinTx;

      const spinRecord = {
        id: spinId,
        uid: cleanUid,
        rewardAmount: safeAmount,
        spinDate: today,
        timestamp: Date.now(),
        transactionId: spinTxId,
        status: 'credited'
      };
      dbState.spin_results[spinId] = spinRecord;
      dbState.app_settings.totalRewardsCredited = (dbState.app_settings.totalRewardsCredited || 0) + safeAmount;

      saveLocalDB(dbState);

      // Async sync to Firestore
      try {
        setDoc(doc(firestoreDb, 'wallets', cleanUid), wallet, { merge: true }).catch(() => {});
        setDoc(doc(firestoreDb, 'transactions', spinTxId), spinTx).catch(() => {});
        setDoc(doc(firestoreDb, 'spin_results', spinId), spinRecord).catch(() => {});
      } catch (_) {}

      res.json({
        success: true,
        rewardAmount: safeAmount,
        wallet,
        transactionId: spinTxId,
        spinsRemaining: Math.max(0, spinLimit - (userSpinsToday.length + 1)),
        message: `Won ₹${safeAmount} from Spin Wheel!`
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Spin error';
      res.status(500).json({ success: false, error: msg });
    }
  });

  // ---------------------------------------------------------
  // 4. SCRATCH CARDS ENGINE (Rewards: ₹1 to ₹20 inclusive)
  // ---------------------------------------------------------
  app.get('/api/scratch/status/:uid', (req, res) => {
    const uid = req.params.uid;
    const today = getTodayKey();
    const userScratchesToday = Object.values(dbState.scratch_results).filter(
      (s: any) => s.uid === uid && s.scratchDate === today
    );
    const limit = dbState.app_settings.dailyScratchLimit || 5;
    const remaining = Math.max(0, limit - userScratchesToday.length);
    res.json({
      success: true,
      enabled: dbState.app_settings.scratchCardsEnabled !== false,
      dailyLimit: limit,
      scratchesUsed: userScratchesToday.length,
      scratchesRemaining: remaining,
      possibleRewards: dbState.app_settings.possibleScratchRewards || [1, 2, 3, 5, 8, 10, 12, 15, 18, 20],
      history: userScratchesToday
    });
  });

  // Request new scratch card (pre-selects authoritative reward on server)
  app.post('/api/scratch/card/generate', (req, res) => {
    try {
      const { uid } = req.body || {};
      if (!uid) return res.status(400).json({ success: false, error: 'User UID is required.' });

      if (dbState.app_settings.scratchCardsEnabled === false) {
        return res.status(403).json({ success: false, error: 'Scratch Cards are currently disabled by administrator.' });
      }

      const cleanUid = uid.trim();
      const today = getTodayKey();

      const userScratchesToday = Object.values(dbState.scratch_results).filter(
        (s: any) => s.uid === cleanUid && s.scratchDate === today
      );
      const scratchLimit = dbState.app_settings.dailyScratchLimit || 5;
      if (userScratchesToday.length >= scratchLimit) {
        return res.status(400).json({ success: false, error: 'Daily scratch card limit reached! Come back tomorrow.' });
      }

      // Secure random reward between ₹1 and ₹20 inclusive
      const pool = dbState.app_settings.possibleScratchRewards || [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
      const selectedReward = pool[Math.floor(Math.random() * pool.length)];

      const cardId = `sc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      dbState.pending_scratch_cards[cardId] = {
        id: cardId,
        uid: cleanUid,
        rewardAmount: selectedReward,
        status: 'unrevealed',
        createdAt: Date.now()
      };
      saveLocalDB(dbState);

      res.json({
        success: true,
        cardId,
        rewardAmount: selectedReward,
        scratchesRemaining: scratchLimit - userScratchesToday.length
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Scratch card generate error';
      res.status(500).json({ success: false, error: msg });
    }
  });

  // Claim scratch card reward once scratched >= 50%
  app.post('/api/scratch/card/claim', (req, res) => {
    try {
      const { uid, cardId, scratchPercentage, idempotencyKey } = req.body || {};
      if (!uid || !cardId) {
        return res.status(400).json({ success: false, error: 'Missing UID or cardId' });
      }

      const cleanUid = uid.trim();
      const card = dbState.pending_scratch_cards[cardId];
      if (!card) {
        return res.status(404).json({ success: false, error: 'Scratch card not found or expired.' });
      }

      if (card.uid !== cleanUid) {
        return res.status(403).json({ success: false, error: 'Unauthorized card session.' });
      }

      // Prevent duplicate claims
      if (card.status === 'claimed') {
        return res.status(409).json({ success: false, error: 'This card has already been claimed!' });
      }

      // Minimum scratch percentage condition
      const pct = Number(scratchPercentage) || 0;
      if (pct < 45) {
        return res.status(400).json({ success: false, error: 'Please scratch at least 50% of the card to reveal and claim your prize.' });
      }

      const rewardAmount = Number(card.rewardAmount) || 1;
      const today = getTodayKey();
      const txId = `tx_scratch_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

      // Update card status to claimed
      card.status = 'claimed';
      card.claimedAt = Date.now();

      // Atomically update user wallet
      const wallet = dbState.wallets[cleanUid] || {
        uid: cleanUid,
        availableBalance: 0,
        pendingBalance: 0,
        totalEarnings: 0,
        taskEarnings: 0,
        spinEarnings: 0,
        scratchEarnings: 0,
        storyEarnings: 0,
        referralEarnings: 0,
        otherEarnings: 0,
        todayEarnings: 0,
        updatedAt: Date.now()
      };

      wallet.availableBalance = Number(((wallet.availableBalance || 0) + rewardAmount).toFixed(2));
      wallet.totalEarnings = Number(((wallet.totalEarnings || 0) + rewardAmount).toFixed(2));
      wallet.scratchEarnings = Number(((wallet.scratchEarnings || 0) + rewardAmount).toFixed(2));
      wallet.todayEarnings = Number(((wallet.todayEarnings || 0) + rewardAmount).toFixed(2));
      wallet.updatedAt = Date.now();
      dbState.wallets[cleanUid] = wallet;

      // Record in transactions ledger
      const tx = {
        id: txId,
        uid: cleanUid,
        amount: rewardAmount,
        type: 'credit',
        source: 'Scratch Card Reward',
        status: 'completed',
        referenceId: cardId,
        idempotencyKey,
        timestamp: Date.now()
      };
      dbState.transactions[txId] = tx;

      // Record in scratch_results
      dbState.scratch_results[cardId] = {
        id: cardId,
        uid: cleanUid,
        rewardAmount,
        scratchDate: today,
        timestamp: Date.now(),
        transactionId: txId,
        status: 'credited'
      };
      dbState.app_settings.totalRewardsCredited = (dbState.app_settings.totalRewardsCredited || 0) + rewardAmount;

      saveLocalDB(dbState);

      // Async sync to Firestore
      try {
        setDoc(doc(firestoreDb, 'wallets', cleanUid), wallet, { merge: true }).catch(() => {});
        setDoc(doc(firestoreDb, 'transactions', txId), tx).catch(() => {});
        setDoc(doc(firestoreDb, 'scratch_results', cardId), dbState.scratch_results[cardId]).catch(() => {});
      } catch (_) {}

      res.json({
        success: true,
        rewardAmount,
        wallet,
        transactionId: txId,
        message: `🎉 Won ₹${rewardAmount} from Scratch Card!`
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Claim error';
      res.status(500).json({ success: false, error: msg });
    }
  });

  // ---------------------------------------------------------
  // 5. USER WALLET & TRANSACTIONS
  // ---------------------------------------------------------
  app.get('/api/wallet/:uid', (req, res) => {
    const uid = req.params.uid;
    const wallet = dbState.wallets[uid] || {
      uid,
      availableBalance: 0,
      pendingBalance: 0,
      totalEarnings: 0,
      taskEarnings: 0,
      spinEarnings: 0,
      scratchEarnings: 0,
      storyEarnings: 0,
      referralEarnings: 0,
      otherEarnings: 0,
      todayEarnings: 0,
      updatedAt: Date.now()
    };
    res.json({ success: true, wallet });
  });

  app.get('/api/transactions/:uid', (req, res) => {
    const uid = req.params.uid;
    const list = Object.values(dbState.transactions).filter((t: any) => t.uid === uid);
    list.sort((a: any, b: any) => b.timestamp - a.timestamp);
    res.json({ success: true, transactions: list });
  });

  app.get('/api/task-submissions/:uid', (req, res) => {
    const uid = req.params.uid;
    const today = getTodayKey();
    const claims = Object.values(dbState.task_submissions)
      .filter((s: any) => s.uid === uid && s.claimDate === today && s.status === 'completed')
      .map((s: any) => s.taskId);
    res.json({ success: true, claimedTaskIds: claims });
  });

  // ---------------------------------------------------------
  // 6. REFERRALS & WITHDRAWALS
  // ---------------------------------------------------------
  app.post('/api/referrals/register', (req, res) => {
    const { referrerUid, referrerCode, referredUid, referredName } = req.body || {};
    if (!referredUid) return res.status(400).json({ error: 'Missing referredUid' });

    if (referrerUid === referredUid) {
      return res.status(400).json({ error: 'Self-referral is strictly prohibited.' });
    }

    const refId = `ref_${referredUid}`;
    dbState.referrals[refId] = {
      id: refId,
      referrerUid,
      referrerCode,
      referredUid,
      referredName: referredName || 'New User',
      rewardAmount: dbState.app_settings.referralReward || 50,
      status: 'pending',
      createdAt: Date.now()
    };
    saveLocalDB(dbState);
    res.json({ success: true });
  });

  app.get('/api/referrals/:uid', (req, res) => {
    const uid = req.params.uid;
    const userRefs = Object.values(dbState.referrals).filter(
      (r: any) => r.referrerUid === uid || r.referrerCode === req.query.code
    );
    const totalCount = userRefs.length;
    const eligibleCount = userRefs.filter((r: any) => r.status === 'credited').length;
    const pendingCount = userRefs.filter((r: any) => r.status === 'pending').length;
    const earnings = userRefs
      .filter((r: any) => r.status === 'credited')
      .reduce((sum: number, r: any) => sum + (r.rewardAmount || 50), 0);

    res.json({
      success: true,
      stats: {
        totalCount,
        eligibleCount,
        pendingCount,
        earnings,
        referrals: userRefs
      }
    });
  });

  // ---------------------------------------------------------
  // 6. DAILY CHECK-IN & CONSECUTIVE STREAK ENGINE
  // ---------------------------------------------------------
  app.get('/api/checkin/status/:uid', (req, res) => {
    const uid = req.params.uid;
    const today = getTodayKey();
    const record = (dbState.check_ins && dbState.check_ins[uid]) || {
      uid,
      streak: 0,
      lastCheckInDate: null,
      totalCheckIns: 0,
      totalRewardsEarned: 0,
      history: []
    };

    const lastDate = record.lastCheckInDate;
    let canCheckInToday = true;
    let currentStreak = record.streak || 0;
    let todayRewardAmount = DAILY_CHECKIN_REWARDS[0];
    let nextStreakDay = 1;

    if (lastDate === today) {
      canCheckInToday = false;
      currentStreak = record.streak || 1;
      const cycleDay = ((currentStreak - 1) % 7) + 1;
      todayRewardAmount = DAILY_CHECKIN_REWARDS[cycleDay - 1];
      nextStreakDay = (currentStreak % 7) + 1;
    } else if (lastDate) {
      const diff = getDaysBetween(lastDate, today);
      if (diff === 1) {
        // Consecutive streak is alive
        const nextStreak = currentStreak + 1;
        nextStreakDay = ((nextStreak - 1) % 7) + 1;
        todayRewardAmount = DAILY_CHECKIN_REWARDS[nextStreakDay - 1];
      } else {
        // Streak missed/broken -> reset to Day 1
        currentStreak = 0;
        nextStreakDay = 1;
        todayRewardAmount = DAILY_CHECKIN_REWARDS[0];
      }
    }

    res.json({
      success: true,
      streak: currentStreak,
      lastCheckInDate: lastDate,
      canCheckInToday,
      todayRewardAmount,
      nextStreakDay,
      totalCheckIns: record.totalCheckIns || 0,
      streakRewards: DAILY_CHECKIN_REWARDS,
      history: record.history || []
    });
  });

  app.post('/api/checkin/claim', (req, res) => {
    try {
      const { uid } = req.body || {};
      if (!uid) {
        return res.status(400).json({ success: false, error: 'Missing user ID' });
      }

      if (!dbState.check_ins) {
        dbState.check_ins = {};
      }

      const today = getTodayKey();
      const record = dbState.check_ins[uid] || {
        uid,
        streak: 0,
        lastCheckInDate: null,
        totalCheckIns: 0,
        totalRewardsEarned: 0,
        history: []
      };

      if (record.lastCheckInDate === today) {
        return res.status(400).json({
          success: false,
          error: 'You have already checked in today! Come back tomorrow for your next streak bonus.'
        });
      }

      let newStreak = 1;
      if (record.lastCheckInDate) {
        const diff = getDaysBetween(record.lastCheckInDate, today);
        if (diff === 1) {
          newStreak = (record.streak || 0) + 1;
        } else {
          newStreak = 1;
        }
      }

      const cycleDay = ((newStreak - 1) % 7) + 1;
      const rewardAmount = DAILY_CHECKIN_REWARDS[cycleDay - 1];

      // Update check-in record
      record.streak = newStreak;
      record.lastCheckInDate = today;
      record.totalCheckIns = (record.totalCheckIns || 0) + 1;
      record.totalRewardsEarned = Number(((record.totalRewardsEarned || 0) + rewardAmount).toFixed(2));
      record.updatedAt = Date.now();

      if (!Array.isArray(record.history)) {
        record.history = [];
      }
      record.history.unshift({
        date: today,
        streakDay: cycleDay,
        streakCount: newStreak,
        rewardAmount,
        timestamp: Date.now()
      });
      if (record.history.length > 30) {
        record.history = record.history.slice(0, 30);
      }
      dbState.check_ins[uid] = record;

      // Update user wallet
      const wallet = dbState.wallets[uid] || {
        uid,
        availableBalance: 0,
        pendingBalance: 0,
        totalEarnings: 0,
        taskEarnings: 0,
        spinEarnings: 0,
        scratchEarnings: 0,
        storyEarnings: 0,
        referralEarnings: 0,
        otherEarnings: 0,
        todayEarnings: 0,
        updatedAt: Date.now()
      };

      wallet.availableBalance = Number(((wallet.availableBalance || 0) + rewardAmount).toFixed(2));
      wallet.totalEarnings = Number(((wallet.totalEarnings || 0) + rewardAmount).toFixed(2));
      wallet.todayEarnings = Number(((wallet.todayEarnings || 0) + rewardAmount).toFixed(2));
      wallet.otherEarnings = Number(((wallet.otherEarnings || 0) + rewardAmount).toFixed(2));
      wallet.updatedAt = Date.now();
      dbState.wallets[uid] = wallet;

      // Record transaction
      const txId = `tx_checkin_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const txRecord = {
        id: txId,
        uid,
        amount: rewardAmount,
        type: 'credit',
        source: `Daily Check-in Bonus (Day ${cycleDay})`,
        status: 'completed',
        referenceId: `checkin_${today}`,
        idempotencyKey: `checkin_${uid}_${today}`,
        timestamp: Date.now()
      };
      dbState.transactions[txId] = txRecord;
      dbState.app_settings.totalRewardsCredited = (dbState.app_settings.totalRewardsCredited || 0) + rewardAmount;

      saveLocalDB(dbState);

      // Async sync to Firestore
      try {
        setDoc(doc(firestoreDb, 'wallets', uid), wallet, { merge: true }).catch(() => {});
        setDoc(doc(firestoreDb, 'transactions', txId), txRecord).catch(() => {});
        setDoc(doc(firestoreDb, 'check_ins', uid), record, { merge: true }).catch(() => {});
      } catch (_) {}

      res.json({
        success: true,
        rewardAmount,
        newStreak,
        streakDay: cycleDay,
        wallet,
        message: `🎉 Checked in for Day ${cycleDay}! Earned ₹${rewardAmount} streak bonus.`
      });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Check-in error';
      res.status(500).json({ success: false, error: msg });
    }
  });

  app.post('/api/withdrawals/request', (req, res) => {
    const { uid, amount, upiId, userName, userPhone } = req.body || {};
    if (!uid || !amount || !upiId) {
      return res.status(400).json({ success: false, error: 'Missing parameters' });
    }

    const wallet = dbState.wallets[uid] || { availableBalance: 0, pendingBalance: 0 };
    const numAmount = Number(amount);
    if (wallet.availableBalance < numAmount) {
      return res.status(400).json({ success: false, error: 'Insufficient available balance' });
    }

    wallet.availableBalance = Number((wallet.availableBalance - numAmount).toFixed(2));
    wallet.pendingBalance = Number(((wallet.pendingBalance || 0) + numAmount).toFixed(2));
    wallet.updatedAt = Date.now();
    dbState.wallets[uid] = wallet;

    const wdId = `wd_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const wdRequest = {
      id: wdId,
      uid,
      userName: userName || 'ARJ Member',
      userPhone: userPhone || '',
      amount: numAmount,
      payoutMethod: 'UPI',
      payoutDetails: { upiId },
      status: 'pending',
      createdAt: Date.now()
    };
    dbState.withdrawals[wdId] = wdRequest;

    const txId = wdId;
    dbState.transactions[txId] = {
      id: txId,
      uid,
      amount: numAmount,
      type: 'withdrawal',
      source: `UPI Payout (${upiId})`,
      status: 'pending',
      referenceId: wdId,
      timestamp: Date.now()
    };

    saveLocalDB(dbState);
    res.json({ success: true, message: 'Withdrawal submitted successfully!', withdrawalId: wdId, wallet });
  });

  // Admin Overview API
  app.get('/api/admin/overview', (_req, res) => {
    const totalRewards = dbState.app_settings.totalRewardsCredited || 0;
    const spinsCount = Object.keys(dbState.spin_results).length;
    const scratchCount = Object.keys(dbState.scratch_results).length;
    const tasksCount = Object.keys(dbState.task_submissions).length;
    const withdrawals = Object.values(dbState.withdrawals);
    const pendingWithdrawalsCount = withdrawals.filter((w: any) => w.status === 'pending').length;
    const paidWithdrawalsCount = withdrawals.filter((w: any) => w.status === 'paid').length;

    res.json({
      success: true,
      stats: {
        totalRewardsCredited: totalRewards,
        spinsCount,
        scratchCount,
        tasksCount,
        pendingWithdrawalsCount,
        paidWithdrawalsCount,
        settings: dbState.app_settings
      }
    });
  });

  // Admin Settings Update API
  app.post('/api/admin/settings', (req, res) => {
    try {
      const settings = req.body || {};
      dbState.app_settings = {
        ...dbState.app_settings,
        ...settings,
        updatedAt: Date.now()
      };
      saveLocalDB(dbState);
      try {
        setDoc(doc(firestoreDb, 'app_settings', 'config'), dbState.app_settings, { merge: true }).catch(() => {});
      } catch (_) {}
      res.json({ success: true, settings: dbState.app_settings });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error updating settings';
      res.status(500).json({ success: false, error: msg });
    }
  });

  // ZapUPI Webhook Receiver
  app.post('/api/payment/webhook', (req, res) => {
    const { order_id, status, txn_id, amount, utr, environment } = req.body || {};
    console.log(`[ZapUPI Webhook] Order: ${order_id}, Status: ${status}, Txn: ${txn_id}, Amount: ${amount}, UTR: ${utr}, Env: ${environment}`);
    res.json({ status: 'ok' });
  });

  // ZapUPI Server-Side Order Proxy
  app.post('/api/payment/create-order', async (req, res) => {
    try {
      const { zap_key, order_id, amount, customer_mobile, remark, webhook_url } = req.body || {};
      const key = zap_key || process.env.ZAP_KEY || 'zap64b8e6c0bbd16e5965a3ad714395863a';
      if (!key) {
        return res.status(400).json({ status: 'error', message: 'Missing Zap key' });
      }

      const response = await fetch('https://pay.zapupi.com/api/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          zap_key: key,
          order_id,
          amount,
          customer_mobile,
          remark,
          webhook_url
        })
      });

      const data = await response.json();
      return res.json(data);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Internal error';
      return res.status(500).json({ status: 'error', message: msg });
    }
  });

  // Server health endpoint
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'ARJ Online Earning Backend',
      tasksCount: Object.keys(dbState.tasks).length,
      spinsCount: Object.keys(dbState.spin_results).length,
      scratchesCount: Object.keys(dbState.scratch_results).length,
      time: Date.now()
    });
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`ARJ Server running on port ${port} (${isProduction ? 'production' : 'development'})`);
  });
}

startServer();
