import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  getFirestore,
  Firestore
} from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import appletConfig from '../../firebase-applet-config.json';

// User's Firebase Authentication Configuration (arjmlm-4a25c with Email/Password enabled)
export const arjAuthConfig = {
  apiKey: "AIzaSyDzqz-5yeej3xb-6JEzwQVdzma3Hmuwvh8",
  authDomain: "arjmlm-4a25c.firebaseapp.com",
  projectId: "arjmlm-4a25c",
  storageBucket: "arjmlm-4a25c.firebasestorage.app",
  messagingSenderId: "180651582742",
  appId: "1:180651582742:web:b89a8f5206399a552b5c37"
};

// 1. Initialize Firebase App for Authentication
const authApp = getApps().find((a) => a.name === 'authApp') || initializeApp(arjAuthConfig, 'authApp');
export const auth = getAuth(authApp);

// 2. Initialize Firebase App for Cloud Firestore (ai-studio-arjonlineearning-1b1f882f-6c2b-4d7e-9070-052e05d04940)
const defaultApp = getApps().find((a) => a.name === '[DEFAULT]') || initializeApp(appletConfig);

let dbInstance: Firestore;
try {
  dbInstance = initializeFirestore(
    defaultApp,
    {
      localCache: persistentLocalCache({
        tabManager: persistentMultipleTabManager()
      }),
      experimentalAutoDetectLongPolling: true
    },
    appletConfig.firestoreDatabaseId
  );
} catch {
  dbInstance = getFirestore(defaultApp, appletConfig.firestoreDatabaseId);
}

export const db = dbInstance;
export const storage = getStorage(defaultApp);

export default defaultApp;
