import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  addDoc,
  getDocs,
  runTransaction,
  limit
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import {
  UserProfile,
  UserWallet,
  WalletTransaction,
  TaskItem,
  TaskClaim,
  SpinResult,
  WithdrawalRequest,
  KycRecord,
  PaymentSettingsConfig,
  AppSettingsConfig,
  AppNotification,
  SupportTicket,
  ReferralRecord,
  LiveWithdrawalItem,
  CheckInStatus,
  CheckInClaimResult
} from '../types';

export const ADMIN_EMAILS = ['arjvlog09@gmail.com'];

export const DEFAULT_APP_SETTINGS: AppSettingsConfig = {
  appName: 'ARJ Online Earning Marketing',
  tagline: 'Earn • Watch • Refer • Rewards',
  minimumWithdrawal: 149,
  maximumWithdrawal: 100000,
  spinWheelEnabled: true,
  scratchCardsEnabled: true,
  dailySpinLimit: 10,
  dailyScratchLimit: 5,
  referralReward: 50,
  referralEligibility: 'first_task_completion',
  referrerRewardAmount: 50,
  refereeRewardAmount: 20,
  possibleSpinRewards: [1, 5, 8, 10, 12, 15, 17, 20], // Exactly 8 sectors
  possibleScratchRewards: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
  dailyRewardBudget: 1500,
  totalRewardsCredited: 0,
  supportEmail: 'support@arjonline.com',
  supportWhatsApp: '+919876543210',
  liveWithdrawalsDemoEnabled: true,
  updatedAt: Date.now()
};

export const DEFAULT_PAYMENT_SETTINGS: PaymentSettingsConfig = {
  paymentEnabled: true,
  feeAmount: 99,
  paymentLink: '',
  paymentDescription: 'One-time KYC identity verification and account activation fee required to enable secure UPI withdrawals.',
  refundPolicy: 'Full refund is eligible within 7 business days if KYC verification cannot be processed by our compliance team.',
  withdrawalConditions: 'Requires approved KYC, minimum balance of ₹149, and verified UPI ID.',
  zapKey: 'zap64b8e6c0bbd16e5965a3ad714395863a',
  upiId: 'arjonline@upi',
  updatedAt: Date.now()
};

export const DEFAULT_SAMPLE_STORIES: TaskItem[] = [
  {
    id: 'task-1',
    title: 'Welcome to ARJ Rewards! 🌟',
    description: 'Learn how to maximize your daily earnings with Spin & Watch.',
    category: 'story',
    mediaUrl: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=1080&q=80',
    mediaType: 'image',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=300&q=80',
    rewardAmount: 10,
    watchDuration: 8,
    completionRequired: true,
    active: true,
    order: 1,
    createdAt: Date.now()
  },
  {
    id: 'task-2',
    title: 'Daily Spin Strategy 🎯',
    description: 'Claim up to 10 free spins daily and hit the ₹20 jackpot!',
    category: 'story',
    mediaUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=1080&q=80',
    mediaType: 'image',
    thumbnailUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=300&q=80',
    rewardAmount: 10,
    watchDuration: 8,
    completionRequired: true,
    active: true,
    order: 2,
    createdAt: Date.now()
  },
  {
    id: 'task-3',
    title: 'Instant UPI Payouts ⚡',
    description: 'Withdraw your rewards directly to Google Pay, PhonePe, or Paytm.',
    category: 'story',
    mediaUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1080&q=80',
    mediaType: 'image',
    thumbnailUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=300&q=80',
    rewardAmount: 10,
    watchDuration: 8,
    completionRequired: true,
    active: true,
    order: 3,
    createdAt: Date.now()
  },
  {
    id: 'task-4',
    title: 'Refer & Earn 👥',
    description: 'Invite your friends via WhatsApp and get ₹50 when they complete tasks.',
    category: 'story',
    mediaUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1080&q=80',
    mediaType: 'image',
    thumbnailUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=300&q=80',
    rewardAmount: 10,
    watchDuration: 8,
    completionRequired: true,
    active: true,
    order: 4,
    createdAt: Date.now()
  },
  {
    id: 'task-5',
    title: 'KYC & Account Safety 🔒',
    description: 'Keep your account secure with government ID verification.',
    category: 'story',
    mediaUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1080&q=80',
    mediaType: 'image',
    thumbnailUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=300&q=80',
    rewardAmount: 10,
    watchDuration: 8,
    completionRequired: true,
    active: true,
    order: 5,
    createdAt: Date.now()
  }
];

export const getTodayKey = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

// Listeners map for active wallet updates
const walletListeners = new Map<string, Set<(w: UserWallet) => void>>();

export function notifyWalletUpdated(uid: string, wallet: UserWallet) {
  const listeners = walletListeners.get(uid);
  if (listeners) {
    listeners.forEach((fn) => fn(wallet));
  }
}

/**
 * Initialize / fetch user profile
 */
export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const userDoc = await getDoc(doc(db, 'users', uid));
    if (userDoc.exists()) {
      return userDoc.data() as UserProfile;
    }
    return null;
  } catch (err) {
    console.warn('Error fetching user profile:', err);
    return null;
  }
}

/**
 * Initialize new user profile & wallet upon register
 */
export async function initializeNewUser(
  uid: string,
  data: {
    name: string;
    email: string;
    phone: string;
    referralCode: string;
    referredBy?: string | null;
  }
): Promise<{ profile: UserProfile; wallet: UserWallet }> {
  const isAdmin = ADMIN_EMAILS.includes(data.email.toLowerCase().trim());

  const profile: UserProfile = {
    uid,
    name: data.name,
    email: data.email,
    phone: data.phone,
    referralCode: data.referralCode,
    referredBy: data.referredBy || null,
    createdAt: Date.now(),
    kycStatus: 'unverified',
    accountStatus: 'active',
    role: isAdmin ? 'admin' : 'user',
    feePaid: false,
    tasksCompletedCount: 0
  };

  const wallet: UserWallet = {
    uid,
    availableBalance: 0,
    pendingBalance: 0,
    totalEarnings: 0,
    taskEarnings: 0,
    spinEarnings: 0,
    scratchEarnings: 0,
    storyEarnings: 0,
    referralEarnings: 0,
    otherEarnings: 0,
    updatedAt: Date.now()
  };

  try {
    await setDoc(doc(db, 'users', uid), profile);
    await setDoc(doc(db, 'wallets', uid), wallet);

    // If referred by someone, record referral record and notify backend
    if (data.referredBy && data.referredBy.trim() !== '') {
      const cleanRefCode = data.referredBy.trim().toUpperCase();

      if (cleanRefCode !== data.referralCode) {
        const q = query(collection(db, 'users'), where('referralCode', '==', cleanRefCode));
        const querySnap = await getDocs(q);

        if (!querySnap.empty) {
          const referrerDoc = querySnap.docs[0];
          const referrerUid = referrerDoc.id;

          if (referrerUid !== uid) {
            // Also notify backend API
            fetch('/api/referrals/register', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                referrerUid,
                referrerCode: cleanRefCode,
                referredUid: uid,
                referredName: data.name
              })
            }).catch(() => {});

            const refDocRef = doc(collection(db, 'referrals'));
            await setDoc(refDocRef, {
              id: refDocRef.id,
              referrerUid,
              referrerCode: cleanRefCode,
              referredUid: uid,
              referredName: data.name,
              rewardAmount: 50,
              status: 'pending',
              createdAt: Date.now()
            });
          }
        }
      }
    }

    // Welcome Notification
    await addDoc(collection(db, 'notifications'), {
      uid,
      title: 'Welcome to ARJ Online! 🎉',
      message: 'Start completing daily tasks and spinning the wheel to earn real rewards.',
      category: 'Announcements',
      read: false,
      createdAt: Date.now()
    });
  } catch (err) {
    console.warn('Initialization notice:', err);
  }

  notifyWalletUpdated(uid, wallet);
  return { profile, wallet };
}

/**
 * Subscribe to real-time wallet updates (combines server API and Firestore)
 */
export function subscribeUserWallet(uid: string, callback: (wallet: UserWallet) => void): () => void {
  if (!walletListeners.has(uid)) {
    walletListeners.set(uid, new Set());
  }
  walletListeners.get(uid)!.add(callback);

  // 1. Initial fetch from authoritative backend API
  fetch(`/api/wallet/${uid}`)
    .then((r) => r.json())
    .then((data) => {
      if (data.success && data.wallet) {
        callback({
          uid,
          availableBalance: Number((data.wallet.availableBalance ?? 0).toFixed(2)),
          pendingBalance: Number((data.wallet.pendingBalance ?? 0).toFixed(2)),
          totalEarnings: Number((data.wallet.totalEarnings ?? 0).toFixed(2)),
          taskEarnings: Number((data.wallet.taskEarnings ?? data.wallet.storyEarnings ?? 0).toFixed(2)),
          spinEarnings: Number((data.wallet.spinEarnings ?? 0).toFixed(2)),
          scratchEarnings: Number((data.wallet.scratchEarnings ?? 0).toFixed(2)),
          storyEarnings: Number((data.wallet.storyEarnings ?? 0).toFixed(2)),
          referralEarnings: Number((data.wallet.referralEarnings ?? 0).toFixed(2)),
          otherEarnings: Number((data.wallet.otherEarnings ?? 0).toFixed(2)),
          updatedAt: data.wallet.updatedAt ?? Date.now()
        });
      }
    })
    .catch(() => {});

  // 2. Also subscribe to Firestore
  const walletRef = doc(db, 'wallets', uid);
  const unsubFirestore = onSnapshot(
    walletRef,
    (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        callback({
          uid,
          availableBalance: Number((data.availableBalance ?? 0).toFixed(2)),
          pendingBalance: Number((data.pendingBalance ?? 0).toFixed(2)),
          totalEarnings: Number((data.totalEarnings ?? 0).toFixed(2)),
          taskEarnings: Number((data.taskEarnings ?? data.storyEarnings ?? 0).toFixed(2)),
          spinEarnings: Number((data.spinEarnings ?? 0).toFixed(2)),
          scratchEarnings: Number((data.scratchEarnings ?? 0).toFixed(2)),
          storyEarnings: Number((data.storyEarnings ?? 0).toFixed(2)),
          referralEarnings: Number((data.referralEarnings ?? 0).toFixed(2)),
          otherEarnings: Number((data.otherEarnings ?? 0).toFixed(2)),
          updatedAt: data.updatedAt ?? Date.now()
        });
      }
    },
    (err) => {
      console.warn('Wallet subscription warning:', err);
    }
  );

  return () => {
    walletListeners.get(uid)?.delete(callback);
    unsubFirestore();
  };
}

/**
 * Subscribe to real-time App Settings
 */
export function subscribeAppSettings(callback: (settings: AppSettingsConfig) => void): () => void {
  const configRef = doc(db, 'app_settings', 'config');
  return onSnapshot(
    configRef,
    (snapshot) => {
      if (snapshot.exists()) {
        callback({ ...DEFAULT_APP_SETTINGS, ...snapshot.data() });
      } else {
        callback(DEFAULT_APP_SETTINGS);
      }
    },
    () => {
      callback(DEFAULT_APP_SETTINGS);
    }
  );
}

/**
 * Subscribe to real-time Payment Settings
 */
export function subscribePaymentSettings(callback: (settings: PaymentSettingsConfig) => void): () => void {
  const configRef = doc(db, 'payment_settings', 'config');
  return onSnapshot(
    configRef,
    (snapshot) => {
      if (snapshot.exists()) {
        callback({ ...DEFAULT_PAYMENT_SETTINGS, ...snapshot.data() });
      } else {
        callback(DEFAULT_PAYMENT_SETTINGS);
      }
    },
    () => {
      callback(DEFAULT_PAYMENT_SETTINGS);
    }
  );
}

/**
 * Subscribe to active Stories / Tasks
 */
export function subscribeStories(callback: (stories: TaskItem[]) => void): () => void {
  // First fetch from backend
  fetch('/api/tasks')
    .then((r) => r.json())
    .then((data) => {
      if (data.success && data.tasks && data.tasks.length > 0) {
        callback(data.tasks);
      }
    })
    .catch(() => {});

  const tasksRef = collection(db, 'tasks');
  return onSnapshot(
    tasksRef,
    (snapshot) => {
      if (!snapshot.empty) {
        const items = snapshot.docs
          .map((d) => ({ id: d.id, ...d.data() }))
          .filter((t: any) => t.active !== false) as TaskItem[];
        items.sort((a, b) => (a.order || 0) - (b.order || 0));
        callback(items);
      } else {
        callback(DEFAULT_SAMPLE_STORIES);
      }
    },
    () => {
      callback(DEFAULT_SAMPLE_STORIES);
    }
  );
}

/**
 * Get all tasks for admin
 */
export async function getAllTasksForAdmin(): Promise<TaskItem[]> {
  try {
    const res = await fetch('/api/tasks');
    const data = await res.json();
    if (data.success && data.tasks) {
      return data.tasks;
    }
  } catch (_) {}
  return DEFAULT_SAMPLE_STORIES;
}

/**
 * Save / Update a task by Admin
 */
export async function saveTaskByAdmin(task: Partial<TaskItem>): Promise<{ success: boolean; message: string }> {
  try {
    const taskId = task.id || `task_${Date.now()}`;
    const taskRef = doc(db, 'tasks', taskId);
    await setDoc(
      taskRef,
      {
        ...task,
        id: taskId,
        updatedAt: Date.now()
      },
      { merge: true }
    );
    return { success: true, message: 'Task saved successfully!' };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Failed to save task';
    return { success: false, message: msg };
  }
}

/**
 * Get today's claims for user from task_submissions
 */
export async function getUserStoryClaimsToday(uid: string): Promise<string[]> {
  try {
    // 1. Check server API
    const res = await fetch(`/api/task-submissions/${uid}`);
    const data = await res.json();
    if (data.success && data.claimedTaskIds) {
      return data.claimedTaskIds;
    }
  } catch (_) {}

  // 2. Fallback to Firestore task_submissions
  try {
    const today = getTodayKey();
    const q = query(
      collection(db, 'task_submissions'),
      where('uid', '==', uid),
      where('claimDate', '==', today),
      where('status', '==', 'completed')
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => (d.data() as TaskClaim).taskId);
  } catch (err) {
    console.warn('Error fetching task submissions:', err);
    return [];
  }
}

/**
 * Claim Story / Task Reward with TRUSTED BACKEND PROCESSING
 * - Contacts /api/tasks/complete on server
 * - Verifies user UID and task configuration in database
 * - Validates reward amount
 * - Checks eligibility and prevents duplicate claims
 * - Atomically credits wallet and adds transaction record
 * - Refreshes local wallet state immediately
 * - ONLY returns success if backend confirms the database write!
 */
export async function claimStoryReward(
  uid: string,
  taskId: string
): Promise<{ success: boolean; rewardAmount: number; message: string; wallet?: UserWallet }> {
  if (!uid || !taskId) {
    return { success: false, rewardAmount: 0, message: 'Missing user UID or task ID.' };
  }

  const idempotencyKey = `idemp_${uid}_${taskId}_${getTodayKey()}_${Date.now()}`;

  try {
    // 1. Call trusted backend API for authoritative reward calculation and wallet credit
    const response = await fetch('/api/tasks/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        uid,
        taskId,
        idempotencyKey
      })
    });

    const result = await response.json();

    if (!response.ok || !result.success) {
      const errorMsg = result.error || result.message || 'Task reward validation failed on server.';
      return { success: false, rewardAmount: 0, message: errorMsg };
    }

    // 2. Successful backend confirmation!
    const rewardAmount = result.rewardAmount;
    const updatedWallet = result.wallet;

    // Immediately notify wallet listeners to update balance in UI without logout
    if (updatedWallet) {
      notifyWalletUpdated(uid, {
        uid,
        availableBalance: Number((updatedWallet.availableBalance ?? 0).toFixed(2)),
        pendingBalance: Number((updatedWallet.pendingBalance ?? 0).toFixed(2)),
        totalEarnings: Number((updatedWallet.totalEarnings ?? 0).toFixed(2)),
        taskEarnings: Number((updatedWallet.taskEarnings ?? updatedWallet.storyEarnings ?? 0).toFixed(2)),
        spinEarnings: Number((updatedWallet.spinEarnings ?? 0).toFixed(2)),
        scratchEarnings: Number((updatedWallet.scratchEarnings ?? 0).toFixed(2)),
        storyEarnings: Number((updatedWallet.storyEarnings ?? 0).toFixed(2)),
        referralEarnings: Number((updatedWallet.referralEarnings ?? 0).toFixed(2)),
        otherEarnings: Number((updatedWallet.otherEarnings ?? 0).toFixed(2)),
        updatedAt: updatedWallet.updatedAt ?? Date.now()
      });
    }

    return {
      success: true,
      rewardAmount,
      wallet: updatedWallet,
      message: result.message || `🎉 ₹${rewardAmount} credited to your wallet balance!`
    };
  } catch (networkErr: unknown) {
    console.warn('Backend API request error, running atomic Firestore transaction fallback:', networkErr);

    // Fallback: Direct Firestore execution if offline
    try {
      const today = getTodayKey();
      const submissionKey = `${uid}_${taskId}_${today}`;
      const submissionRef = doc(db, 'task_submissions', submissionKey);

      // Check existing submission
      const existing = await getDoc(submissionRef);
      if (existing.exists() && existing.data().status === 'completed') {
        return { success: false, rewardAmount: 0, message: 'You have already claimed this task reward for today!' };
      }

      // Load task
      let taskReward = 10;
      let taskTitle = 'Status Task';
      const taskDocRef = doc(db, 'tasks', taskId);
      const taskSnap = await getDoc(taskDocRef);
      if (taskSnap.exists()) {
        const tData = taskSnap.data();
        if (tData.active === false) {
          return { success: false, rewardAmount: 0, message: 'This task is inactive.' };
        }
        taskReward = Number(tData.rewardAmount) || 10;
        taskTitle = tData.title || 'Status Task';
      }

      const txId = `tx_task_${Date.now()}`;
      await setDoc(submissionRef, {
        id: submissionKey,
        taskId,
        uid,
        rewardAmount: taskReward,
        status: 'completed',
        completedAt: Date.now(),
        claimDate: today,
        transactionId: txId
      });

      await creditUserWallet(
        uid,
        taskReward,
        `Task Reward: ${taskTitle}`,
        'taskEarnings',
        submissionKey
      );

      return {
        success: true,
        rewardAmount: taskReward,
        message: `🎉 ₹${taskReward} credited to your wallet balance!`
      };
    } catch (fbErr: unknown) {
      const msg = fbErr instanceof Error ? fbErr.message : 'Database reward credit failed.';
      return { success: false, rewardAmount: 0, message: msg };
    }
  }
}

/**
 * Get today's spins for user
 */
export async function getUserSpinsToday(uid: string): Promise<SpinResult[]> {
  try {
    const today = getTodayKey();
    const q = query(
      collection(db, 'spin_results'),
      where('uid', '==', uid),
      where('spinDate', '==', today)
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => ({
      id: d.id,
      ...d.data()
    })) as SpinResult[];
  } catch (err) {
    console.warn('Error fetching spin history:', err);
    return [];
  }
}

/**
 * Record a Spin Result & Credit Wallet with backend validation
 */
export async function recordSpinResult(
  uid: string,
  rewardAmount: number
): Promise<{ success: boolean; spin: SpinResult; message: string }> {
  try {
    const res = await fetch('/api/spin/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid, rewardAmount })
    });
    const data = await res.json();
    if (data.success) {
      if (data.wallet) {
        notifyWalletUpdated(uid, data.wallet);
      }
      return {
        success: true,
        spin: {
          id: data.transactionId,
          uid,
          rewardAmount: data.rewardAmount,
          timestamp: Date.now(),
          status: 'credited',
          spinDate: getTodayKey()
        },
        message: data.message
      };
    }
  } catch (_) {}

  // Fallback
  const spinData: SpinResult = {
    id: `spin_${Date.now()}`,
    uid,
    rewardAmount,
    timestamp: Date.now(),
    status: 'credited',
    spinDate: getTodayKey()
  };
  await creditUserWallet(uid, rewardAmount, 'Spin Daily Reward', 'spinEarnings');
  return { success: true, spin: spinData, message: `Congratulations! Won ₹${rewardAmount}` };
}

/**
 * Get user's scratch card status and remaining cards
 */
export async function getUserScratchStatus(uid: string): Promise<{
  enabled: boolean;
  dailyLimit: number;
  scratchesUsed: number;
  scratchesRemaining: number;
  history: any[];
}> {
  try {
    const res = await fetch(`/api/scratch/status/${uid}`);
    const data = await res.json();
    if (data.success) {
      return {
        enabled: data.enabled !== false,
        dailyLimit: data.dailyLimit || 5,
        scratchesUsed: data.scratchesUsed || 0,
        scratchesRemaining: data.scratchesRemaining ?? 5,
        history: data.history || []
      };
    }
  } catch (_) {}
  return {
    enabled: true,
    dailyLimit: 5,
    scratchesUsed: 0,
    scratchesRemaining: 5,
    history: []
  };
}

/**
 * Generate a new scratch card session from server
 */
export async function generateScratchCard(uid: string): Promise<{
  success: boolean;
  cardId?: string;
  rewardAmount?: number;
  scratchesRemaining?: number;
  error?: string;
}> {
  try {
    const res = await fetch('/api/scratch/card/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid })
    });
    const data = await res.json();
    if (data.success) {
      return {
        success: true,
        cardId: data.cardId,
        rewardAmount: data.rewardAmount,
        scratchesRemaining: data.scratchesRemaining
      };
    }
    return { success: false, error: data.error || 'Failed to generate scratch card' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Network error generating scratch card';
    return { success: false, error: msg };
  }
}

/**
 * Claim Scratch Card reward after >= 50% scratched
 */
export async function claimScratchCardReward(
  uid: string,
  cardId: string,
  scratchPercentage: number
): Promise<{
  success: boolean;
  rewardAmount?: number;
  wallet?: UserWallet;
  transactionId?: string;
  message?: string;
  error?: string;
}> {
  try {
    const idempotencyKey = `idemp_scratch_${uid}_${cardId}`;
    const res = await fetch('/api/scratch/card/claim', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        uid,
        cardId,
        scratchPercentage,
        idempotencyKey
      })
    });
    const data = await res.json();
    if (data.success) {
      if (data.wallet) {
        notifyWalletUpdated(uid, data.wallet);
      }
      return {
        success: true,
        rewardAmount: data.rewardAmount,
        wallet: data.wallet,
        transactionId: data.transactionId,
        message: data.message || `Won ₹${data.rewardAmount}!`
      };
    }
    return { success: false, error: data.error || 'Failed to claim scratch card' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Error claiming scratch card reward';
    return { success: false, error: msg };
  }
}

/**
 * Get Admin Overview Statistics
 */
export async function getAdminOverview(): Promise<any> {
  try {
    const res = await fetch('/api/admin/overview');
    const data = await res.json();
    if (data.success) return data.stats;
  } catch (_) {}
  return null;
}

/**
 * Safely credit wallet balance and create transaction with idempotency
 */
export async function creditUserWallet(
  uid: string,
  amount: number,
  source: string,
  categoryKey: 'taskEarnings' | 'spinEarnings' | 'scratchEarnings' | 'storyEarnings' | 'referralEarnings' | 'otherEarnings',
  idempotencyKey?: string
): Promise<void> {
  const walletRef = doc(db, 'wallets', uid);
  const roundedAmount = Number(amount.toFixed(2));
  const txId = `tx_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  try {
    let finalWallet: UserWallet | null = null;
    await runTransaction(db, async (txn) => {
      const snap = await txn.get(walletRef);
      if (snap.exists()) {
        const data = snap.data() as UserWallet;
        const newAvailable = Number(((data.availableBalance || 0) + roundedAmount).toFixed(2));
        const newTotal = Number(((data.totalEarnings || 0) + roundedAmount).toFixed(2));
        const newCategory = Number(((data[categoryKey] || 0) + roundedAmount).toFixed(2));

        const updated = {
          ...data,
          availableBalance: newAvailable,
          totalEarnings: newTotal,
          [categoryKey]: newCategory,
          updatedAt: Date.now()
        };
        txn.update(walletRef, updated);
        finalWallet = updated;
      } else {
        const created: UserWallet = {
          uid,
          availableBalance: roundedAmount,
          pendingBalance: 0,
          totalEarnings: roundedAmount,
          taskEarnings: categoryKey === 'taskEarnings' || categoryKey === 'storyEarnings' ? roundedAmount : 0,
          spinEarnings: categoryKey === 'spinEarnings' ? roundedAmount : 0,
          scratchEarnings: categoryKey === 'scratchEarnings' ? roundedAmount : 0,
          storyEarnings: categoryKey === 'storyEarnings' ? roundedAmount : 0,
          referralEarnings: categoryKey === 'referralEarnings' ? roundedAmount : 0,
          otherEarnings: categoryKey === 'otherEarnings' ? roundedAmount : 0,
          updatedAt: Date.now()
        };
        txn.set(walletRef, created);
        finalWallet = created;
      }
    });

    if (finalWallet) {
      notifyWalletUpdated(uid, finalWallet);
    }

    // Create unique ledger entry in transactions/{txId}
    const txRef = doc(db, 'transactions', txId);
    await setDoc(txRef, {
      id: txId,
      uid,
      amount: roundedAmount,
      type: 'credit',
      source,
      status: 'completed',
      timestamp: Date.now(),
      idempotencyKey: idempotencyKey || txId
    });
  } catch (err) {
    console.error('Wallet credit transaction notice:', err);
  }
}

/**
 * Manual auditable adjustment by Administrator
 */
export async function adjustUserWalletByAdmin(
  adminUid: string,
  targetUid: string,
  amount: number,
  reason: string
): Promise<{ success: boolean; message: string }> {
  const walletRef = doc(db, 'wallets', targetUid);
  const roundedAmount = Number(Math.abs(amount).toFixed(2));
  const isCredit = amount >= 0;
  const txId = `adj_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

  try {
    await runTransaction(db, async (txn) => {
      const snap = await txn.get(walletRef);
      if (!snap.exists()) {
        throw new Error('User wallet does not exist');
      }
      const data = snap.data() as UserWallet;

      if (!isCredit && data.availableBalance < roundedAmount) {
        throw new Error('User does not have sufficient balance for debit adjustment');
      }

      const newAvailable = isCredit
        ? Number((data.availableBalance + roundedAmount).toFixed(2))
        : Number((data.availableBalance - roundedAmount).toFixed(2));

      txn.update(walletRef, {
        availableBalance: newAvailable,
        updatedAt: Date.now()
      });
    });

    await setDoc(doc(db, 'transactions', txId), {
      id: txId,
      uid: targetUid,
      amount: roundedAmount,
      type: 'adjustment',
      source: `Admin Adjustment: ${reason} (by ${adminUid})`,
      status: 'completed',
      timestamp: Date.now(),
      note: reason
    });

    return { success: true, message: `Wallet adjusted successfully by ${isCredit ? '+' : '-'}${roundedAmount}` };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Adjustment failed';
    return { success: false, message: msg };
  }
}

/**
 * Subscribe to user transactions
 */
export function subscribeUserTransactions(
  uid: string,
  callback: (transactions: WalletTransaction[]) => void
): () => void {
  // Fetch from backend
  fetch(`/api/transactions/${uid}`)
    .then((r) => r.json())
    .then((data) => {
      if (data.success && data.transactions) {
        callback(data.transactions);
      }
    })
    .catch(() => {});

  const q = query(collection(db, 'transactions'), where('uid', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const list = snapshot.docs.map((d) => ({
        id: d.id,
        ...d.data()
      })) as WalletTransaction[];
      list.sort((a, b) => b.timestamp - a.timestamp);
      callback(list);
    },
    () => callback([])
  );
}

/**
 * Submit Withdrawal Request
 */
export async function submitWithdrawalRequest(
  uid: string,
  amount: number,
  upiId: string,
  userName?: string,
  userPhone?: string
): Promise<{ success: boolean; message: string; withdrawalId?: string }> {
  try {
    // 1. Send to server
    const res = await fetch('/api/withdrawals/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid, amount, upiId, userName, userPhone })
    });
    const data = await res.json();
    if (data.success) {
      if (data.wallet) notifyWalletUpdated(uid, data.wallet);
      return { success: true, message: data.message, withdrawalId: data.withdrawalId };
    } else {
      return { success: false, message: data.error || 'Failed to submit withdrawal' };
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Withdrawal error';
    return { success: false, message: msg };
  }
}

/**
 * Admin action: Process Withdrawal
 */
export async function processWithdrawalByAdmin(
  withdrawalId: string,
  action: 'paid' | 'rejected',
  rejectionReason?: string
): Promise<{ success: boolean; message: string }> {
  try {
    const wdRef = doc(db, 'withdrawals', withdrawalId);
    const wdSnap = await getDoc(wdRef);
    if (!wdSnap.exists()) {
      return { success: false, message: 'Withdrawal request not found' };
    }

    const wdData = wdSnap.data() as WithdrawalRequest;
    const walletRef = doc(db, 'wallets', wdData.uid);

    if (action === 'paid') {
      await runTransaction(db, async (txn) => {
        const wSnap = await txn.get(walletRef);
        if (wSnap.exists()) {
          const w = wSnap.data() as UserWallet;
          txn.update(walletRef, {
            pendingBalance: Math.max(0, Number(((w.pendingBalance || 0) - wdData.amount).toFixed(2))),
            updatedAt: Date.now()
          });
        }
      });

      await updateDoc(wdRef, { status: 'paid', processedAt: Date.now() });
      return { success: true, message: `Withdrawal ₹${wdData.amount} marked as paid successfully!` };
    } else {
      await runTransaction(db, async (txn) => {
        const wSnap = await txn.get(walletRef);
        if (wSnap.exists()) {
          const w = wSnap.data() as UserWallet;
          txn.update(walletRef, {
            availableBalance: Number(((w.availableBalance || 0) + wdData.amount).toFixed(2)),
            pendingBalance: Math.max(0, Number(((w.pendingBalance || 0) - wdData.amount).toFixed(2))),
            updatedAt: Date.now()
          });
        }
      });

      await updateDoc(wdRef, { status: 'rejected', rejectionReason: rejectionReason || '' });
      return { success: true, message: 'Withdrawal rejected and balance safely refunded.' };
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Error processing withdrawal';
    return { success: false, message: msg };
  }
}

/**
 * Subscribe to user withdrawals
 */
export function subscribeUserWithdrawals(
  uid: string,
  callback: (withdrawals: WithdrawalRequest[]) => void
): () => void {
  const q = query(collection(db, 'withdrawals'), where('uid', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs.map((d) => ({
        id: d.id,
        ...d.data()
      })) as WithdrawalRequest[];
      items.sort((a, b) => b.createdAt - a.createdAt);
      callback(items);
    },
    () => callback([])
  );
}

/**
 * Subscribe to all withdrawals (for Admin)
 */
export function subscribeAllWithdrawals(
  callback: (withdrawals: WithdrawalRequest[]) => void
): () => void {
  const q = query(collection(db, 'withdrawals'), limit(50));
  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs.map((d) => ({
        id: d.id,
        ...d.data()
      })) as WithdrawalRequest[];
      items.sort((a, b) => b.createdAt - a.createdAt);
      callback(items);
    },
    () => callback([])
  );
}

/**
 * Subscribe to Live Successful Withdrawals for Notification Ticker
 */
export function subscribeLiveWithdrawals(
  callback: (items: LiveWithdrawalItem[]) => void
): () => void {
  const q = query(collection(db, 'withdrawals'), where('status', '==', 'paid'), limit(20));
  return onSnapshot(
    q,
    (snapshot) => {
      if (!snapshot.empty) {
        const liveItems = snapshot.docs.map((d) => {
          const data = d.data() as WithdrawalRequest;
          return {
            id: d.id,
            name: data.userName || 'User',
            amount: data.amount,
            timestamp: data.processedAt || data.createdAt,
            isDemo: false
          };
        });
        liveItems.sort((a, b) => b.timestamp - a.timestamp);
        callback(liveItems);
      } else {
        callback([]);
      }
    },
    () => {
      callback([]);
    }
  );
}

/**
 * Submit KYC verification document
 */
export async function submitKycVerification(
  uid: string,
  data: {
    fullName: string;
    email: string;
    phone: string;
    identityType: 'PAN' | 'Aadhaar' | 'Voter ID' | 'Driving License';
    identityNumber: string;
    documentUrl?: string;
  }
): Promise<{ success: boolean; message: string }> {
  try {
    const kycData: KycRecord = {
      uid,
      fullName: data.fullName,
      email: data.email,
      phone: data.phone,
      identityType: data.identityType,
      identityNumber: data.identityNumber,
      status: 'pending',
      submittedAt: Date.now()
    };
    if (data.documentUrl) {
      kycData.documentUrl = data.documentUrl;
    }
    await setDoc(doc(db, 'kyc', uid), kycData);
    await updateDoc(doc(db, 'users', uid), { kycStatus: 'pending' });
    return { success: true, message: 'KYC details submitted successfully! Status set to Pending review.' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Failed to submit KYC';
    return { success: false, message: msg };
  }
}

/**
 * Review KYC by Admin
 */
export async function reviewKycByAdmin(
  targetUid: string,
  status: 'approved' | 'rejected',
  rejectionReason?: string
): Promise<{ success: boolean; message: string }> {
  try {
    await updateDoc(doc(db, 'kyc', targetUid), {
      status,
      rejectionReason: rejectionReason || '',
      reviewedAt: Date.now()
    });
    await updateDoc(doc(db, 'users', targetUid), { kycStatus: status });
    return { success: true, message: `KYC status updated to ${status}` };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Error updating KYC';
    return { success: false, message: msg };
  }
}

/**
 * Subscribe to user KYC
 */
export function subscribeUserKyc(uid: string, callback: (kyc: KycRecord | null) => void): () => void {
  const kycRef = doc(db, 'kyc', uid);
  return onSnapshot(
    kycRef,
    (snapshot) => {
      if (snapshot.exists()) {
        callback(snapshot.data() as KycRecord);
      } else {
        callback(null);
      }
    },
    () => callback(null)
  );
}

/**
 * Subscribe to all KYC requests for Admin
 */
export function subscribeAllKyc(callback: (records: KycRecord[]) => void): () => void {
  const q = query(collection(db, 'kyc'), limit(50));
  return onSnapshot(
    q,
    (snapshot) => {
      const records = snapshot.docs.map((d) => ({
        uid: d.id,
        ...d.data()
      })) as KycRecord[];
      records.sort((a, b) => b.submittedAt - a.submittedAt);
      callback(records);
    },
    () => callback([])
  );
}

/**
 * Record payment fee verification submission
 */
export async function submitPaymentProof(
  uid: string,
  data: {
    amount: number;
    transactionReference: string;
    proofUrl?: string;
    method: 'ZapUPI' | 'Direct UPI' | 'Manual';
  }
): Promise<{ success: boolean; message: string }> {
  try {
    await addDoc(collection(db, 'payment_records'), {
      uid,
      amount: data.amount,
      transactionReference: data.transactionReference,
      proofUrl: data.proofUrl || null,
      method: data.method,
      status: 'pending',
      submittedAt: Date.now()
    });
    await updateDoc(doc(db, 'users', uid), { feePaid: true });
    return { success: true, message: 'Payment record submitted for verification!' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Error submitting payment';
    return { success: false, message: msg };
  }
}

/**
 * Record a verified ZapUPI payment directly
 */
export async function recordSuccessfulZapPayment(
  uid: string,
  amount: number,
  orderId: string
): Promise<{ success: boolean; message: string }> {
  try {
    await updateDoc(doc(db, 'users', uid), {
      feePaid: true,
      paymentStatus: 'verified',
      feePaymentOrderId: orderId,
      feePaidAt: Date.now()
    });

    await addDoc(collection(db, 'payment_records'), {
      uid,
      amount,
      transactionReference: orderId,
      method: 'ZapUPI',
      status: 'verified',
      verifiedAt: Date.now(),
      createdAt: Date.now()
    });

    await setDoc(doc(db, 'transactions', `fee_${orderId}`), {
      id: `fee_${orderId}`,
      uid,
      amount,
      type: 'debit',
      source: `Verification Fee (ZapUPI - ${orderId})`,
      status: 'completed',
      referenceId: orderId,
      timestamp: Date.now()
    });

    return { success: true, message: `Payment verified for Order: ${orderId}` };
  } catch (err: unknown) {
    console.error('Payment record error:', err);
    return { success: true, message: `Payment recorded for Order: ${orderId}` };
  }
}

/**
 * Subscribe to user notifications
 */
export function subscribeNotifications(
  uid: string,
  callback: (notifications: AppNotification[]) => void
): () => void {
  const q = query(collection(db, 'notifications'));
  return onSnapshot(
    q,
    (snapshot) => {
      const all = snapshot.docs.map((d) => ({
        id: d.id,
        ...d.data()
      })) as AppNotification[];
      const userList = all.filter((n) => !n.uid || n.uid === uid);
      userList.sort((a, b) => b.createdAt - a.createdAt);
      callback(userList);
    },
    () => callback([])
  );
}

/**
 * Submit support ticket
 */
export async function submitSupportTicket(
  ticket: Omit<SupportTicket, 'id' | 'createdAt' | 'status'>
): Promise<{ success: boolean; message: string }> {
  try {
    await addDoc(collection(db, 'support_tickets'), {
      ...ticket,
      status: 'Open',
      createdAt: Date.now()
    });
    return { success: true, message: 'Support ticket submitted. Our team will get back to you shortly!' };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Failed to create ticket';
    return { success: false, message: msg };
  }
}

/**
 * Subscribe to user support tickets
 */
export function subscribeSupportTickets(
  uid: string,
  callback: (tickets: SupportTicket[]) => void
): () => void {
  const q = query(collection(db, 'support_tickets'), where('uid', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const list = snapshot.docs.map((d) => ({
        id: d.id,
        ...d.data()
      })) as SupportTicket[];
      list.sort((a, b) => b.createdAt - a.createdAt);
      callback(list);
    },
    () => callback([])
  );
}

/**
 * Get comprehensive referral stats & history for a user
 */
export async function getReferralStats(
  userUid: string,
  referralCode: string
): Promise<{
  totalCount: number;
  eligibleCount: number;
  pendingCount: number;
  earnings: number;
  referrals: ReferralRecord[];
}> {
  try {
    const res = await fetch(`/api/referrals/${userUid}?code=${referralCode}`);
    const data = await res.json();
    if (data.success && data.stats) {
      return data.stats;
    }
  } catch (_) {}

  // Fallback to Firestore
  try {
    const qUid = query(collection(db, 'referrals'), where('referrerUid', '==', userUid));
    const snapUid = await getDocs(qUid);
    const qCode = query(collection(db, 'referrals'), where('referrerCode', '==', referralCode));
    const snapCode = await getDocs(qCode);

    const recordMap = new Map<string, ReferralRecord>();
    snapUid.docs.forEach((d) => recordMap.set(d.id, { id: d.id, ...(d.data() as Omit<ReferralRecord, 'id'>) }));
    snapCode.docs.forEach((d) => recordMap.set(d.id, { id: d.id, ...(d.data() as Omit<ReferralRecord, 'id'>) }));

    const records = Array.from(recordMap.values());
    records.sort((a, b) => b.createdAt - a.createdAt);

    const totalCount = records.length;
    const creditedRecords = records.filter((r) => r.status === 'credited');
    const eligibleCount = creditedRecords.length;
    const pendingCount = records.filter((r) => r.status === 'pending').length;
    const earnings = creditedRecords.reduce((sum, r) => sum + (r.rewardAmount || 50), 0);

    return { totalCount, eligibleCount, pendingCount, earnings, referrals: records };
  } catch (err) {
    return { totalCount: 0, eligibleCount: 0, pendingCount: 0, earnings: 0, referrals: [] };
  }
}

/**
 * Update App Settings by Admin
 */
export async function updateAppSettingsByAdmin(
  settings: Partial<AppSettingsConfig>
): Promise<{ success: boolean; message: string }> {
  try {
    fetch('/api/admin/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    }).catch(() => {});

    const configRef = doc(db, 'app_settings', 'config');
    await setDoc(configRef, { ...settings, updatedAt: Date.now() }, { merge: true });
    return { success: true, message: 'Application settings updated successfully!' };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Failed to update settings';
    return { success: false, message: msg };
  }
}

/**
 * Allow authorized administrators to approve profile verification badge
 * Separate from KYC verification
 */
export async function setUserVerificationStatusByAdmin(
  targetUid: string,
  isVerified: boolean
): Promise<{ success: boolean; message: string }> {
  try {
    await updateDoc(doc(db, 'users', targetUid), {
      isVerified,
      verified: isVerified,
      verifiedAt: isVerified ? Date.now() : null
    });
    return {
      success: true,
      message: `Profile verification ${isVerified ? 'approved' : 'revoked'} successfully.`
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Failed to update verification status';
    return { success: false, message: msg };
  }
}

// -------------------------------------------------------------
// DAILY CHECK-IN & CONSECUTIVE STREAK TRACKING
// -------------------------------------------------------------
export const DAILY_CHECKIN_REWARDS = [1, 2, 3, 4, 5, 7, 10];

function calculateDaysBetween(dateStr1: string, dateStr2: string): number {
  if (!dateStr1 || !dateStr2) return 999;
  const [y1, m1, d1] = dateStr1.split('-').map(Number);
  const [y2, m2, d2] = dateStr2.split('-').map(Number);
  const ut1 = Date.UTC(y1, m1 - 1, d1);
  const ut2 = Date.UTC(y2, m2 - 1, d2);
  const diffMs = ut2 - ut1;
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Get user's current daily check-in and streak status
 */
export async function getUserCheckInStatus(uid: string): Promise<CheckInStatus> {
  if (!uid) {
    return {
      streak: 0,
      lastCheckInDate: null,
      canCheckInToday: true,
      todayRewardAmount: DAILY_CHECKIN_REWARDS[0],
      nextStreakDay: 1,
      totalCheckIns: 0,
      streakRewards: DAILY_CHECKIN_REWARDS,
      history: []
    };
  }

  // 1. Try authoritative server endpoint first
  try {
    const res = await fetch(`/api/checkin/status/${uid}`);
    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        return {
          streak: data.streak ?? 0,
          lastCheckInDate: data.lastCheckInDate ?? null,
          canCheckInToday: data.canCheckInToday ?? true,
          todayRewardAmount: data.todayRewardAmount ?? DAILY_CHECKIN_REWARDS[0],
          nextStreakDay: data.nextStreakDay ?? 1,
          totalCheckIns: data.totalCheckIns ?? 0,
          streakRewards: data.streakRewards || DAILY_CHECKIN_REWARDS,
          history: data.history || []
        };
      }
    }
  } catch (_) {}

  // 2. Direct Firestore fallback
  try {
    const today = getTodayKey();
    const checkInRef = doc(db, 'check_ins', uid);
    const snap = await getDoc(checkInRef);

    if (snap.exists()) {
      const data = snap.data();
      const lastDate = data.lastCheckInDate || null;
      let canCheckInToday = true;
      let streak = data.streak || 0;
      let todayRewardAmount = DAILY_CHECKIN_REWARDS[0];
      let nextStreakDay = 1;

      if (lastDate === today) {
        canCheckInToday = false;
        streak = data.streak || 1;
        const cycleDay = ((streak - 1) % 7) + 1;
        todayRewardAmount = DAILY_CHECKIN_REWARDS[cycleDay - 1];
        nextStreakDay = (streak % 7) + 1;
      } else if (lastDate) {
        const diff = calculateDaysBetween(lastDate, today);
        if (diff === 1) {
          const nextStreak = streak + 1;
          nextStreakDay = ((nextStreak - 1) % 7) + 1;
          todayRewardAmount = DAILY_CHECKIN_REWARDS[nextStreakDay - 1];
        } else {
          streak = 0;
          nextStreakDay = 1;
          todayRewardAmount = DAILY_CHECKIN_REWARDS[0];
        }
      }

      return {
        streak,
        lastCheckInDate: lastDate,
        canCheckInToday,
        todayRewardAmount,
        nextStreakDay,
        totalCheckIns: data.totalCheckIns || 0,
        streakRewards: DAILY_CHECKIN_REWARDS,
        history: data.history || []
      };
    }
  } catch (err) {
    console.warn('Error reading check-in from Firestore:', err);
  }

  return {
    streak: 0,
    lastCheckInDate: null,
    canCheckInToday: true,
    todayRewardAmount: DAILY_CHECKIN_REWARDS[0],
    nextStreakDay: 1,
    totalCheckIns: 0,
    streakRewards: DAILY_CHECKIN_REWARDS,
    history: []
  };
}

/**
 * Claim user's daily check-in bonus & increment consecutive streak
 */
export async function claimDailyCheckIn(uid: string): Promise<CheckInClaimResult> {
  if (!uid) {
    return { success: false, rewardAmount: 0, newStreak: 0, message: 'User not signed in.' };
  }

  // 1. Authoritative backend request
  try {
    const res = await fetch('/api/checkin/claim', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid })
    });
    const data = await res.json();
    if (res.ok && data.success) {
      if (data.wallet) {
        notifyWalletUpdated(uid, data.wallet);
      }
      return {
        success: true,
        rewardAmount: data.rewardAmount,
        newStreak: data.newStreak,
        wallet: data.wallet,
        message: data.message || `🎉 Day ${data.streakDay || 1} Streak Bonus: ₹${data.rewardAmount} credited!`
      };
    } else if (data.error) {
      return { success: false, rewardAmount: 0, newStreak: 0, message: data.error };
    }
  } catch (_) {}

  // 2. Direct Firestore transactional fallback
  try {
    const today = getTodayKey();
    const checkInRef = doc(db, 'check_ins', uid);
    const snap = await getDoc(checkInRef);

    let streak = 0;
    let lastDate: string | null = null;
    let totalCheckIns = 0;
    let totalRewardsEarned = 0;
    let history: any[] = [];

    if (snap.exists()) {
      const d = snap.data();
      streak = d.streak || 0;
      lastDate = d.lastCheckInDate || null;
      totalCheckIns = d.totalCheckIns || 0;
      totalRewardsEarned = d.totalRewardsEarned || 0;
      history = Array.isArray(d.history) ? d.history : [];
    }

    if (lastDate === today) {
      return {
        success: false,
        rewardAmount: 0,
        newStreak: streak,
        message: 'You have already checked in today! Come back tomorrow.'
      };
    }

    let newStreak = 1;
    if (lastDate) {
      const diff = calculateDaysBetween(lastDate, today);
      if (diff === 1) {
        newStreak = streak + 1;
      } else {
        newStreak = 1;
      }
    }

    const cycleDay = ((newStreak - 1) % 7) + 1;
    const rewardAmount = DAILY_CHECKIN_REWARDS[cycleDay - 1];

    const updatedRecord = {
      uid,
      streak: newStreak,
      lastCheckInDate: today,
      totalCheckIns: totalCheckIns + 1,
      totalRewardsEarned: Number((totalRewardsEarned + rewardAmount).toFixed(2)),
      updatedAt: Date.now(),
      history: [
        {
          date: today,
          streakDay: cycleDay,
          streakCount: newStreak,
          rewardAmount,
          timestamp: Date.now()
        },
        ...history.slice(0, 29)
      ]
    };

    await setDoc(checkInRef, updatedRecord, { merge: true });

    // Credit wallet
    await creditUserWallet(
      uid,
      rewardAmount,
      `Daily Check-in Bonus (Day ${cycleDay})`,
      'otherEarnings',
      `checkin_${uid}_${today}`
    );

    // Add user notification
    try {
      await addDoc(collection(db, 'notifications'), {
        uid,
        title: 'Daily Streak Bonus Claimed! 🔥',
        message: `You completed Day ${cycleDay} check-in and earned ₹${rewardAmount}. Keep your streak alive tomorrow!`,
        category: 'Rewards',
        read: false,
        createdAt: Date.now()
      });
    } catch (_) {}

    return {
      success: true,
      rewardAmount,
      newStreak,
      message: `🎉 Day ${cycleDay} Streak Bonus: ₹${rewardAmount} credited to your wallet!`
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Failed to claim daily check-in';
    return { success: false, rewardAmount: 0, newStreak: 0, message: msg };
  }
}
