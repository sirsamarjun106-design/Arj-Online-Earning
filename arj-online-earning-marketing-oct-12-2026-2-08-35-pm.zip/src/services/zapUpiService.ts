declare global {
  interface Window {
    ZapUPI?: {
      setPaymentCallbacks: (callbacks: {
        onSuccess?: (orderId: string) => void;
        onFailed?: (orderId: string) => void;
        onTimeout?: (orderId: string) => void;
        onCancel?: (orderId: string) => void;
      }) => void;
      createOrder: (
        orderData: {
          zap_key: string;
          order_id: string;
          amount: string;
          customer_mobile?: string;
          remark?: string;
        },
        callbacks: {
          onResponse: (paymentUrl: string, orderId: string, data: unknown) => void;
          onError: (err: string) => void;
        }
      ) => void;
      loadPayment: (paymentUrl: string) => void;
    };
  }
}

export interface ZapPaymentParams {
  amount: number | string;
  paymentLink?: string;
  orderId?: string;
  customerMobile?: string;
  customerName?: string;
  userId?: string;
  zapKey?: string;
  remark?: string;
}

export interface ZapPaymentCallbacks {
  onSuccess: (orderId: string) => void;
  onFailed: (orderId: string) => void;
  onTimeout: (orderId: string) => void;
  onError: (errorMsg: string) => void;
}

/**
 * Register payment callbacks on the ZapUPI Web SDK.
 */
export const registerZapPaymentCallbacks = (
  callbacks: ZapPaymentCallbacks,
  fallbackOrderId: string
) => {
  if (typeof window !== 'undefined' && window.ZapUPI && typeof window.ZapUPI.setPaymentCallbacks === 'function') {
    window.ZapUPI.setPaymentCallbacks({
      onSuccess: (orderId: string) => {
        callbacks.onSuccess(orderId || fallbackOrderId);
      },
      onFailed: (orderId: string) => {
        callbacks.onFailed(orderId || fallbackOrderId);
      },
      onTimeout: (orderId: string) => {
        callbacks.onTimeout(orderId || fallbackOrderId);
      },
      onCancel: (orderId: string) => {
        callbacks.onFailed(orderId || fallbackOrderId);
      }
    });
    return true;
  }
  return false;
};

/**
 * Service to manage ZapUPI transactions smoothly.
 */
export const initiateZapPayment = (
  params: ZapPaymentParams,
  callbacks: ZapPaymentCallbacks
): string => {
  const uniqueOrderId =
    params.orderId ||
    `ORD_${Date.now()}_${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
  const amountStr = String(params.amount);

  if (typeof window !== 'undefined' && window.ZapUPI) {
    try {
      registerZapPaymentCallbacks(callbacks, uniqueOrderId);

      if (params.paymentLink && params.paymentLink.trim() !== '') {
        const link = params.paymentLink.trim();
        if (typeof window.ZapUPI.loadPayment === 'function') {
          window.ZapUPI.loadPayment(link);
          return uniqueOrderId;
        } else {
          window.location.href = link;
          return uniqueOrderId;
        }
      }

      if (typeof window.ZapUPI.createOrder === 'function') {
        const activeKey = params.zapKey || 'zap64b8e6c0bbd16e5965a3ad714395863a';
        window.ZapUPI.createOrder(
          {
            zap_key: activeKey,
            order_id: uniqueOrderId,
            amount: amountStr,
            customer_mobile: params.customerMobile || '',
            remark: params.remark || `Verification Fee | ${params.userId || 'User'}`
          },
          {
            onResponse: (paymentUrl: string) => {
              if (paymentUrl) {
                if (window.ZapUPI && typeof window.ZapUPI.loadPayment === 'function') {
                  window.ZapUPI.loadPayment(paymentUrl);
                } else {
                  window.location.href = paymentUrl;
                }
              } else {
                callbacks.onError('Payment URL was not returned by gateway.');
              }
            },
            onError: (err: string) => {
              callbacks.onError(err || 'Failed to initiate ZapUPI payment.');
            }
          }
        );
        return uniqueOrderId;
      }
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'ZapUPI initiation error';
      callbacks.onError(msg);
      return uniqueOrderId;
    }
  }

  if (params.paymentLink && params.paymentLink.trim() !== '') {
    window.location.href = params.paymentLink;
    return uniqueOrderId;
  }

  callbacks.onError('ZapUPI payment kit is initializing. Please tap again or submit your UTR reference.');
  return uniqueOrderId;
};
