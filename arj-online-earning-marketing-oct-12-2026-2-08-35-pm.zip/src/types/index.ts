export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  phone: string;
  referralCode: string;
  referredBy?: string | null;
  createdAt: number;
  kycStatus: 'unverified' | 'pending' | 'approved' | 'rejected';
  accountStatus: 'active' | 'blocked' | 'pending';
  role?: 'user' | 'admin';
  feePaid?: boolean;
  avatarUrl?: string;
  tasksCompletedCount?: number;
  paymentStatus?: string;
  feePaymentOrderId?: string;
  feePaidAt?: number;
  isVerified?: boolean;
  verified?: boolean;
}

export interface UserWallet {
  uid: string;
  availableBalance: number;
  pendingBalance: number;
  totalEarnings: number;
  taskEarnings: number;
  spinEarnings: number;
  scratchEarnings: number;
  storyEarnings: number;
  referralEarnings: number;
  otherEarnings: number;
  todayEarnings?: number;
  updatedAt: number;
}

export type TransactionType = 'credit' | 'debit' | 'withdrawal' | 'adjustment';
export type TransactionStatus = 'completed' | 'pending' | 'failed' | 'rejected';

export interface WalletTransaction {
  id: string;
  uid: string;
  amount: number;
  type: TransactionType;
  source: string; // e.g., 'Spin Wheel Reward', 'Scratch Card Reward', 'Task Reward: ...', 'Referral Bonus', 'UPI Withdrawal'
  status: TransactionStatus;
  timestamp: number;
  referenceId?: string;
  idempotencyKey?: string;
  note?: string;
}

export interface TaskItem {
  id: string;
  title: string;
  description: string;
  category: 'story' | 'video' | 'survey' | 'social' | 'special';
  mediaUrl: string;
  mediaType: 'image' | 'video';
  thumbnailUrl: string;
  rewardAmount: number;
  watchDuration: number; // in seconds
  completionRequired: boolean;
  active: boolean;
  requiresAdminApproval?: boolean;
  order: number;
  createdAt: number;
  updatedAt?: number;
}

export type StoryItem = TaskItem;

export interface TaskClaim {
  id: string;
  uid: string;
  taskId: string;
  completed: boolean;
  rewardAmount: number;
  createdAt: number;
  claimDate: string; // YYYY-MM-DD
  transactionId?: string;
}

export type StoryClaim = TaskClaim;

export interface SpinResult {
  id: string;
  uid: string;
  rewardAmount: number;
  timestamp: number;
  status: 'credited' | 'pending';
  spinDate: string; // YYYY-MM-DD
  transactionId?: string;
}

export interface ScratchCardResult {
  id: string;
  uid: string;
  rewardAmount: number;
  timestamp: number;
  status: 'credited' | 'pending';
  scratchDate: string; // YYYY-MM-DD
  transactionId?: string;
}

export interface WithdrawalRequest {
  id: string;
  uid: string;
  userName?: string;
  userPhone?: string;
  amount: number;
  payoutMethod: 'UPI';
  payoutDetails: {
    upiId: string;
    accountHolderName?: string;
  };
  status: 'pending' | 'processing' | 'paid' | 'rejected' | 'failed';
  rejectionReason?: string;
  transactionReference?: string;
  createdAt: number;
  updatedAt?: number;
  processedAt?: number;
}

export interface KycRecord {
  uid: string;
  fullName: string;
  email: string;
  phone: string;
  identityType: 'PAN' | 'Aadhaar' | 'Voter ID' | 'Driving License';
  identityNumber: string;
  documentUrl?: string;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  submittedAt: number;
  reviewedAt?: number;
}

export interface PaymentSettingsConfig {
  paymentEnabled: boolean;
  feeAmount: number;
  paymentLink: string;
  paymentDescription: string;
  refundPolicy: string;
  withdrawalConditions: string;
  zapKey?: string;
  upiId?: string;
  updatedAt: number;
}

export interface AppSettingsConfig {
  appName: string;
  tagline: string;
  minimumWithdrawal: number;
  maximumWithdrawal: number;
  spinWheelEnabled: boolean;
  scratchCardsEnabled: boolean;
  dailySpinLimit: number;
  dailyScratchLimit: number;
  referralReward: number; // Configurable referral reward amount in DB/settings
  referralEligibility: 'instant_on_register' | 'first_task_completion' | 'kyc_approved'; // eligibility condition
  referrerRewardAmount: number;
  refereeRewardAmount: number; // If reward for both users
  possibleSpinRewards: number[]; // Exactly [1, 5, 8, 10, 13, 15, 17, 19, 10]
  possibleScratchRewards: number[]; // ₹1 to ₹20
  dailyRewardBudget?: number;
  totalRewardsCredited?: number;
  supportEmail: string;
  supportWhatsApp: string;
  liveWithdrawalsDemoEnabled: boolean;
  updatedAt: number;
}

export interface AppNotification {
  id: string;
  uid?: string; // empty means broadcast to all users
  title: string;
  message: string;
  category: 'Rewards' | 'KYC' | 'Withdrawal' | 'Announcements';
  read?: boolean;
  createdAt: number;
}

export interface SupportTicket {
  id: string;
  uid: string;
  userEmail: string;
  userName: string;
  subject: string;
  description: string;
  category: string;
  status: 'Open' | 'In Progress' | 'Resolved';
  createdAt: number;
}

export interface ReferralRecord {
  id: string;
  referrerUid: string;
  referrerCode: string;
  referredUid: string;
  referredName: string;
  rewardAmount: number;
  status: 'pending' | 'eligible' | 'credited';
  createdAt: number;
  creditedAt?: number;
  transactionId?: string;
}

export interface LiveWithdrawalItem {
  id: string;
  name: string;
  amount: number;
  timestamp: number;
  isDemo?: boolean;
}

export interface CheckInStatus {
  streak: number;
  lastCheckInDate: string | null;
  canCheckInToday: boolean;
  todayRewardAmount: number;
  totalCheckIns: number;
  streakRewards: number[];
  nextStreakDay?: number;
  history?: Array<{
    date: string;
    streakDay: number;
    streakCount?: number;
    rewardAmount: number;
    timestamp: number;
  }>;
}

export interface CheckInClaimResult {
  success: boolean;
  rewardAmount: number;
  newStreak: number;
  message: string;
  wallet?: UserWallet;
}
