import React, { useEffect, useState } from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';

interface SplashProps {
  onFinish: () => void;
  isLoggedIn: boolean;
}

export const Splash: React.FC<SplashProps> = ({ onFinish, isLoggedIn }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(() => {
            onFinish();
          }, 350);
          return 100;
        }
        return prev + 12;
      });
    }, 120);

    return () => clearInterval(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-b from-[#070710] via-[#0d0b1a] to-[#05050a] px-6 py-12 text-white overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-purple-600/20 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-1/3 left-1/2 -translate-x-1/2 w-72 h-72 bg-amber-500/15 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/3 w-64 h-64 bg-blue-600/15 rounded-full blur-[90px] pointer-events-none" />

      {/* Top Tag */}
      <div className="pt-6 flex items-center space-x-2 text-xs font-semibold tracking-widest uppercase text-purple-400 bg-purple-950/40 border border-purple-500/20 px-4 py-1.5 rounded-full">
        <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: '4s' }} />
        <span>Official Rewards Portal</span>
      </div>

      {/* Center Logo & Branding */}
      <div className="flex flex-col items-center text-center my-auto">
        <div className="relative mb-6">
          <div className="w-28 h-28 rounded-3xl bg-gradient-to-tr from-purple-700 via-indigo-600 to-amber-500 p-1 shadow-2xl shadow-purple-600/30 flex items-center justify-center">
            <div className="w-full h-full bg-[#0a0914] rounded-[22px] flex flex-col items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent pointer-events-none" />
              <span className="text-4xl font-extrabold tracking-tight bg-gradient-to-r from-amber-300 via-purple-300 to-indigo-200 bg-clip-text text-transparent">
                ARJ
              </span>
              <span className="text-[10px] font-bold text-amber-400 tracking-wider uppercase mt-0.5">
                PRO
              </span>
            </div>
          </div>
          <div className="absolute -inset-2 rounded-[28px] border border-purple-500/30 animate-pulse pointer-events-none" />
        </div>

        <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
          ARJ Online Earning
        </h1>
        <p className="text-sm font-semibold tracking-wider text-purple-400 uppercase mt-1">
          Marketing
        </p>

        <div className="mt-4 flex items-center justify-center space-x-2 text-xs font-medium text-slate-400 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full">
          <span className="text-amber-400">Earn</span>
          <span className="text-slate-600">•</span>
          <span className="text-purple-400">Watch</span>
          <span className="text-slate-600">•</span>
          <span className="text-blue-400">Refer</span>
          <span className="text-slate-600">•</span>
          <span className="text-emerald-400">Rewards</span>
        </div>
      </div>

      {/* Bottom Loading Progress */}
      <div className="w-full max-w-xs flex flex-col items-center">
        <div className="w-full bg-slate-900/80 border border-white/10 rounded-full h-2 overflow-hidden p-0.5">
          <div
            className="bg-gradient-to-r from-purple-600 via-indigo-500 to-amber-400 h-full rounded-full transition-all duration-200 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mt-3 flex justify-between items-center w-full text-[11px] text-slate-400 font-medium">
          <span>{isLoggedIn ? 'Synchronizing Wallet...' : 'Loading Portal...'}</span>
          <span className="text-purple-400 font-bold">{progress}%</span>
        </div>
        <button
          onClick={onFinish}
          className="mt-4 flex items-center space-x-1.5 text-xs text-slate-500 hover:text-slate-300 transition-colors py-1 px-3"
        >
          <span>Tap to continue</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
