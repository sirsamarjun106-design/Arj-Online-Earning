import React from 'react';
import { RotateCw, Play, Sparkles, CheckCircle2, Trophy, MessageCircle, Gift, CreditCard } from 'lucide-react';
import { AppSettingsConfig } from '../../types';

interface EarnPageProps {
  onOpenSpin: () => void;
  onOpenScratch: () => void;
  onOpenStories: () => void;
  spinsRemaining: number;
  scratchesRemaining?: number;
  storiesRemaining: number;
  totalStoriesCount: number;
  appSettings: AppSettingsConfig;
  todayEarnings: number;
}

export const EarnPage: React.FC<EarnPageProps> = ({
  onOpenSpin,
  onOpenScratch,
  onOpenStories,
  spinsRemaining,
  scratchesRemaining = 5,
  storiesRemaining,
  totalStoriesCount,
  appSettings,
  todayEarnings
}) => {
  const dailyScratchLimit = appSettings.dailyScratchLimit || 5;
  const scratchesUsed = Math.max(0, dailyScratchLimit - scratchesRemaining);
  const spinsUsed = appSettings.dailySpinLimit - spinsRemaining;
  const storiesWatched = totalStoriesCount - storiesRemaining;

  const statusItems = [
    { id: 1, title: 'Welcome', reward: '₹10', icon: '🌟' },
    { id: 2, title: 'Daily Spin', reward: '₹10', icon: '🎯' },
    { id: 3, title: 'Instant UPI', reward: '₹10', icon: '⚡' },
    { id: 4, title: 'Refer & Earn', reward: '₹10', icon: '👥' },
    { id: 5, title: 'Safety Tips', reward: '₹10', icon: '🔒' },
  ];

  return (
    <div className="space-y-5 pb-6">
      {/* Page Title */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">
            Daily Tasks Hub
          </span>
          <h2 className="text-xl font-extrabold text-white">EARN MORE</h2>
        </div>
        <div className="bg-purple-950/40 border border-purple-500/20 px-3 py-1.5 rounded-xl flex items-center space-x-1.5">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-bold text-slate-100">Today: ₹{todayEarnings.toFixed(2)}</span>
        </div>
      </div>

      {/* WhatsApp Status Updates Horizontal Tray */}
      <div className="glass-card rounded-2xl p-3.5 border border-emerald-500/20">
        <div className="flex items-center justify-between mb-2.5 px-1">
          <div className="flex items-center space-x-1.5 text-xs font-bold text-emerald-400">
            <MessageCircle className="w-4 h-4" />
            <span>WhatsApp Status Updates</span>
          </div>
          <span className="text-[10px] text-slate-400 font-medium">₹10 Per Status</span>
        </div>
        <div className="flex items-center space-x-3 overflow-x-auto no-scrollbar py-1 px-1">
          {statusItems.map((st) => (
            <button
              key={st.id}
              onClick={onOpenStories}
              className="flex flex-col items-center space-y-1 flex-shrink-0 group focus:outline-none"
            >
              <div className="relative">
                <div className="w-14 h-14 rounded-full p-[2.5px] bg-gradient-to-tr from-emerald-400 via-teal-500 to-amber-400 group-hover:scale-105 transition-transform shadow-md">
                  <div className="w-full h-full bg-[#0e1713] rounded-full flex items-center justify-center text-lg border border-black/40">
                    {st.icon}
                  </div>
                </div>
                <span className="absolute -bottom-1 -right-0.5 text-[9px] font-extrabold text-black bg-amber-400 rounded-full px-1.5 py-0 shadow-sm">
                  {st.reward}
                </span>
              </div>
              <span className="text-[10px] font-semibold text-slate-300 truncate max-w-[60px]">
                {st.title}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Task 1: Spin Daily */}
      <div className="glass-card rounded-3xl p-5 border border-purple-500/25 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/10 rounded-full blur-2xl pointer-events-none" />
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 p-0.5 shadow-lg shadow-purple-600/30 flex items-center justify-center">
              <div className="w-full h-full bg-[#120f26] rounded-[14px] flex items-center justify-center text-white">
                <RotateCw className="w-6 h-6 text-purple-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <h3 className="text-sm font-bold text-white">Spin Daily</h3>
                <span className="text-base">🎯</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {spinsRemaining}/{appSettings.dailySpinLimit} Spins Available Today
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
            Up to ₹20/spin
          </span>
        </div>

        {/* Progress bar */}
        <div className="mt-4">
          <div className="flex justify-between text-[10px] font-medium text-slate-400 mb-1.5">
            <span>Progress ({spinsUsed}/{appSettings.dailySpinLimit} Completed)</span>
            <span className="text-amber-400 font-bold">
              {Math.round((spinsUsed / appSettings.dailySpinLimit) * 100)}%
            </span>
          </div>
          <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div
              className="h-full bg-gradient-to-r from-purple-500 to-amber-400 rounded-full transition-all duration-300"
              style={{ width: `${(spinsUsed / appSettings.dailySpinLimit) * 100}%` }}
            />
          </div>
        </div>

        <button
          onClick={onOpenSpin}
          disabled={spinsRemaining === 0}
          className="w-full mt-4 py-3 px-4 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-500 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {spinsRemaining > 0 ? (
            <>
              <RotateCw className="w-4 h-4" />
              <span>SPIN NOW ({spinsRemaining} LEFT)</span>
            </>
          ) : (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>ALL SPINS USED TODAY</span>
            </>
          )}
        </button>
      </div>

      {/* Task 2: Scratch Cards */}
      <div className="glass-card rounded-3xl p-5 border border-pink-500/25 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-pink-600/10 rounded-full blur-2xl pointer-events-none" />
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-600 via-purple-600 to-amber-500 p-0.5 shadow-lg shadow-pink-600/30 flex items-center justify-center">
              <div className="w-full h-full bg-[#1b0d26] rounded-[14px] flex items-center justify-center text-white">
                <CreditCard className="w-6 h-6 text-pink-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <h3 className="text-sm font-bold text-white">Scratch Cards</h3>
                <span className="text-base">🎟️</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {scratchesRemaining}/{dailyScratchLimit} Cards Available Today
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30">
            ₹1 to ₹20/Card
          </span>
        </div>

        {/* Progress bar */}
        <div className="mt-4">
          <div className="flex justify-between text-[10px] font-medium text-slate-400 mb-1.5">
            <span>Progress ({scratchesUsed}/{dailyScratchLimit} Scratched)</span>
            <span className="text-pink-400 font-bold">
              {Math.round((scratchesUsed / dailyScratchLimit) * 100)}%
            </span>
          </div>
          <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div
              className="h-full bg-gradient-to-r from-pink-500 to-amber-400 rounded-full transition-all duration-300"
              style={{ width: `${(scratchesUsed / dailyScratchLimit) * 100}%` }}
            />
          </div>
        </div>

        <button
          onClick={onOpenScratch}
          disabled={scratchesRemaining === 0}
          className="w-full mt-4 py-3 px-4 bg-gradient-to-r from-pink-600 via-purple-600 to-pink-500 hover:from-pink-500 hover:to-purple-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {scratchesRemaining > 0 ? (
            <>
              <CreditCard className="w-4 h-4" />
              <span>SCRATCH NOW ({scratchesRemaining} LEFT)</span>
            </>
          ) : (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>ALL SCRATCH CARDS USED TODAY</span>
            </>
          )}
        </button>
      </div>

      {/* Task 3: Story Watch */}
      <div className="glass-card rounded-3xl p-5 border border-emerald-500/25 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-600/10 rounded-full blur-2xl pointer-events-none" />
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-green-500 p-0.5 shadow-lg shadow-emerald-600/30 flex items-center justify-center">
              <div className="w-full h-full bg-[#0a1510] rounded-[14px] flex items-center justify-center text-white">
                <MessageCircle className="w-6 h-6 text-emerald-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <h3 className="text-sm font-bold text-white">WhatsApp Status Watch</h3>
                <span className="text-base">🎬</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {storiesRemaining} of {totalStoriesCount} Status Stories Available
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            ₹10/Status
          </span>
        </div>

        {/* Progress bar */}
        <div className="mt-4">
          <div className="flex justify-between text-[10px] font-medium text-slate-400 mb-1.5">
            <span>Progress ({storiesWatched}/{totalStoriesCount} Watched)</span>
            <span className="text-emerald-400 font-bold">
              {totalStoriesCount > 0 ? Math.round((storiesWatched / totalStoriesCount) * 100) : 100}%
            </span>
          </div>
          <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden p-0.5 border border-white/5">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300"
              style={{
                width: `${totalStoriesCount > 0 ? (storiesWatched / totalStoriesCount) * 100 : 100}%`
              }}
            />
          </div>
        </div>

        <button
          onClick={onOpenStories}
          disabled={storiesRemaining === 0}
          className="w-full mt-4 py-3 px-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {storiesRemaining > 0 ? (
            <>
              <Play className="w-4 h-4 ml-0.5" />
              <span>WATCH STATUS NOW ({storiesRemaining} LEFT)</span>
            </>
          ) : (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>ALL STATUS STORIES COMPLETED TODAY</span>
            </>
          )}
        </button>
      </div>

      {/* Rules Notice */}
      <div className="p-4 rounded-2xl bg-black/30 border border-white/5 text-slate-400 text-xs space-y-1.5">
        <div className="flex items-center space-x-1.5 text-amber-400 font-bold text-[11px]">
          <Gift className="w-3.5 h-3.5" />
          <span>Reward Rules & Conditions</span>
        </div>
        <p className="text-[11px] leading-relaxed">
          Daily tasks reset every night at 00:00 AM IST. All rewards are directly credited to your available balance upon full completion. No instant views or automated bot completion is permitted.
        </p>
      </div>
    </div>
  );
};
