import React, { useState, useEffect } from 'react';
import {
  Copy,
  Check,
  Share2,
  Users,
  Trophy,
  Sparkles,
  AlertCircle,
  MessageCircle,
  Clock,
  CheckCircle2,
  Gift
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { AppSettingsConfig, ReferralRecord } from '../../types';
import { getReferralStats } from '../../services/firestoreService';

interface ReferAndEarnProps {
  appSettings: AppSettingsConfig;
  referralCount: number;
  referralEarnings: number;
}

export const ReferAndEarn: React.FC<ReferAndEarnProps> = ({
  appSettings
}) => {
  const { userProfile, currentUser } = useAuth();
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<{
    totalCount: number;
    eligibleCount: number;
    pendingCount: number;
    earnings: number;
    referrals: ReferralRecord[];
  }>({
    totalCount: 0,
    eligibleCount: 0,
    pendingCount: 0,
    earnings: 0,
    referrals: []
  });

  const referralCode = userProfile?.referralCode || 'ARJ50X';
  const referralLink = `${window.location.origin}/?ref=${referralCode}`;
  const rewardAmount = appSettings.referralReward || 50;

  useEffect(() => {
    if (currentUser && userProfile) {
      setLoading(true);
      getReferralStats(currentUser.uid, referralCode).then((res) => {
        setStats(res);
        setLoading(false);
      });
    }
  }, [currentUser, userProfile, referralCode]);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const shareText = `Join ${appSettings.appName}! 🚀\nEarn daily rewards with Spin Wheel, Stories & Tasks. Get bonus rewards when you register!\nUse my referral code: ${referralCode}\nSign up here: ${referralLink}`;

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: appSettings.appName,
          text: shareText,
          url: referralLink
        });
      } catch {
        // user dismissed share dialog
      }
    } else {
      handleCopyLink();
    }
  };

  const handleShareWhatsApp = () => {
    const encoded = encodeURIComponent(shareText);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  return (
    <div className="space-y-5 pb-6">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl p-6 bg-gradient-to-br from-[#241a4a] via-[#15122e] to-[#0c0919] border border-amber-500/30 shadow-2xl">
        <div className="absolute top-0 right-0 w-44 h-44 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 text-center">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-xs font-bold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Referral Program</span>
          </div>
          <h2 className="text-2xl font-black text-white sm:text-3xl">
            Invite & Earn ₹{rewardAmount}
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xs mx-auto">
            Share your unique referral link. Earn ₹{rewardAmount} in your wallet for every friend who joins & completes tasks!
          </p>
        </div>
      </div>

      {/* 4 Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="glass-card rounded-2xl p-3.5 border border-purple-500/20 text-center">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
            Total Referrals
          </span>
          <span className="text-xl font-black text-white mt-1 block">
            {stats.totalCount}
          </span>
        </div>
        <div className="glass-card rounded-2xl p-3.5 border border-emerald-500/20 text-center">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
            Eligible Credited
          </span>
          <span className="text-xl font-black text-emerald-400 mt-1 block">
            {stats.eligibleCount}
          </span>
        </div>
        <div className="glass-card rounded-2xl p-3.5 border border-amber-500/20 text-center">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
            Pending Tasks
          </span>
          <span className="text-xl font-black text-amber-300 mt-1 block">
            {stats.pendingCount}
          </span>
        </div>
        <div className="glass-card rounded-2xl p-3.5 border border-amber-500/20 text-center">
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
            Total Earned
          </span>
          <span className="text-xl font-black text-amber-300 mt-1 block">
            ₹{stats.earnings.toFixed(2)}
          </span>
        </div>
      </div>

      {/* Referral Code Box */}
      <div className="glass-card rounded-3xl p-5 border border-purple-500/20 space-y-4">
        <div>
          <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-1.5">
            Your Unique Referral Code
          </label>
          <div className="flex items-center space-x-2">
            <div className="flex-1 bg-black/50 border border-purple-500/30 rounded-xl px-4 py-3 font-mono text-base font-extrabold text-amber-300 tracking-wider">
              {referralCode}
            </div>
            <button
              onClick={handleCopyCode}
              className="py-3 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs uppercase flex items-center space-x-1.5 transition-colors shadow-md"
            >
              {copiedCode ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              <span>{copiedCode ? 'COPIED' : 'COPY'}</span>
            </button>
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-1.5">
            Your Shareable Referral Link
          </label>
          <div className="flex items-center space-x-2">
            <div className="flex-1 bg-black/50 border border-purple-500/30 rounded-xl px-3.5 py-2.5 text-xs text-slate-300 truncate font-mono">
              {referralLink}
            </div>
            <button
              onClick={handleCopyLink}
              className="py-2.5 px-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 font-bold text-xs uppercase flex items-center space-x-1 transition-colors"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'COPIED' : 'COPY'}</span>
            </button>
          </div>
        </div>

        {/* Action Share Buttons */}
        <div className="grid grid-cols-2 gap-3 pt-2">
          <button
            onClick={handleShare}
            className="py-3 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-lg shadow-purple-600/30"
          >
            <Share2 className="w-4 h-4" />
            <span>SHARE LINK</span>
          </button>
          <button
            onClick={handleShareWhatsApp}
            className="py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center space-x-2 transition-all shadow-lg shadow-emerald-600/30"
          >
            <MessageCircle className="w-4 h-4" />
            <span>WHATSAPP</span>
          </button>
        </div>
      </div>

      {/* Referral History Passbook */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          Referral History ({stats.referrals.length})
        </h3>

        {stats.referrals.length === 0 ? (
          <div className="p-6 text-center glass-card rounded-2xl border border-white/5 text-slate-500 text-xs">
            No referrals registered yet. Share your link above to invite friends and start earning!
          </div>
        ) : (
          <div className="space-y-2">
            {stats.referrals.map((r) => (
              <div
                key={r.id}
                className="glass-card rounded-2xl p-3.5 border border-white/5 flex items-center justify-between"
              >
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                      r.status === 'credited'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-amber-500/20 text-amber-400'
                    }`}
                  >
                    {r.status === 'credited' ? <CheckCircle2 className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">{r.referredName || 'Invited Friend'}</h4>
                    <span className="text-[10px] text-slate-400">
                      {new Date(r.createdAt).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric'
                      })}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-black text-amber-300 block">
                    +₹{r.rewardAmount || rewardAmount}
                  </span>
                  <span
                    className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full inline-block mt-0.5 ${
                      r.status === 'credited'
                        ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-950/60 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    {r.status === 'credited' ? 'Credited to Wallet' : 'Pending Task Completion'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Rules & Transparency Notice */}
      <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-2 text-slate-400 text-xs">
        <div className="flex items-center space-x-2 text-amber-400 font-bold text-[11px]">
          <AlertCircle className="w-3.5 h-3.5" />
          <span>Referral Program Rules & Conditions</span>
        </div>
        <ul className="list-disc list-inside space-y-1 text-[11px] leading-relaxed text-slate-400">
          <li>Referral reward is configured at ₹{rewardAmount} per successful invitation.</li>
          <li>Reward is automatically credited to your wallet once your referred contact completes their initial eligible task.</li>
          <li>Self-referrals, clone accounts, and automated registrations are strictly blocked by fraud prevention algorithms.</li>
          <li>All referral bonuses are reflected directly in your wallet balance and passbook ledger.</li>
        </ul>
      </div>
    </div>
  );
};
