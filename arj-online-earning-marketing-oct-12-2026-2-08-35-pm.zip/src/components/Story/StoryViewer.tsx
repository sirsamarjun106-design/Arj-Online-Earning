import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  X,
  Play,
  Pause,
  ChevronRight,
  Trophy,
  CheckCircle2,
  Volume2,
  VolumeX,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { TaskItem } from '../../types';
import { claimStoryReward } from '../../services/firestoreService';
import { useAuth } from '../../context/AuthContext';

interface StoryViewerProps {
  isOpen: boolean;
  onClose: () => void;
  stories: TaskItem[];
  claimedStoryIds: string[];
  onRewardClaimed: () => void;
  initialIndex?: number;
}

export const StoryViewer: React.FC<StoryViewerProps> = ({
  isOpen,
  onClose,
  stories,
  claimedStoryIds,
  onRewardClaimed,
  initialIndex = 0
}) => {
  const { currentUser } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [progress, setProgress] = useState(0); // 0 to 100%
  const [isPaused, setIsPaused] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [hasClaimedCurrent, setHasClaimedCurrent] = useState(false);
  const [claiming, setClaiming] = useState(false);
  const [claimToast, setClaimToast] = useState<string | null>(null);
  const [errorToast, setErrorToast] = useState<string | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const holdTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const currentStory = stories[currentIndex] || null;
  const watchDuration = currentStory?.watchDuration || 8; // seconds

  useEffect(() => {
    if (initialIndex >= 0 && initialIndex < stories.length) {
      setCurrentIndex(initialIndex);
    }
  }, [initialIndex, stories.length]);

  // Check if current story is already claimed today
  useEffect(() => {
    if (currentStory) {
      setHasClaimedCurrent(claimedStoryIds.includes(currentStory.id));
      setProgress(0);
      setIsPaused(false);
      setClaiming(false);
      setErrorToast(null);
    }
  }, [currentIndex, currentStory, claimedStoryIds]);

  // Progression timer
  useEffect(() => {
    if (!isOpen || !currentStory || isPaused) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    const intervalMs = 100;
    const step = 100 / ((watchDuration * 1000) / intervalMs);

    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          if (timerRef.current) clearInterval(timerRef.current);
          handleStoryCompleted();
          return 100;
        }
        return prev + step;
      });
    }, intervalMs);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isOpen, currentIndex, isPaused, watchDuration, currentStory]);

  if (!isOpen || !currentStory) return null;

  const handleStoryCompleted = async () => {
    if (claiming) return;

    // Only process reward if not already claimed and user is authenticated
    if (!hasClaimedCurrent && currentUser && currentStory) {
      setClaiming(true);
      setIsPaused(true); // Pause while server validates reward
      const res = await claimStoryReward(currentUser.uid, currentStory.id);
      setClaiming(false);

      if (res.success) {
        setHasClaimedCurrent(true);
        setClaimToast(`🎉 Won ₹${res.rewardAmount}! Credited to wallet balance`);
        try {
          confetti({
            particleCount: 65,
            spread: 70,
            origin: { y: 0.7 }
          });
        } catch {
          // ignore
        }
        onRewardClaimed();
        setTimeout(() => setClaimToast(null), 3000);

        // Advance to next story only after confirmed credit
        setTimeout(() => {
          if (currentIndex < stories.length - 1) {
            setCurrentIndex((prev) => prev + 1);
          } else {
            onClose();
          }
        }, 1500);
      } else {
        setErrorToast(res.message);
        setTimeout(() => setErrorToast(null), 4000);
      }
    } else if (hasClaimedCurrent) {
      // If already claimed, smoothly advance
      setTimeout(() => {
        if (currentIndex < stories.length - 1) {
          setCurrentIndex((prev) => prev + 1);
        } else {
          onClose();
        }
      }, 1000);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      onClose();
    }
  };

  const handleTouchStart = () => {
    holdTimeoutRef.current = setTimeout(() => {
      setIsPaused(true);
    }, 150);
  };

  const handleTouchEnd = () => {
    if (holdTimeoutRef.current) clearTimeout(holdTimeoutRef.current);
    setIsPaused(false);
  };

  const remainingSeconds = Math.max(0, Math.ceil(watchDuration - (progress / 100) * watchDuration));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black select-none">
      {/* WhatsApp Status 9:16 Aspect Container */}
      <div className="relative w-full h-full max-w-md max-h-[920px] aspect-[9/16] bg-[#070707] overflow-hidden flex flex-col justify-between shadow-2xl">
        {/* Story Background Media (Image or Video) */}
        <div className="absolute inset-0 z-0">
          {currentStory.mediaType === 'video' ? (
            <video
              src={currentStory.mediaUrl}
              autoPlay
              muted={isMuted}
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <img
              src={currentStory.mediaUrl}
              alt={currentStory.title}
              className="w-full h-full object-cover"
            />
          )}
          {/* WhatsApp Status Vignette overlay */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-black/85 pointer-events-none" />
        </div>

        {/* Tap Interaction Zones (Left = Prev, Center = Hold to pause, Right = Next) */}
        <div className="absolute inset-0 z-10 flex">
          <div
            className="w-1/3 h-full cursor-pointer"
            onClick={handlePrev}
            onMouseDown={handleTouchStart}
            onMouseUp={handleTouchEnd}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
          />
          <div
            className="w-1/3 h-full cursor-pointer"
            onClick={() => setIsPaused(!isPaused)}
            onMouseDown={handleTouchStart}
            onMouseUp={handleTouchEnd}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
          />
          <div
            className="w-1/3 h-full cursor-pointer"
            onClick={handleNext}
            onMouseDown={handleTouchStart}
            onMouseUp={handleTouchEnd}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
          />
        </div>

        {/* WhatsApp Top Header Bar */}
        <div className="relative z-20 pt-3 px-3 pb-2 space-y-2.5">
          {/* Segmented Status Progress Bars */}
          <div className="flex items-center space-x-1.5 w-full px-1">
            {stories.map((s, idx) => {
              let fill = 0;
              if (idx < currentIndex) fill = 100;
              else if (idx === currentIndex) fill = progress;
              return (
                <div
                  key={s.id}
                  className="h-[2.5px] flex-1 bg-white/35 rounded-full overflow-hidden"
                >
                  <div
                    className="h-full bg-white rounded-full transition-all duration-100 ease-linear shadow-sm"
                    style={{ width: `${fill}%` }}
                  />
                </div>
              );
            })}
          </div>

          {/* User Status Profile Bar */}
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center space-x-2.5">
              <button
                onClick={onClose}
                className="p-1 text-white hover:text-slate-300 transition-colors"
                aria-label="Back"
              >
                <ArrowLeft className="w-5 h-5 drop-shadow" />
              </button>
              <div className="w-9 h-9 rounded-full ring-2 ring-emerald-400 ring-offset-1 ring-offset-black/50 p-0.5 overflow-hidden flex-shrink-0">
                <img
                  src={currentStory.thumbnailUrl || currentStory.mediaUrl}
                  alt="Story thumbnail"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <div>
                <div className="flex items-center space-x-1.5">
                  <h4 className="text-xs font-bold text-white drop-shadow truncate max-w-[150px]">
                    ARJ Official Status
                  </h4>
                  <span className="text-[10px] font-extrabold text-amber-300 bg-amber-400/20 px-1.5 py-0.2 rounded border border-amber-400/30">
                    +₹{currentStory.rewardAmount}
                  </span>
                </div>
                <p className="text-[10px] text-white/80 drop-shadow flex items-center space-x-1">
                  <span>Today, Just now</span>
                  <span>•</span>
                  <span>{currentIndex + 1} of {stories.length}</span>
                </p>
              </div>
            </div>

            {/* Top Right Controls */}
            <div className="flex items-center space-x-1 text-white/90">
              <button
                onClick={() => setIsPaused(!isPaused)}
                className="p-1.5 hover:text-white rounded-full bg-black/30 backdrop-blur-sm"
                aria-label="Pause"
              >
                {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
              </button>
              {currentStory.mediaType === 'video' && (
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-1.5 hover:text-white rounded-full bg-black/30 backdrop-blur-sm"
                  aria-label="Mute"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
              )}
              <button
                onClick={onClose}
                className="p-1.5 hover:text-white rounded-full bg-black/30 backdrop-blur-sm"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Claimed Toast Celebration */}
        {claimToast && (
          <div className="relative z-30 mx-4 bg-emerald-500/95 text-white font-bold text-xs p-3.5 rounded-2xl flex items-center justify-center space-x-2 shadow-xl backdrop-blur-md animate-bounce border border-emerald-400">
            <Trophy className="w-4 h-4 text-amber-200" />
            <span>{claimToast}</span>
          </div>
        )}

        {/* Error Toast */}
        {errorToast && (
          <div className="relative z-30 mx-4 bg-red-500/95 text-white font-bold text-xs p-3.5 rounded-2xl flex items-center justify-center space-x-2 shadow-xl backdrop-blur-md border border-red-400">
            <AlertCircle className="w-4 h-4 text-white" />
            <span>{errorToast}</span>
          </div>
        )}

        {/* Bottom Status Content & Reply Drawer */}
        <div className="relative z-20 p-4 space-y-3">
          <div className="text-center px-3 py-2">
            <h3 className="text-sm font-extrabold text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
              {currentStory.title}
            </h3>
            <p className="text-xs text-white/95 mt-1 leading-relaxed drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)] line-clamp-3">
              {currentStory.description}
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <div className="flex-1 bg-black/60 backdrop-blur-lg border border-white/20 rounded-full px-4 py-2.5 flex items-center justify-between text-xs text-slate-200 shadow-lg">
              <div className="flex items-center space-x-2">
                <span className="text-emerald-400 font-bold">Status Reward</span>
                <span className="text-white font-bold">₹{currentStory.rewardAmount}</span>
              </div>
              {hasClaimedCurrent ? (
                <span className="flex items-center space-x-1 text-emerald-400 font-bold text-[11px]">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Claimed</span>
                </span>
              ) : claiming ? (
                <span className="text-amber-300 font-bold text-[11px]">Verifying...</span>
              ) : (
                <span className="font-mono text-amber-300 font-bold text-[11px] bg-amber-400/20 px-2 py-0.5 rounded-full border border-amber-400/30">
                  {remainingSeconds}s left
                </span>
              )}
            </div>
            <button
              onClick={handleNext}
              className="w-10 h-10 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-lg transition-transform active:scale-95 flex-shrink-0"
              aria-label="Next Story"
            >
              <ChevronRight className="w-5 h-5 ml-0.5" />
            </button>
          </div>

          <div className="text-center text-[10px] text-white/60">
            Hold screen to pause • Tap left/right to navigate
          </div>
        </div>
      </div>
    </div>
  );
};
