import React, { useState } from 'react';
import {
  Wallet,
  ArrowUpRight,
  RotateCw,
  Play,
  Users,
  Gift,
  Clock,
  CheckCircle2,
  AlertCircle,
  Filter,
  ArrowDownLeft,
  Landmark,
  ArrowRight,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { WalletTransaction, TransactionType } from '../../types';

interface WalletPageProps {
  onOpenWithdraw: () => void;
  transactions: WalletTransaction[];
}

export const WalletPage: React.FC<WalletPageProps> = ({
  onOpenWithdraw,
  transactions
}) => {
  const { wallet } = useAuth();
  const [filterType, setFilterType] = useState<'all' | TransactionType>('all');

  const availableBalance = wallet?.availableBalance ?? 0;
  const pendingBalance = wallet?.pendingBalance ?? 0;
  const totalBalance = availableBalance + pendingBalance;
  const totalEarnings = wallet?.totalEarnings ?? 0;
  const taskEarnings = wallet?.taskEarnings ?? wallet?.storyEarnings ?? 0;
  const spinEarnings = wallet?.spinEarnings ?? 0;
  const referralEarnings = wallet?.referralEarnings ?? 0;
  const otherEarnings = wallet?.otherEarnings ?? 0;

  const filteredTransactions = transactions.filter((tx) => {
    if (filterType === 'all') return true;
    return tx.type === filterType;
  });

  return (
    <div className="space-y-5 pb-6">
      {/* 1. TOTAL BALANCE HERO CARD */}
      <div className="relative overflow-hidden rounded-3xl p-6 bg-gradient-to-br from-[#1e1742] via-[#120f28] to-[#0a0818] border border-purple-500/30 shadow-2xl">
        <div className="absolute top-0 right-0 w-52 h-52 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
              <span className="text-[11px] font-extrabold text-amber-300 uppercase tracking-widest">
                TOTAL WALLET BALANCE
              </span>
            </div>
            <span className="text-[10px] font-bold text-slate-400 bg-white/5 border border-white/10 px-2.5 py-0.5 rounded-full">
              Live Ledger
            </span>
          </div>

          <div className="py-1">
            <span className="text-4xl sm:text-5xl font-black tracking-tight bg-gradient-to-r from-amber-200 via-white to-purple-200 bg-clip-text text-transparent">
              ₹{totalBalance.toFixed(2)}
            </span>
            <div className="flex items-center space-x-2 mt-1.5 text-xs text-slate-300">
              <span className="text-emerald-400 font-bold">
                Available: ₹{availableBalance.toFixed(2)}
              </span>
              <span>•</span>
              <span className="text-amber-300/90 font-medium">
                Pending: ₹{pendingBalance.toFixed(2)}
              </span>
            </div>
          </div>

          {/* WITHDRAWAL BUTTON */}
          <button
            onClick={onOpenWithdraw}
            className="w-full py-4 px-6 bg-gradient-to-r from-amber-500 via-purple-600 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-white font-black text-sm uppercase tracking-wider rounded-2xl shadow-xl shadow-purple-950/60 transition-all flex items-center justify-center space-x-2.5 active:scale-[0.98] group"
          >
            <Landmark className="w-5 h-5 text-amber-300 group-hover:scale-110 transition-transform" />
            <span>WITHDRAW (INSTANT UPI)</span>
            <ArrowRight className="w-4 h-4 text-amber-200 ml-1 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      {/* 2. SUB-BALANCES ROW */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="bg-black/30 glass-card rounded-2xl p-3 border border-white/5 text-center">
          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block truncate">
            Withdrawable
          </span>
          <span className="text-sm font-black text-emerald-400 mt-0.5 block truncate">
            ₹{availableBalance.toFixed(2)}
          </span>
        </div>
        <div className="bg-black/30 glass-card rounded-2xl p-3 border border-white/5 text-center">
          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block truncate">
            Pending Approval
          </span>
          <span className="text-sm font-black text-amber-300 mt-0.5 block truncate">
            ₹{pendingBalance.toFixed(2)}
          </span>
        </div>
        <div className="bg-black/30 glass-card rounded-2xl p-3 border border-white/5 text-center">
          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block truncate">
            Total Earned
          </span>
          <span className="text-sm font-black text-purple-300 mt-0.5 block truncate">
            ₹{totalEarnings.toFixed(2)}
          </span>
        </div>
      </div>

      {/* 3. EARNINGS BREAKDOWN */}
      <div>
        <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
          Earnings Breakdown
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="glass-card rounded-2xl p-3.5 border border-purple-500/20">
            <div className="flex items-center space-x-2 text-purple-400 mb-2">
              <RotateCw className="w-4 h-4" />
              <span className="text-[11px] font-bold text-slate-200">Spin Daily</span>
            </div>
            <span className="text-lg font-black text-white">₹{spinEarnings.toFixed(2)}</span>
          </div>
          <div className="glass-card rounded-2xl p-3.5 border border-indigo-500/20">
            <div className="flex items-center space-x-2 text-indigo-400 mb-2">
              <Play className="w-4 h-4" />
              <span className="text-[11px] font-bold text-slate-200">Tasks & Stories</span>
            </div>
            <span className="text-lg font-black text-white">₹{taskEarnings.toFixed(2)}</span>
          </div>
          <div className="glass-card rounded-2xl p-3.5 border border-amber-500/20">
            <div className="flex items-center space-x-2 text-amber-400 mb-2">
              <Users className="w-4 h-4" />
              <span className="text-[11px] font-bold text-slate-200">Referrals</span>
            </div>
            <span className="text-lg font-black text-white">₹{referralEarnings.toFixed(2)}</span>
          </div>
          <div className="glass-card rounded-2xl p-3.5 border border-emerald-500/20">
            <div className="flex items-center space-x-2 text-emerald-400 mb-2">
              <Gift className="w-4 h-4" />
              <span className="text-[11px] font-bold text-slate-200">Bonuses & Adjustments</span>
            </div>
            <span className="text-lg font-black text-white">₹{otherEarnings.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* 4. TRANSACTION PASSBOOK */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Transaction Passbook ({filteredTransactions.length})
          </h3>
          <div className="flex items-center space-x-1 bg-black/40 p-1 rounded-xl border border-white/5 text-[10px]">
            {(['all', 'credit', 'withdrawal', 'adjustment'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setFilterType(t as any)}
                className={`px-2 py-1 rounded-lg font-bold capitalize transition-colors ${
                  filterType === t
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {filteredTransactions.length === 0 ? (
          <div className="text-center py-8 glass-card rounded-2xl border border-white/5 text-slate-500 text-xs">
            No transactions found yet. Complete tasks or spins to view your passbook history!
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredTransactions.map((tx) => {
              const isCredit = tx.type === 'credit';
              const isWithdrawal = tx.type === 'withdrawal';
              const isAdjustment = tx.type === 'adjustment';

              return (
                <div
                  key={tx.id}
                  className="glass-card rounded-2xl p-3.5 border border-white/5 flex items-center justify-between"
                >
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                        isCredit
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20'
                          : isWithdrawal
                          ? 'bg-amber-500/15 text-amber-400 border border-amber-500/20'
                          : 'bg-purple-500/15 text-purple-400 border border-purple-500/20'
                      }`}
                    >
                      {isCredit ? (
                        <ArrowDownLeft className="w-4 h-4" />
                      ) : (
                        <ArrowUpRight className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">{tx.source}</h4>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        {new Date(tx.timestamp).toLocaleString([], {
                          dateStyle: 'medium',
                          timeStyle: 'short'
                        })}
                      </p>
                      {tx.referenceId && (
                        <span className="text-[9px] font-mono text-slate-500 block">
                          Ref: {tx.referenceId.substring(0, 14)}...
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-sm font-black block ${
                        isCredit ? 'text-emerald-400' : 'text-slate-100'
                      }`}
                    >
                      {isCredit ? '+' : '-'}₹{tx.amount.toFixed(2)}
                    </span>
                    <span
                      className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full inline-block mt-0.5 ${
                        tx.status === 'completed'
                          ? 'bg-emerald-950/40 text-emerald-400 border border-emerald-500/20'
                          : tx.status === 'pending'
                          ? 'bg-amber-950/40 text-amber-400 border border-amber-500/20'
                          : 'bg-red-950/40 text-red-400 border border-red-500/20'
                      }`}
                    >
                      {tx.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
