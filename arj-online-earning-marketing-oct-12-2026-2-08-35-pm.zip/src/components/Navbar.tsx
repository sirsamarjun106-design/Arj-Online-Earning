import React from 'react';
import { Bell, Sparkles, ShieldCheck, Shield } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  onOpenNotifications: () => void;
  onOpenProfile: () => void;
  onOpenAdmin?: () => void;
  unreadCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenNotifications,
  onOpenProfile,
  onOpenAdmin,
  unreadCount = 1
}) => {
  const { userProfile, isAdmin } = useAuth();
  const userName = userProfile?.name?.split(' ')[0] || 'User';

  return (
    <header className="sticky top-0 z-30 w-full glass-panel border-b border-purple-900/20 px-4 py-3 sm:px-6">
      <div className="max-w-lg mx-auto flex items-center justify-between">
        {/* Brand & Greeting */}
        <div className="flex items-center space-x-3">
          <button
            onClick={onOpenProfile}
            className="relative flex-shrink-0 focus:outline-none focus:ring-2 focus:ring-purple-500 rounded-full"
            aria-label="Open profile"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 via-indigo-600 to-amber-500 p-0.5 shadow-md shadow-purple-900/30">
              <div className="w-full h-full bg-[#100e20] rounded-full flex items-center justify-center overflow-hidden">
                {userProfile?.avatarUrl ? (
                  <img src={userProfile.avatarUrl} alt={userName} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-sm font-bold text-amber-300">
                    {userName.charAt(0).toUpperCase()}
                  </span>
                )}
              </div>
            </div>
            {userProfile?.kycStatus === 'approved' && (
              <span className="absolute -bottom-0.5 -right-0.5 bg-emerald-500 text-black rounded-full p-0.5">
                <ShieldCheck className="w-2.5 h-2.5" />
              </span>
            )}
          </button>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="text-[11px] font-bold tracking-widest text-purple-400 uppercase">
                ARJ Marketing
              </span>
              <span className="inline-block w-1 h-1 rounded-full bg-amber-400" />
            </div>
            <h2 className="text-sm font-bold text-slate-100 flex items-center">
              <span>Hello, {userName}</span>
              {(userProfile?.isVerified === true || userProfile?.verified === true || isAdmin) && (
                <span
                  title="Verified Account"
                  className="inline-flex items-center justify-center w-3.5 h-3.5 rounded-full bg-[#1d9bf0] text-white shadow-xs ml-1 flex-shrink-0 select-none"
                  aria-label="Verified user"
                >
                  <svg
                    className="w-2 h-2"
                    viewBox="0 0 16 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M13.5 4.5L6.5 11.5L3 8"
                      stroke="#ffffff"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </span>
              )}
              <span className="ml-1 text-base">👋</span>
            </h2>
          </div>
        </div>

        {/* Right actions */}
        <div className="flex items-center space-x-2">
          {/* Admin shortcut button if admin */}
          {isAdmin && onOpenAdmin && (
            <button
              onClick={onOpenAdmin}
              className="flex items-center space-x-1 text-[10px] font-extrabold text-amber-300 bg-amber-500/20 border border-amber-400/40 px-2.5 py-1 rounded-full hover:bg-amber-500/30 transition-all shadow-sm"
              title="Admin Control Panel"
            >
              <Shield className="w-3 h-3 text-amber-400" />
              <span>ADMIN</span>
            </button>
          )}

          {/* Tagline Pill */}
          <div className="hidden xs:flex items-center space-x-1 text-[10px] font-semibold text-amber-400 bg-amber-400/10 border border-amber-400/20 px-2.5 py-1 rounded-full">
            <Sparkles className="w-3 h-3" />
            <span>Earn & Rewards</span>
          </div>

          {/* Notification Bell */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-slate-300 hover:text-white hover:bg-purple-950/40 hover:border-purple-500/30 transition-all focus:outline-none"
            aria-label="View notifications"
          >
            <Bell className="w-4.5 h-4.5" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-400 ring-2 ring-[#070710] animate-pulse" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
