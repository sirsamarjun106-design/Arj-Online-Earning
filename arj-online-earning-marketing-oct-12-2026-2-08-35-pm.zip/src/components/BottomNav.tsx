import React from 'react';
import { Home, Flame, Wallet, Users, User } from 'lucide-react';

export type NavTab = 'home' | 'earn' | 'wallet' | 'refer' | 'profile';

interface BottomNavProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'home' as NavTab, label: 'Home', icon: Home },
    { id: 'earn' as NavTab, label: 'Earn', icon: Flame },
    { id: 'wallet' as NavTab, label: 'Wallet', icon: Wallet },
    { id: 'refer' as NavTab, label: 'Refer', icon: Users },
    { id: 'profile' as NavTab, label: 'Profile', icon: User }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#090814]/90 backdrop-blur-xl border-t border-purple-900/30 px-3 py-2 pb-safe">
      <div className="max-w-lg mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all duration-200 select-none ${
                isActive ? 'text-amber-300' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {isActive && (
                <div className="absolute inset-0 bg-gradient-to-t from-purple-950/60 to-purple-800/20 rounded-2xl border border-purple-500/30 -z-10 animate-fade-in" />
              )}
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive ? 'scale-110 text-amber-300 drop-shadow-[0_0_8px_rgba(253,224,71,0.5)]' : ''
                  }`}
                />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-amber-400" />
                )}
              </div>
              <span
                className={`text-[10px] mt-1 font-semibold transition-colors duration-200 ${
                  isActive ? 'text-amber-300 font-bold' : 'text-slate-400'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
