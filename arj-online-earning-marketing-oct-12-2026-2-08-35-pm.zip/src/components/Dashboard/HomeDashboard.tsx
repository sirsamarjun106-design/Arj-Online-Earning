import React from 'react';
import {
  Sparkles,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCw,
  Users,
  Wallet,
  Landmark,
  ShieldCheck,
  ChevronRight,
  Gift,
  Award,
  CreditCard
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { AppSettingsConfig, PaymentSettingsConfig } from '../../types';
import { DailyCheckInCard } from './DailyCheckInCard';

interface HomeDashboardProps {
  onCheckInCompleted?: (rewardAmount: number, newStreak: number) => void;
  onOpenSpin: () => void;
  onOpenScratch: () => void;
  onOpenStories: () => void;
  onOpenRefer: () => void;
  onOpenWallet: () => void;
  onOpenWithdraw: () => void;
  onOpenKyc: () => void;
  appSettings: AppSettingsConfig;
  paymentSettings: PaymentSettingsConfig;
  spinsRemaining: number;
  scratchesRemaining?: number;
  storiesRemaining: number;
  todayEarnings: number;
  referralCount?: number;
  referralPendingCount?: number;
  referralEarnings?: number;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onOpenSpin,
  onOpenScratch,
  onOpenStories,
  onOpenRefer,
  onOpenWallet,
  onOpenWithdraw,
  onOpenKyc,
  appSettings,
  paymentSettings,
  spinsRemaining,
  scratchesRemaining = 5,
  storiesRemaining,
  todayEarnings,
  referralCount = 0,
  referralPendingCount = 0,
  referralEarnings = 0,
  onCheckInCompleted
}) => {
  const { userProfile, wallet } = useAuth();
  const availableBalance = wallet?.availableBalance ?? 0;
  const pendingBalance = wallet?.pendingBalance ?? 0;
  const totalBalance = availableBalance + pendingBalance;
  const taskEarnings = wallet?.taskEarnings ?? wallet?.storyEarnings ?? 0;
  const tasksCompletedCount = userProfile?.tasksCompletedCount ?? 0;

  return (
    <div className="space-y-4 pb-6">
      {/* 1. Main Hero Wallet Balance Card */}
      <div className="relative overflow-hidden rounded-3xl p-5 sm:p-6 bg-gradient-to-br from-[#1b1539] via-[#120f26] to-[#0a0817] border border-purple-500/25 shadow-2xl shadow-purple-950/50">
        <div className="absolute top-0 right-0 w-44 h-44 bg-purple-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[11px] font-bold tracking-wider text-slate-300 uppercase">
                Available Balance
              </span>
            </div>
            <button
              onClick={onOpenWithdraw}
              className="flex items-center space-x-1 text-[11px] font-bold text-amber-300 hover:text-amber-200 bg-amber-400/10 hover:bg-amber-400/20 px-3 py-1 rounded-full border border-amber-400/30 transition-all active:scale-95"
            >
              <span>Withdraw</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-baseline space-x-1">
            <span className="text-3xl sm:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-amber-200 via-white to-purple-200 bg-clip-text text-transparent">
              ₹{availableBalance.toFixed(2)}
            </span>
          </div>

          {/* Sub Stats Row */}
          <div className="grid grid-cols-2 gap-3 mt-4 pt-3.5 border-t border-white/10">
            <div className="bg-black/25 rounded-2xl p-2.5 border border-white/5">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Today's Earning
              </span>
              <span className="text-sm sm:text-base font-bold text-emerald-400 mt-0.5 block">
                ₹{todayEarnings.toFixed(2)}
              </span>
            </div>
            <div className="bg-black/25 rounded-2xl p-2.5 border border-white/5">
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Pending Approval
              </span>
              <span className="text-sm sm:text-base font-bold text-amber-300 mt-0.5 block">
                ₹{pendingBalance.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. User Performance Summary Dashboard Cards (Task & Referral stats) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="glass-card rounded-2xl p-3 border border-indigo-500/20 text-center">
          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
            Task Earnings
          </span>
          <span className="text-sm sm:text-base font-black text-indigo-300 mt-0.5 block">
            ₹{taskEarnings.toFixed(2)}
          </span>
          <span className="text-[9px] text-slate-500 mt-0.5 block">
            {tasksCompletedCount} Tasks Done
          </span>
        </div>

        <div className="glass-card rounded-2xl p-3 border border-amber-500/20 text-center">
          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
            Referral Earnings
          </span>
          <span className="text-sm sm:text-base font-black text-amber-300 mt-0.5 block">
            ₹{referralEarnings.toFixed(2)}
          </span>
          <span className="text-[9px] text-slate-500 mt-0.5 block">
            {referralCount} Invites
          </span>
        </div>

        <div className="glass-card rounded-2xl p-3 border border-purple-500/20 text-center">
          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
            Pending Tasks
          </span>
          <span className="text-sm sm:text-base font-black text-purple-300 mt-0.5 block">
            {storiesRemaining + spinsRemaining}
          </span>
          <span className="text-[9px] text-slate-500 mt-0.5 block">
            Tasks Available
          </span>
        </div>

        <div className="glass-card rounded-2xl p-3 border border-emerald-500/20 text-center">
          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
            Pending Referrals
          </span>
          <span className="text-sm sm:text-base font-black text-emerald-400 mt-0.5 block">
            {referralPendingCount}
          </span>
          <span className="text-[9px] text-slate-500 mt-0.5 block">
            Awaiting Tasks
          </span>
        </div>
      </div>

      {/* 3. Daily Check-in & Consecutive Streak Card */}
      <DailyCheckInCard onCheckInCompleted={onCheckInCompleted} />

      {/* 4. Official Earning Tagline Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-purple-900/40 via-indigo-900/40 to-slate-900/40 border border-purple-500/20 p-3.5 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-purple-600 flex items-center justify-center text-white shadow-md">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white tracking-wide">
              {appSettings.appName}
            </h3>
            <p className="text-[10px] text-amber-300 font-medium">
              Earn • Watch • Refer • Rewards
            </p>
          </div>
        </div>
        <span className="text-[9px] font-bold uppercase tracking-wider bg-white/10 text-slate-300 px-2.5 py-1 rounded-full border border-white/10">
          Instant UPI
        </span>
      </div>

      {/* 4. Main Feature Action Cards (6 Cards) */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-1">
          <h3 className="text-xs font-bold tracking-wider text-slate-300 uppercase">
            Quick Actions
          </h3>
          <span className="text-[10px] text-purple-400 font-medium">Daily Tasks & Tools</span>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:gap-3.5">
          {/* 1. Spin Daily */}
          <button
            onClick={onOpenSpin}
            className="group relative text-left p-4 rounded-2xl glass-card border border-purple-500/20 hover:border-purple-400/50 transition-all duration-200 overflow-hidden"
          >
            <div className="absolute top-2.5 right-2.5 text-[9px] font-bold text-purple-300 bg-purple-500/20 px-2 py-0.5 rounded-full">
              {spinsRemaining}/{appSettings.dailySpinLimit} Left
            </div>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 to-pink-600 flex items-center justify-center text-white mb-3 shadow-lg shadow-purple-600/30 group-hover:scale-105 transition-transform">
              <RotateCw className="w-5 h-5 group-hover:rotate-45 transition-transform" />
            </div>
            <h4 className="text-xs font-bold text-slate-100 flex items-center">
              Spin Daily <span className="ml-1 text-sm">🎯</span>
            </h4>
            <p className="text-[10px] text-slate-400 mt-0.5">Win ₹1 to ₹20 per spin</p>
          </button>

          {/* 2. Scratch Cards */}
          <button
            onClick={onOpenScratch}
            className="group relative text-left p-4 rounded-2xl glass-card border border-pink-500/25 hover:border-pink-400/50 transition-all duration-200 overflow-hidden"
          >
            <div className="absolute top-2.5 right-2.5 text-[9px] font-bold text-pink-300 bg-pink-500/20 px-2 py-0.5 rounded-full">
              {scratchesRemaining}/{appSettings.dailyScratchLimit || 5} Left
            </div>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-600 via-purple-600 to-amber-500 flex items-center justify-center text-white mb-3 shadow-lg shadow-pink-600/30 group-hover:scale-105 transition-transform">
              <CreditCard className="w-5 h-5 group-hover:scale-110 transition-transform" />
            </div>
            <h4 className="text-xs font-bold text-slate-100 flex items-center">
              Scratch Cards <span className="ml-1 text-sm">🎟️</span>
            </h4>
            <p className="text-[10px] text-slate-400 mt-0.5">Win ₹1 to ₹20 instantly</p>
          </button>

          {/* 3. Story Watch */}
          <button
            onClick={onOpenStories}
            className="group relative text-left p-4 rounded-2xl glass-card border border-indigo-500/20 hover:border-indigo-400/50 transition-all duration-200 overflow-hidden"
          >
            <div className="absolute top-2.5 right-2.5 text-[9px] font-bold text-indigo-300 bg-indigo-500/20 px-2 py-0.5 rounded-full">
              {storiesRemaining} Left
            </div>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-600 flex items-center justify-center text-white mb-3 shadow-lg shadow-indigo-600/30 group-hover:scale-105 transition-transform">
              <Play className="w-5 h-5 ml-0.5 group-hover:scale-110 transition-transform" />
            </div>
            <h4 className="text-xs font-bold text-slate-100 flex items-center">
              Story Watch <span className="ml-1 text-sm">🎬</span>
            </h4>
            <p className="text-[10px] text-slate-400 mt-0.5">Earn ₹10 per completed story</p>
          </button>

          {/* 3. Refer & Earn */}
          <button
            onClick={onOpenRefer}
            className="group text-left p-4 rounded-2xl glass-card border border-amber-500/20 hover:border-amber-400/50 transition-all duration-200"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-600 flex items-center justify-center text-white mb-3 shadow-lg shadow-amber-600/30 group-hover:scale-105 transition-transform">
              <Users className="w-5 h-5" />
            </div>
            <h4 className="text-xs font-bold text-slate-100 flex items-center">
              Refer & Earn <span className="ml-1 text-sm">👥</span>
            </h4>
            <p className="text-[10px] text-slate-400 mt-0.5">Earn ₹{appSettings.referralReward} per referral</p>
          </button>

          {/* 4. Wallet */}
          <button
            onClick={onOpenWallet}
            className="group text-left p-4 rounded-2xl glass-card border border-emerald-500/20 hover:border-emerald-400/50 transition-all duration-200"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-600 flex items-center justify-center text-white mb-3 shadow-lg shadow-emerald-600/30 group-hover:scale-105 transition-transform">
              <Wallet className="w-5 h-5" />
            </div>
            <h4 className="text-xs font-bold text-slate-100 flex items-center">
              Wallet <span className="ml-1 text-sm">💳</span>
            </h4>
            <p className="text-[10px] text-slate-400 mt-0.5">View balance & passbook</p>
          </button>

          {/* 5. Withdraw */}
          <button
            onClick={onOpenWithdraw}
            className="group text-left p-4 rounded-2xl glass-card border border-blue-500/20 hover:border-blue-400/50 transition-all duration-200"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-600 flex items-center justify-center text-white mb-3 shadow-lg shadow-blue-600/30 group-hover:scale-105 transition-transform">
              <Landmark className="w-5 h-5" />
            </div>
            <h4 className="text-xs font-bold text-slate-100 flex items-center">
              Withdraw <span className="ml-1 text-sm">⚡</span>
            </h4>
            <p className="text-[10px] text-slate-400 mt-0.5">Min ₹{appSettings.minimumWithdrawal} via UPI</p>
          </button>

          {/* 6. KYC */}
          <button
            onClick={onOpenWithdraw}
            className="group text-left p-4 rounded-2xl glass-card border border-violet-500/20 hover:border-violet-400/50 transition-all duration-200"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-violet-600 to-purple-800 flex items-center justify-center text-white mb-3 shadow-lg shadow-violet-600/30 group-hover:scale-105 transition-transform">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="text-xs font-bold text-slate-100 flex items-center">
              KYC <span className="ml-1 text-sm">🔒</span>
            </h4>
            <p className="text-[10px] text-slate-400 mt-0.5">
              {userProfile?.kycStatus === 'approved' ? (
                <span className="text-emerald-400 font-semibold">VERIFIED</span>
              ) : (
                <span>Unlocked on Withdrawal</span>
              )}
            </p>
          </button>
        </div>
      </div>
    </div>
  );
};
