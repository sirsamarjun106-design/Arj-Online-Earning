import React, { useState, useEffect } from 'react';
import {
  Flame,
  Sparkles,
  CheckCircle2,
  Clock,
  Gift,
  Coins,
  Crown,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useAuth } from '../../context/AuthContext';
import { CheckInStatus } from '../../types';
import { getUserCheckInStatus, claimDailyCheckIn, DAILY_CHECKIN_REWARDS } from '../../services/firestoreService';

interface DailyCheckInCardProps {
  onCheckInCompleted?: (rewardAmount: number, newStreak: number) => void;
}

export const DailyCheckInCard: React.FC<DailyCheckInCardProps> = ({ onCheckInCompleted }) => {
  const { currentUser } = useAuth();
  const [status, setStatus] = useState<CheckInStatus>({
    streak: 0,
    lastCheckInDate: null,
    canCheckInToday: true,
    todayRewardAmount: DAILY_CHECKIN_REWARDS[0],
    nextStreakDay: 1,
    totalCheckIns: 0,
    streakRewards: DAILY_CHECKIN_REWARDS
  });
  const [claiming, setClaiming] = useState(false);
  const [timeUntilMidnight, setTimeUntilMidnight] = useState('');
  const [claimedRewardPopup, setClaimedRewardPopup] = useState<{ amount: number; streak: number } | null>(null);

  // Load check-in status
  const loadStatus = async () => {
    if (!currentUser?.uid) return;
    try {
      const res = await getUserCheckInStatus(currentUser.uid);
      setStatus(res);
    } catch (err) {
      console.warn('Failed to fetch check-in status:', err);
    }
  };

  useEffect(() => {
    loadStatus();
  }, [currentUser?.uid]);

  // Midnight countdown timer
  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0);

      const diffMs = tomorrow.getTime() - now.getTime();
      if (diffMs <= 0) {
        setTimeUntilMidnight('00h 00m');
        loadStatus();
        return;
      }

      const hours = Math.floor(diffMs / (1000 * 60 * 60));
      const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);
      setTimeUntilMidnight(
        `${String(hours).padStart(2, '0')}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`
      );
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [currentUser?.uid]);

  const handleClaim = async () => {
    if (!currentUser?.uid || !status.canCheckInToday || claiming) return;

    setClaiming(true);
    try {
      const res = await claimDailyCheckIn(currentUser.uid);
      if (res.success) {
        // Trigger celebratory confetti
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#a855f7', '#ec4899', '#f59e0b', '#10b981', '#3b82f6']
        });

        setClaimedRewardPopup({ amount: res.rewardAmount, streak: res.newStreak });
        if (onCheckInCompleted) {
          onCheckInCompleted(res.rewardAmount, res.newStreak);
        }
        await loadStatus();
      }
    } catch (err) {
      console.error('Error claiming check-in:', err);
    } finally {
      setClaiming(false);
    }
  };

  const rewards = status.streakRewards && status.streakRewards.length === 7
    ? status.streakRewards
    : DAILY_CHECKIN_REWARDS;

  const currentStreak = status.streak || 0;
  const cycleDayClaimed = !status.canCheckInToday ? ((currentStreak - 1) % 7) + 1 : 0;
  const cycleDayToClaim = status.canCheckInToday ? (status.nextStreakDay || ((currentStreak % 7) + 1)) : 0;

  return (
    <div className="relative overflow-hidden rounded-3xl p-4 sm:p-5 bg-gradient-to-br from-[#1c143d] via-[#130f2c] to-[#0c0a1a] border border-purple-500/30 shadow-xl shadow-purple-950/40">
      {/* Background Glows */}
      <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-36 h-36 bg-purple-500/15 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="relative z-10 flex items-center justify-between mb-3.5">
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-lg shadow-orange-500/30">
            <Flame className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <h3 className="text-sm font-extrabold text-white tracking-wide">
                Daily Check-in
              </h3>
              <span className="text-[10px] font-bold text-amber-400 bg-amber-400/15 border border-amber-400/30 px-2 py-0.5 rounded-full">
                {currentStreak > 0 ? `${currentStreak} Day Streak 🔥` : 'Start Streak'}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              Check in 7 days in a row for the ₹10 Jackpot!
            </p>
          </div>
        </div>

        {/* Small stats pill */}
        <div className="text-right">
          <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-semibold">
            Total Claimed
          </span>
          <span className="text-xs font-black text-amber-300">
            {status.totalCheckIns || 0} Days
          </span>
        </div>
      </div>

      {/* 7-Day Progress Track Grid */}
      <div className="relative z-10 grid grid-cols-7 gap-1.5 sm:gap-2 mb-4">
        {rewards.map((reward, idx) => {
          const dayNumber = idx + 1;
          const isDay7 = dayNumber === 7;

          // Determine day status
          let isCompleted = false;
          let isCurrentTarget = false;

          if (!status.canCheckInToday) {
            // Checked in today already
            if (dayNumber <= cycleDayClaimed) {
              isCompleted = true;
            }
          } else {
            // Can check in today
            if (dayNumber < cycleDayToClaim) {
              isCompleted = true;
            } else if (dayNumber === cycleDayToClaim) {
              isCurrentTarget = true;
            }
          }

          return (
            <div
              key={dayNumber}
              className={`relative flex flex-col items-center justify-between p-2 rounded-2xl transition-all duration-200 border ${
                isCurrentTarget
                  ? 'bg-gradient-to-b from-purple-600/30 to-amber-500/20 border-amber-400 shadow-lg shadow-amber-500/20 scale-105 z-10 ring-2 ring-amber-400/50'
                  : isCompleted
                  ? 'bg-emerald-950/30 border-emerald-500/40 opacity-90'
                  : 'bg-black/30 border-white/5 opacity-60'
              }`}
            >
              {/* Day label */}
              <span className={`text-[9px] font-bold uppercase tracking-wider ${
                isCurrentTarget ? 'text-amber-300' : isCompleted ? 'text-emerald-400' : 'text-slate-400'
              }`}>
                D{dayNumber}
              </span>

              {/* Icon / Indicator */}
              <div className="my-1.5">
                {isCompleted ? (
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-emerald-400">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                ) : isCurrentTarget ? (
                  <div className="w-6 h-6 rounded-full bg-amber-400/20 border border-amber-400 flex items-center justify-center text-amber-300 animate-bounce">
                    {isDay7 ? <Crown className="w-3.5 h-3.5 text-amber-400" /> : <Coins className="w-3.5 h-3.5" />}
                  </div>
                ) : isDay7 ? (
                  <div className="w-6 h-6 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-500/60">
                    <Crown className="w-3.5 h-3.5" />
                  </div>
                ) : (
                  <div className="w-6 h-6 rounded-full bg-white/5 flex items-center justify-center text-slate-500">
                    <Gift className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>

              {/* Reward text */}
              <span className={`text-[11px] font-black tracking-tight ${
                isCurrentTarget
                  ? 'text-amber-200'
                  : isCompleted
                  ? 'text-emerald-300'
                  : isDay7
                  ? 'text-amber-400'
                  : 'text-slate-300'
              }`}>
                ₹{reward}
              </span>

              {/* Tag */}
              {isDay7 && (
                <span className="absolute -top-1.5 -right-1 bg-amber-400 text-black text-[7px] font-black px-1 rounded-full uppercase">
                  MAX
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* Action Area */}
      <div className="relative z-10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-1 border-t border-white/5">
        <div className="flex items-center space-x-2 text-xs">
          <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="text-[10px] text-slate-400">
            {status.canCheckInToday ? (
              <span className="text-amber-300 font-medium">Claim today's reward before midnight!</span>
            ) : (
              <span>
                Next check-in opens in <strong className="text-slate-200">{timeUntilMidnight}</strong>
              </span>
            )}
          </span>
        </div>

        <div>
          {status.canCheckInToday ? (
            <button
              onClick={handleClaim}
              disabled={claiming}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider text-black bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-400 hover:from-amber-200 hover:to-yellow-300 active:scale-95 transition-all shadow-lg shadow-amber-500/30 flex items-center justify-center space-x-1.5 cursor-pointer disabled:opacity-50"
            >
              {claiming ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  <span>Claiming...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>
                    Claim Day {cycleDayToClaim} Bonus • ₹{status.todayRewardAmount}
                  </span>
                </>
              )}
            </button>
          ) : (
            <div className="w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center space-x-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Checked In Today ✓ (+₹{status.todayRewardAmount})</span>
            </div>
          )}
        </div>
      </div>

      {/* Claimed Reward Modal / Toast overlay */}
      {claimedRewardPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="relative max-w-sm w-full bg-gradient-to-b from-[#231a4c] to-[#120d28] border-2 border-amber-400/80 rounded-3xl p-6 text-center shadow-2xl shadow-purple-900/60">
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-400 to-orange-500 mx-auto flex items-center justify-center text-white mb-4 shadow-xl shadow-amber-500/40">
              <Flame className="w-9 h-9 animate-pulse" />
            </div>

            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-widest block">
              Streak Bonus Claimed!
            </span>
            <h4 className="text-2xl font-black text-white mt-1">
              +₹{claimedRewardPopup.amount.toFixed(2)}
            </h4>
            <p className="text-xs text-slate-300 mt-2">
              Credited directly to your available balance. You are now on a{' '}
              <strong className="text-amber-300">{claimedRewardPopup.streak} Day Streak</strong>!
            </p>

            <button
              onClick={() => setClaimedRewardPopup(null)}
              className="mt-5 w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 text-black font-extrabold text-xs uppercase tracking-wider hover:opacity-95 active:scale-95 transition-all shadow-lg shadow-amber-500/30 cursor-pointer"
            >
              Awesome!
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
