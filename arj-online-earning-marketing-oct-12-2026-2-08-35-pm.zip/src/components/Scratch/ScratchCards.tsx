import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  X,
  Sparkles,
  Trophy,
  Coins,
  RotateCw,
  Gift,
  AlertCircle,
  CheckCircle2,
  Volume2,
  VolumeX,
  CreditCard,
  Flame,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { AppSettingsConfig } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  getUserScratchStatus,
  generateScratchCard,
  claimScratchCardReward
} from '../../services/firestoreService';

interface ScratchCardsProps {
  isOpen: boolean;
  onClose: () => void;
  appSettings: AppSettingsConfig;
  onRewardClaimed?: () => void;
}

export const ScratchCards: React.FC<ScratchCardsProps> = ({
  isOpen,
  onClose,
  appSettings,
  onRewardClaimed
}) => {
  const { currentUser, wallet } = useAuth();

  // Status state
  const [loading, setLoading] = useState(false);
  const [cardLoading, setCardLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Scratch card session state
  const [scratchesRemaining, setScratchesRemaining] = useState(appSettings.dailyScratchLimit || 5);
  const [dailyLimit, setDailyLimit] = useState(appSettings.dailyScratchLimit || 5);
  const [scratchHistory, setScratchHistory] = useState<any[]>([]);

  // Active Card State
  const [currentCardId, setCurrentCardId] = useState<string | null>(null);
  const [currentReward, setCurrentReward] = useState<number | null>(null);
  const [isScratching, setIsScratching] = useState(false);
  const [scratchPercent, setScratchPercent] = useState(0);
  const [isClaimed, setIsClaimed] = useState(false);
  const [isClaiming, setIsClaiming] = useState(false);

  // Win modal
  const [showWinModal, setShowWinModal] = useState(false);
  const [wonAmount, setWonAmount] = useState<number | null>(null);

  // Countdown timer to midnight
  const [resetCountdown, setResetCountdown] = useState('');

  // Refs for scratch canvas
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDrawingRef = useRef(false);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Play audio
  const playSound = (type: 'scratch' | 'win') => {
    if (!soundEnabled) return;
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioCtx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      if (type === 'scratch') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(250 + Math.random() * 100, ctx.currentTime);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.04);
      } else if (type === 'win') {
        const notes = [440, 554.37, 659.25, 880];
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.1);
          gain.gain.setValueAtTime(0.2, ctx.currentTime + idx * 0.1);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.1 + 0.35);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(ctx.currentTime + idx * 0.1);
          osc.stop(ctx.currentTime + idx * 0.1 + 0.35);
        });
      }
    } catch {
      // Audio not supported
    }
  };

  // Update countdown to midnight IST
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      const diff = tomorrow.getTime() - now.getTime();
      const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const m = Math.floor((diff / 1000 / 60) % 60);
      const s = Math.floor((diff / 1000) % 60);
      setResetCountdown(
        `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Fetch status on open
  const loadStatus = useCallback(async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const status = await getUserScratchStatus(currentUser.uid);
      setDailyLimit(status.dailyLimit || appSettings.dailyScratchLimit || 5);
      setScratchesRemaining(status.scratchesRemaining);
      setScratchHistory(status.history || []);
    } catch (err) {
      console.error('Failed to load scratch status:', err);
    } finally {
      setLoading(false);
    }
  }, [currentUser, appSettings.dailyScratchLimit]);

  useEffect(() => {
    if (isOpen) {
      loadStatus();
    }
  }, [isOpen, loadStatus]);

  // Request a new scratch card session from server
  const requestNewCard = async () => {
    if (!currentUser || scratchesRemaining <= 0 || cardLoading) return;
    setErrorMsg(null);
    setCardLoading(true);
    setIsClaimed(false);
    setScratchPercent(0);
    setCurrentCardId(null);
    setCurrentReward(null);

    const res = await generateScratchCard(currentUser.uid);
    setCardLoading(false);

    if (res.success && res.cardId && res.rewardAmount) {
      setCurrentCardId(res.cardId);
      setCurrentReward(res.rewardAmount);
      if (res.scratchesRemaining !== undefined) {
        setScratchesRemaining(res.scratchesRemaining);
      }
    } else {
      setErrorMsg(res.error || 'Unable to generate scratch card. Please try again.');
    }
  };

  // Draw scratch canvas overlay
  const setupCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 2;
    const width = 280;
    const height = 180;

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    ctx.scale(dpr, dpr);

    // 1. Base Silver-Gold Metallic Holographic Gradient
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#3b2d54');
    grad.addColorStop(0.2, '#6d28d9');
    grad.addColorStop(0.5, '#4c1d95');
    grad.addColorStop(0.8, '#581c87');
    grad.addColorStop(1, '#2e1065');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // 2. Metallic shimmer stripes
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 12;
    for (let i = -width; i < width * 2; i += 32) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i + 90, height);
      ctx.stroke();
    }

    // 3. Golden decorative border inside scratch layer
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(10, 10, width - 20, height - 20);

    // 4. Subtle corner stars
    ctx.fillStyle = '#fbbf24';
    ctx.font = '12px sans-serif';
    ctx.fillText('★', 16, 26);
    ctx.fillText('★', width - 26, 26);
    ctx.fillText('★', 16, height - 16);
    ctx.fillText('★', width - 26, height - 16);

    // 5. Centered Callout Text: "SCRATCH HERE TO WIN"
    ctx.fillStyle = '#fbbf24';
    ctx.font = 'bold 15px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
    ctx.shadowBlur = 5;
    ctx.fillText('SCRATCH TO REVEAL', width / 2, height / 2 - 12);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 11px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText('Win ₹1 to ₹20 Instantly 🎟️', width / 2, height / 2 + 10);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.font = '9px "Plus Jakarta Sans", system-ui, sans-serif';
    ctx.fillText('Scratch at least 50% with finger or mouse', width / 2, height / 2 + 30);
  }, []);

  useEffect(() => {
    if (currentCardId && currentReward !== null) {
      setupCanvas();
    }
  }, [currentCardId, currentReward, setupCanvas]);

  // Calculate scratched area percentage
  const checkScratchPercentage = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return 0;
    const ctx = canvas.getContext('2d');
    if (!ctx) return 0;

    const dpr = window.devicePixelRatio || 2;
    const width = 280 * dpr;
    const height = 180 * dpr;

    try {
      // Sample every 4th pixel for high performance
      const imgData = ctx.getImageData(0, 0, width, height);
      const pixels = imgData.data;
      let transparentCount = 0;
      const totalSampled = pixels.length / 16; // sample every 4th pixel (4 bytes per pixel)

      for (let i = 3; i < pixels.length; i += 16) {
        if (pixels[i] < 128) {
          transparentCount++;
        }
      }

      const percent = Math.min(100, Math.round((transparentCount / totalSampled) * 100));
      return percent;
    } catch {
      return 0;
    }
  }, []);

  // Claim reward when >= 50% scratched
  const handleRewardClaim = useCallback(
    async (percent: number) => {
      if (!currentUser || !currentCardId || isClaimed || isClaiming) return;
      setIsClaiming(true);

      const res = await claimScratchCardReward(currentUser.uid, currentCardId, percent);
      setIsClaiming(false);

      if (res.success) {
        setIsClaimed(true);
        setWonAmount(res.rewardAmount ?? currentReward ?? 0);
        setShowWinModal(true);
        playSound('win');

        try {
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 }
          });
        } catch {}

        loadStatus();
        if (onRewardClaimed) onRewardClaimed();
      } else {
        setErrorMsg(res.error || 'Failed to claim reward. Please scratch further.');
      }
    },
    [currentUser, currentCardId, isClaimed, isClaiming, currentReward, loadStatus, onRewardClaimed]
  );

  // Scratch Drawing Handlers (touch & mouse)
  const getCanvasCoords = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    let clientX = 0;
    let clientY = 0;

    if ('touches' in e && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('clientX' in e) {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }

    return {
      x: clientX - rect.left,
      y: clientY - rect.top
    };
  };

  const scratchAtPoint = (x: number, y: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.globalCompositeOperation = 'destination-out';
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = 36;

    if (lastPointRef.current) {
      ctx.beginPath();
      ctx.moveTo(lastPointRef.current.x, lastPointRef.current.y);
      ctx.lineTo(x, y);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.arc(x, y, 18, 0, Math.PI * 2);
      ctx.fill();
    }

    lastPointRef.current = { x, y };
    playSound('scratch');

    // Throttled percentage calculation
    const currentPct = checkScratchPercentage();
    setScratchPercent(currentPct);

    // If reached >= 50%, trigger claim!
    if (currentPct >= 50 && !isClaimed && !isClaiming) {
      handleRewardClaim(currentPct);
    }
  };

  const handlePointerDown = (e: React.MouseEvent | React.TouchEvent) => {
    if (isClaimed || !currentCardId) return;
    isDrawingRef.current = true;
    setIsScratching(true);
    const coords = getCanvasCoords(e);
    lastPointRef.current = coords;
    scratchAtPoint(coords.x, coords.y);
  };

  const handlePointerMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawingRef.current || isClaimed || !currentCardId) return;
    const coords = getCanvasCoords(e);
    scratchAtPoint(coords.x, coords.y);
  };

  const handlePointerUp = () => {
    isDrawingRef.current = false;
    lastPointRef.current = null;
    setIsScratching(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07060e] text-white overflow-y-auto animate-fade-in">
      {/* Top Header */}
      <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-3.5 glass-panel border-b border-purple-900/30">
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-violet-600 via-pink-600 to-amber-500 flex items-center justify-center text-white shadow-md shadow-pink-600/30">
            <CreditCard className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white tracking-wide flex items-center">
              SCRATCH CARDS <Sparkles className="w-3.5 h-3.5 text-amber-400 ml-1.5" />
            </h2>
            <p className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
              Win ₹1 to ₹20 Per Card Guaranteed
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
            title={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-amber-400" />
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
          </button>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="max-w-md mx-auto w-full px-4 py-5 flex-1 flex flex-col items-center">
        {/* Wallet Balance Bar at Top */}
        <div className="w-full flex items-center justify-between bg-black/50 border border-white/10 rounded-2xl p-3.5 mb-3 shadow-inner">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-300">
              <Coins className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
                Your Wallet Balance
              </span>
              <span className="text-xl font-black text-amber-300">
                ₹{(wallet?.availableBalance ?? 0).toFixed(2)}
              </span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-400 uppercase font-bold flex items-center justify-end space-x-1">
              <CreditCard className="w-3 h-3 text-pink-400" />
              <span>Cards Left</span>
            </span>
            <span className="text-base font-black text-pink-400 mt-0.5 block">
              {scratchesRemaining} / {dailyLimit}
            </span>
          </div>
        </div>

        {errorMsg && (
          <div className="w-full mb-3 flex items-center space-x-2 bg-red-950/40 border border-red-500/30 p-3 rounded-xl text-xs text-red-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* ACTIVE SCRATCH CARD AREA */}
        <div className="w-full flex flex-col items-center my-2">
          {currentCardId && currentReward !== null ? (
            <div className="flex flex-col items-center space-y-3">
              {/* Scratch Progress indicator */}
              <div className="w-full max-w-[280px] flex items-center justify-between text-xs">
                <span className="text-[11px] font-bold text-slate-300 flex items-center">
                  <Flame className="w-3.5 h-3.5 text-amber-400 mr-1" />
                  Scratched: {scratchPercent}%
                </span>
                <span
                  className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                    scratchPercent >= 50
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {scratchPercent >= 50 ? 'REVEALED!' : 'Need 50%'}
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full max-w-[280px] bg-black/40 h-2 rounded-full overflow-hidden p-0.5 border border-white/10">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-amber-400 rounded-full transition-all duration-150"
                  style={{ width: `${Math.min(100, scratchPercent)}%` }}
                />
              </div>

              {/* The Interactive Scratch Card Box */}
              <div
                className="relative rounded-3xl overflow-hidden shadow-2xl border-2 border-amber-400/60 select-none touch-none"
                style={{ width: 280, height: 180 }}
                onMouseDown={handlePointerDown}
                onMouseMove={handlePointerMove}
                onMouseUp={handlePointerUp}
                onMouseLeave={handlePointerUp}
                onTouchStart={handlePointerDown}
                onTouchMove={handlePointerMove}
                onTouchEnd={handlePointerUp}
              >
                {/* 1. Underlying Prize Card (Visible once scratched) */}
                <div className="absolute inset-0 bg-gradient-to-br from-[#1b0d3a] via-[#24124d] to-[#0f0724] flex flex-col items-center justify-center p-4 text-center z-0">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 text-black flex items-center justify-center mb-1 shadow-lg shadow-amber-400/30 animate-pulse">
                    <Trophy className="w-7 h-7" />
                  </div>
                  <span className="text-[10px] font-black tracking-widest text-amber-300 uppercase">
                    YOU WON
                  </span>
                  <div className="text-3xl font-black text-white tracking-tight">
                    ₹{currentReward}
                  </div>
                  <span className="text-[9px] text-emerald-400 font-bold uppercase mt-0.5">
                    {isClaimed ? '✓ Added to Wallet' : 'Scratch 50% to Claim'}
                  </span>
                </div>

                {/* 2. Top Interactive HTML5 Scratch Canvas Layer */}
                <canvas
                  ref={canvasRef}
                  className="absolute inset-0 z-10 cursor-pointer touch-none"
                  style={{
                    display: isClaimed && scratchPercent >= 80 ? 'none' : 'block'
                  }}
                />
              </div>

              {/* Action under card */}
              {isClaimed ? (
                <button
                  onClick={requestNewCard}
                  disabled={scratchesRemaining <= 0 || cardLoading}
                  className="w-full max-w-[280px] py-3 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
                >
                  <RotateCw className="w-4 h-4" />
                  <span>
                    {scratchesRemaining > 0
                      ? `SCRATCH NEXT CARD (${scratchesRemaining} LEFT)`
                      : 'ALL CARDS USED TODAY'}
                  </span>
                </button>
              ) : (
                <p className="text-[11px] text-slate-400 text-center animate-pulse">
                  👆 Use your finger or mouse to scratch the card
                </p>
              )}
            </div>
          ) : (
            /* Card Generator Banner */
            <div className="w-full max-w-sm rounded-3xl glass-card p-6 border-2 border-purple-500/30 flex flex-col items-center text-center space-y-4 shadow-xl">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 via-pink-600 to-amber-500 flex items-center justify-center text-white shadow-lg shadow-purple-600/30">
                <Gift className="w-9 h-9" />
              </div>

              <div>
                <h3 className="text-base font-extrabold text-white">
                  Get Your Lucky Scratch Card 🎟️
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Reveal instant cash rewards between{' '}
                  <span className="text-amber-300 font-black">₹1 to ₹20</span>.
                </p>
                <div className="inline-block mt-2 bg-purple-500/10 border border-purple-500/30 px-3 py-1 rounded-full text-[10px] text-purple-300 font-bold">
                  {scratchesRemaining} of {dailyLimit} Cards Available Today
                </div>
              </div>

              <button
                onClick={requestNewCard}
                disabled={scratchesRemaining <= 0 || cardLoading}
                className="w-full py-4 px-6 bg-gradient-to-r from-pink-600 via-purple-600 to-amber-500 hover:from-pink-500 hover:to-amber-400 text-white font-black text-sm tracking-wider rounded-2xl shadow-xl shadow-purple-900/50 transition-all transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {cardLoading ? (
                  <>
                    <RotateCw className="w-5 h-5 animate-spin text-amber-300" />
                    <span>GENERATING CARD...</span>
                  </>
                ) : scratchesRemaining > 0 ? (
                  <>
                    <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
                    <span>SCRATCH A CARD NOW</span>
                  </>
                ) : (
                  <span>DAILY LIMIT REACHED (0 LEFT)</span>
                )}
              </button>
            </div>
          )}
        </div>


        {/* Scratch History */}
        <div className="w-full mt-3">
          <div className="flex items-center justify-between mb-2 px-1">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Today's Scratch History
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">
              Resets in {resetCountdown}
            </span>
          </div>

          {scratchHistory.length === 0 ? (
            <div className="text-center py-4 bg-black/25 rounded-2xl border border-white/5 text-slate-500 text-xs">
              No scratch cards opened today. Tap "SCRATCH A CARD NOW" to win up to ₹20!
            </div>
          ) : (
            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
              {scratchHistory.map((s, idx) => (
                <div
                  key={s.id || idx}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-black/35 border border-white/5 text-xs"
                >
                  <div className="flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-pink-400" />
                    <span className="font-extrabold text-white">Won ₹{s.rewardAmount}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-400 text-[11px]">
                    <span>
                      {new Date(s.timestamp || s.claimedAt || Date.now()).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                    <span className="text-emerald-400 font-bold uppercase text-[9px] bg-emerald-950/50 px-2 py-0.5 rounded-md border border-emerald-500/20">
                      CREDITED
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* WINNING POPUP MODAL */}
      {showWinModal && wonAmount !== null && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-sm glass-card rounded-3xl p-6 border-2 border-pink-400 text-center space-y-4 shadow-2xl relative overflow-hidden animate-scale-up">
            <div className="absolute top-0 right-0 w-32 h-32 bg-pink-500/20 rounded-full blur-2xl pointer-events-none" />

            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-pink-500 via-purple-600 to-amber-400 text-white flex items-center justify-center mx-auto shadow-lg shadow-pink-500/30 animate-bounce">
              <Trophy className="w-9 h-9" />
            </div>

            <div>
              <span className="text-xs font-black text-pink-300 uppercase tracking-widest block">
                SCRATCH CARD REWARD!
              </span>
              <div className="flex items-baseline justify-center space-x-1 my-1">
                <span className="text-4xl sm:text-5xl font-black text-white">₹{wonAmount}</span>
              </div>
              <p className="text-xs text-emerald-300 font-bold mt-1">
                Amount automatically credited to your wallet!
              </p>
              <div className="mt-3 p-2.5 bg-black/40 rounded-xl border border-white/10 text-xs flex items-center justify-between text-slate-300">
                <span>Updated Available Balance:</span>
                <span className="text-amber-300 font-black">
                  ₹{(wallet?.availableBalance ?? 0).toFixed(2)}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                setShowWinModal(false);
                if (scratchesRemaining > 0) {
                  requestNewCard();
                }
              }}
              className="w-full py-3.5 bg-gradient-to-r from-pink-600 via-purple-600 to-amber-500 hover:from-pink-500 hover:to-amber-400 text-white font-black text-sm uppercase rounded-xl shadow-lg transition-all"
            >
              {scratchesRemaining > 0 ? 'SCRATCH ANOTHER CARD' : 'COLLECT REWARD'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
