import React, { useState, useEffect } from 'react';
import {
  X,
  CreditCard,
  ExternalLink,
  Upload,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Info,
  Clock,
  Sparkles,
  Lock,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PaymentSettingsConfig } from '../../types';
import { useAuth } from '../../context/AuthContext';
import {
  submitPaymentProof,
  recordSuccessfulZapPayment
} from '../../services/firestoreService';
import { uploadSecureFile } from '../../services/storageService';
import {
  initiateZapPayment,
  registerZapPaymentCallbacks
} from '../../services/zapUpiService';

interface VerificationFeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  paymentSettings: PaymentSettingsConfig;
  onPaymentSuccess?: () => void;
  pendingWithdrawalAmount?: number | null;
  pendingUpiId?: string | null;
}

export const VerificationFeeModal: React.FC<VerificationFeeModalProps> = ({
  isOpen,
  onClose,
  paymentSettings,
  onPaymentSuccess,
  pendingWithdrawalAmount,
  pendingUpiId
}) => {
  const { currentUser, userProfile, refreshData } = useAuth();
  const [activeTab, setActiveTab] = useState<'pay' | 'proof'>('pay');
  const [transactionRef, setTransactionRef] = useState('');
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [zapInitiating, setZapInitiating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [paidOrderId, setPaidOrderId] = useState<string | null>(null);

  const feeAmount = paymentSettings.feeAmount || 99;
  const paymentLink = paymentSettings.paymentLink || '';
  const isAlreadyPaid = userProfile?.feePaid || userProfile?.kycStatus === 'approved';

  const description =
    paymentSettings.paymentDescription ||
    'One-time verification and processing fee to validate user identity and activate unlimited UPI payouts.';
  const refundPolicy =
    paymentSettings.refundPolicy ||
    'Eligible for 100% refund within 7 business days if your KYC identity verification cannot be approved due to administrative failure.';
  const withdrawalConditions =
    paymentSettings.withdrawalConditions ||
    'Account must maintain active verified KYC status, registered UPI ID, and meet minimum withdrawal threshold of ₹149.';

  useEffect(() => {
    if (isOpen && typeof window !== 'undefined' && window.ZapUPI) {
      registerZapPaymentCallbacks(
        {
          onSuccess: handlePaymentSuccessCallback,
          onFailed: (orderId) => {
            setZapInitiating(false);
            setErrorMessage(`Payment was not completed (Order: ${orderId}). You can try again or use direct UPI.`);
          },
          onTimeout: (orderId) => {
            setZapInitiating(false);
            setErrorMessage(`Payment session timed out (Order: ${orderId}). Please try again.`);
          },
          onError: (err) => {
            setZapInitiating(false);
            setErrorMessage(err || 'ZapUPI gateway error occurred.');
          }
        },
        `ORD_${Date.now()}`
      );
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handlePaymentSuccessCallback = async (orderId: string) => {
    setZapInitiating(false);
    setPaidOrderId(orderId);
    setSuccessMessage(`Payment confirmed! Order ID: ${orderId}. Your verification status is now updated in Firestore.`);

    try {
      confetti({
        particleCount: 90,
        spread: 80,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }

    if (currentUser) {
      await recordSuccessfulZapPayment(currentUser.uid, feeAmount, orderId);
      await refreshData();
    }
    if (onPaymentSuccess) {
      onPaymentSuccess();
    }
  };

  const handlePayWithZapUpi = () => {
    setErrorMessage(null);
    setSuccessMessage(null);
    setZapInitiating(true);

    const orderId = `ORD_${Date.now()}_${currentUser?.uid?.substring(0, 5) || 'USER'}`;
    initiateZapPayment(
      {
        amount: feeAmount,
        paymentLink: paymentLink.trim(),
        orderId,
        customerMobile: userProfile?.phone || '',
        customerName: userProfile?.name || 'ARJ Member',
        userId: currentUser?.uid || 'user',
        zapKey: paymentSettings.zapKey || 'zap64b8e6c0bbd16e5965a3ad714395863a',
        remark: `Verification Fee | ${currentUser?.uid}`
      },
      {
        onSuccess: handlePaymentSuccessCallback,
        onFailed: (failedOrderId) => {
          setZapInitiating(false);
          setErrorMessage(`Payment cancelled or unsuccessful (Order: ${failedOrderId}). You may also pay directly via UPI.`);
        },
        onTimeout: (timeoutOrderId) => {
          setZapInitiating(false);
          setErrorMessage(`Payment session timed out (Order: ${timeoutOrderId}). Please try again.`);
        },
        onError: (err) => {
          setZapInitiating(false);
          setErrorMessage(err || 'ZapUPI gateway could not open. Please use the direct UPI link or submit your UTR reference.');
        }
      }
    );
  };

  const handleDirectUpiIntent = () => {
    if (paymentLink) {
      window.location.href = paymentLink;
    } else {
      const upiId = paymentSettings.upiId || 'arjonline@upi';
      const upiUrl = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent('ARJ Marketing')}&am=${feeAmount}&cu=INR&tn=${encodeURIComponent(`Verification_${currentUser?.uid?.substring(0, 6) || ''}`)}`;
      window.location.href = upiUrl;
    }
  };

  const handleProofSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!transactionRef.trim()) {
      setErrorMessage('Please enter the 12-digit UPI Reference Number (UTR / Transaction ID).');
      return;
    }

    if (!currentUser) return;
    setLoading(true);

    try {
      let proofUrl = '';
      if (proofFile) {
        const storagePath = `payment_proofs/${currentUser.uid}/${Date.now()}_${proofFile.name}`;
        proofUrl = await uploadSecureFile(storagePath, proofFile);
      }

      const res = await submitPaymentProof(currentUser.uid, {
        amount: feeAmount,
        transactionReference: transactionRef.trim(),
        proofUrl,
        method: 'Direct UPI'
      });
      setLoading(false);

      if (res.success) {
        setSuccessMessage('Payment reference submitted! Verification status is now Pending admin confirmation.');
        await refreshData();
        if (onPaymentSuccess) onPaymentSuccess();
      } else {
        setErrorMessage(res.message);
      }
    } catch (err: unknown) {
      setLoading(false);
      const msg = err instanceof Error ? err.message : 'Error submitting proof';
      setErrorMessage(msg);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07060e] text-white overflow-y-auto animate-fade-in">
      <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-4 glass-panel border-b border-purple-900/30">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
            <CreditCard className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">KYC / WITHDRAWAL VERIFICATION</h2>
            <p className="text-[10px] text-amber-400 font-semibold">ZapUPI Secure Payment Portal</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-md mx-auto w-full px-5 py-6 flex-1 space-y-5">
        {(isAlreadyPaid || paidOrderId) && (
          <div className="glass-card rounded-3xl p-6 border border-emerald-500/40 text-center space-y-3 bg-gradient-to-b from-emerald-950/30 to-black/50">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30 shadow-lg shadow-emerald-950/50">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">Verification Fee Confirmed</h3>
              <p className="text-xs text-emerald-300 mt-1">
                Fee Status: <strong className="uppercase">VERIFIED</strong>
                {paidOrderId && ` • Order: ${paidOrderId}`}
              </p>
              <p className="text-[11px] text-slate-300 mt-2 leading-relaxed">
                Your account is confirmed for unlimited withdrawals. Payouts can be requested directly to your registered UPI ID.
              </p>
            </div>
            <button
              onClick={onClose}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase rounded-xl transition-colors mt-2"
            >
              Continue to Dashboard
            </button>
          </div>
        )}

        {pendingWithdrawalAmount && (
          <div className="bg-gradient-to-r from-purple-950/70 via-indigo-950/70 to-slate-900 border border-purple-500/40 rounded-2xl p-4 flex items-center justify-between shadow-xl">
            <div>
              <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider block">
                Pending Withdrawal Request
              </span>
              <span className="text-base font-black text-white">
                ₹{pendingWithdrawalAmount.toFixed(2)} • {pendingUpiId}
              </span>
              <p className="text-[10px] text-slate-300 mt-0.5">
                Pay ₹{feeAmount} processing fee to approve and dispatch this payout.
              </p>
            </div>
            <span className="text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30 px-2.5 py-1 rounded-xl">
              Step 2 of 2
            </span>
          </div>
        )}

        {!isAlreadyPaid && !paidOrderId && (
          <div className="flex p-1 bg-black/50 rounded-2xl border border-white/10 text-xs font-bold">
            <button
              onClick={() => setActiveTab('pay')}
              className={`flex-1 py-2.5 rounded-xl transition-all ${
                activeTab === 'pay'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Pay via ZapUPI (₹{feeAmount})
            </button>
            <button
              onClick={() => setActiveTab('proof')}
              className={`flex-1 py-2.5 rounded-xl transition-all ${
                activeTab === 'proof'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Submit UTR Proof
            </button>
          </div>
        )}

        {errorMessage && (
          <div className="flex items-start space-x-2.5 rounded-xl bg-red-950/40 border border-red-500/30 p-3 text-xs text-red-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="flex items-start space-x-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 p-3 text-xs text-emerald-300">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400 mt-0.5" />
            <span>{successMessage}</span>
          </div>
        )}

        {!isAlreadyPaid && !paidOrderId && activeTab === 'pay' && (
          <div className="space-y-4">
            <div className="glass-card-gold rounded-3xl p-6 border border-amber-500/30 text-center relative overflow-hidden">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest block mb-1">
                Account Verification Fee
              </span>
              <div className="flex items-baseline justify-center space-x-1 my-2">
                <span className="text-4xl font-black text-amber-300">₹{feeAmount}</span>
                <span className="text-xs text-slate-400">One-Time Fee</span>
              </div>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">{description}</p>
            </div>

            <button
              onClick={handlePayWithZapUpi}
              disabled={zapInitiating}
              className="w-full py-4 px-4 bg-gradient-to-r from-amber-500 via-purple-600 to-amber-500 hover:from-amber-400 hover:to-purple-500 text-white font-extrabold text-sm uppercase tracking-wide rounded-2xl shadow-xl shadow-purple-900/30 transition-all flex items-center justify-center space-x-2 disabled:opacity-60 active:scale-[0.98]"
            >
              {zapInitiating ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>PAY ₹{feeAmount} WITH ZAPUPI</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <button
              onClick={handleDirectUpiIntent}
              className="w-full py-3 px-4 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-2"
            >
              <ExternalLink className="w-4 h-4 text-blue-400" />
              <span>
                {paymentLink ? 'OPEN CONFIGURED PAYMENT LINK' : 'PAY VIA UPI INTENT (GPAY / PHONEPE / PAYTM)'}
              </span>
            </button>

            <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-3 text-xs text-slate-300">
              <div className="flex items-center space-x-2 text-amber-400 font-bold text-[11px]">
                <Info className="w-4 h-4" />
                <span>Statutory Policy & Transparency Disclosures</span>
              </div>
              <div className="space-y-1.5 text-[11px] leading-relaxed text-slate-400">
                <p>
                  <strong className="text-slate-200">Refund Policy:</strong> {refundPolicy}
                </p>
                <p>
                  <strong className="text-slate-200">Withdrawal Conditions:</strong> {withdrawalConditions}
                </p>
                <div className="flex items-start space-x-1.5 text-amber-300/90 pt-1.5 border-t border-white/5">
                  <Lock className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-amber-400" />
                  <span>
                    This fee is a private administrative verification charge and is not a government tax. Paying this fee enables KYC processing and does NOT guarantee daily earnings or fixed profits.
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {!isAlreadyPaid && !paidOrderId && activeTab === 'proof' && (
          <div className="glass-card rounded-3xl p-5 border border-purple-500/20">
            <h3 className="text-sm font-bold text-white mb-1">Submit Payment Verification</h3>
            <p className="text-xs text-slate-400 mb-4">
              Enter the bank UTR reference or upload your transaction screenshot.
            </p>
            <form onSubmit={handleProofSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  UPI Reference Number (UTR / Txn ID)
                </label>
                <input
                  type="text"
                  value={transactionRef}
                  onChange={(e) => setTransactionRef(e.target.value)}
                  placeholder="e.g. 443455455555"
                  className="w-full px-4 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs sm:text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Payment Screenshot Proof (Optional)
                </label>
                <label className="flex flex-col items-center justify-center border-2 border-dashed border-purple-900/50 hover:border-purple-500/70 rounded-2xl p-4 bg-[#0d0c1c]/60 cursor-pointer transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => e.target.files && setProofFile(e.target.files[0])}
                    className="hidden"
                  />
                  {proofFile ? (
                    <div className="flex items-center space-x-2 text-emerald-400 text-xs">
                      <FileCheck className="w-4 h-4" />
                      <span className="truncate max-w-[200px]">{proofFile.name}</span>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-5 h-5 text-purple-400 mb-1" />
                      <span className="text-xs text-slate-300 font-medium">Upload receipt screenshot</span>
                    </>
                  )}
                </label>
              </div>

              <div className="p-3 bg-amber-950/30 border border-amber-500/20 rounded-xl text-[11px] text-amber-300 flex items-center space-x-2">
                <Clock className="w-4 h-4 flex-shrink-0" />
                <span>Verification Status will be set to Pending until reviewed by compliance.</span>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm uppercase tracking-wide rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>SUBMIT FOR VERIFICATION</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
