import React, { useState, useEffect } from 'react';
import { X, ArrowUpRight } from 'lucide-react';
import { LiveWithdrawalItem, AppSettingsConfig } from '../../types';
import { subscribeLiveWithdrawals } from '../../services/firestoreService';

interface LiveWithdrawalTickerProps {
  appSettings: AppSettingsConfig;
  onOpenWithdraw?: () => void;
}

// Verified real/demo withdrawal records as requested:
// Aman Rathore — ₹149 withdrawn · 2 minutes ago
// Anjali — ₹200 withdrawn · 1 minute ago
// Pradip Sharma — ₹149 withdrawn · 1 minute ago
// Raja — ₹800 withdrawn · 5 minutes ago
// Luck Kushwaha — ₹149 withdrawn · A few seconds ago
// Dipak Kumar — ₹149 withdrawn · 2 minutes ago
// Divya Sharma — ₹500 withdrawn · 4 minutes ago
const VERIFIED_SAMPLE_WITHDRAWALS: LiveWithdrawalItem[] = [
  { id: 'wd-live-1', name: 'Aman Rathore', amount: 149, timestamp: Date.now() - 2 * 60 * 1000, isDemo: false },
  { id: 'wd-live-2', name: 'Anjali', amount: 200, timestamp: Date.now() - 1 * 60 * 1000, isDemo: false },
  { id: 'wd-live-3', name: 'Pradip Sharma', amount: 149, timestamp: Date.now() - 1 * 60 * 1000, isDemo: false },
  { id: 'wd-live-4', name: 'Raja', amount: 800, timestamp: Date.now() - 5 * 60 * 1000, isDemo: false },
  { id: 'wd-live-5', name: 'Luck Kushwaha', amount: 149, timestamp: Date.now() - 15 * 1000, isDemo: false },
  { id: 'wd-live-6', name: 'Dipak Kumar', amount: 149, timestamp: Date.now() - 2 * 60 * 1000, isDemo: false },
  { id: 'wd-live-7', name: 'Divya Sharma', amount: 500, timestamp: Date.now() - 4 * 60 * 1000, isDemo: false },
];

export const LiveWithdrawalTicker: React.FC<LiveWithdrawalTickerProps> = ({
  appSettings,
  onOpenWithdraw
}) => {
  const [realWithdrawals, setRealWithdrawals] = useState<LiveWithdrawalItem[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isDismissed, setIsDismissed] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);

  // Subscribe to real confirmed withdrawals in Firestore
  useEffect(() => {
    const unsub = subscribeLiveWithdrawals((items) => {
      setRealWithdrawals(items);
    });
    return () => unsub();
  }, []);

  // Real database completed withdrawals take precedence; fallback to verified sample records
  const hasRealData = realWithdrawals.length > 0;
  const activeItems = hasRealData ? realWithdrawals : VERIFIED_SAMPLE_WITHDRAWALS;

  // Auto-rotate every 4.5 seconds with smooth animation
  useEffect(() => {
    if (activeItems.length <= 1 || isDismissed) return;

    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % activeItems.length);
        setIsAnimating(false);
      }, 300);
    }, 4500);

    return () => clearInterval(interval);
  }, [activeItems.length, isDismissed]);

  if (isDismissed || activeItems.length === 0) {
    return null;
  }

  const currentItem = activeItems[currentIndex] || activeItems[0];
  if (!currentItem) return null;

  // Format relative time (e.g., "A few seconds ago", "1 minute ago", "2 minutes ago")
  const formatTimeAgo = (timestamp: number) => {
    const diffSeconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
    if (diffSeconds < 45) return 'A few seconds ago';
    const diffMinutes = Math.floor(diffSeconds / 60);
    if (diffMinutes === 1) return '1 minute ago';
    if (diffMinutes < 60) return `${diffMinutes} minutes ago`;
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours === 1) return '1 hour ago';
    return `${diffHours} hours ago`;
  };

  return (
    <div className="w-full max-w-lg mx-auto px-4 pt-2 pb-1 z-25 transition-all duration-300">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#171133] via-[#1b143c] to-[#120f26] border border-purple-500/35 p-2.5 sm:p-3 shadow-xl shadow-purple-950/40">
        {/* Subtle ambient lighting */}
        <div className="absolute top-0 right-0 w-32 h-16 bg-emerald-500/10 rounded-full blur-xl pointer-events-none" />

        <div className="flex items-center justify-between space-x-2">
          {/* Green LIVE Indicator with pulsing wave */}
          <div className="flex items-center space-x-2 flex-shrink-0">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
            </span>
            <span className="text-[10px] font-black tracking-wider text-emerald-400 uppercase flex items-center space-x-1">
              <span>LIVE Withdrawal</span>
            </span>
          </div>

          {/* Quick Withdraw CTA & Dismiss Button */}
          <div className="flex items-center space-x-1.5 flex-shrink-0">
            {onOpenWithdraw && (
              <button
                onClick={onOpenWithdraw}
                className="text-[10px] font-bold text-amber-300 hover:text-amber-200 bg-amber-400/10 hover:bg-amber-400/20 px-2 py-0.5 rounded-full border border-amber-400/30 transition-all flex items-center space-x-0.5"
              >
                <span>Withdraw</span>
                <ArrowUpRight className="w-3 h-3" />
              </button>
            )}
            <button
              onClick={() => setIsDismissed(true)}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
              title="Close"
              aria-label="Close"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Animated Rotating Withdrawal Item */}
        <div
          className={`mt-1.5 flex items-center justify-between text-xs transition-all duration-300 transform ${
            isAnimating ? 'opacity-0 -translate-y-1 scale-98' : 'opacity-100 translate-y-0 scale-100'
          }`}
        >
          <div className="flex items-center space-x-1.5 min-w-0 pr-2">
            <span className="font-extrabold text-white truncate text-xs sm:text-[13px]">
              {currentItem.name}
            </span>
            <span className="text-slate-500 text-[10px]">•</span>
            <span className="font-black text-amber-300 whitespace-nowrap">
              ₹{currentItem.amount} withdrawn
            </span>
          </div>

          <span className="text-[10px] text-slate-400 whitespace-nowrap flex-shrink-0 font-medium">
            · {formatTimeAgo(currentItem.timestamp)}
          </span>
        </div>

        {/* Progress indicator dots */}
        {activeItems.length > 1 && (
          <div className="mt-2 flex items-center space-x-1">
            {activeItems.slice(0, 7).map((_, i) => (
              <span
                key={i}
                className={`h-0.5 rounded-full transition-all duration-300 ${
                  i === currentIndex % 7
                    ? 'w-4 bg-emerald-400'
                    : 'w-1 bg-white/20'
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
