import React, { useState } from 'react';
import { X, Bell, Trophy, ShieldCheck, Landmark, Megaphone } from 'lucide-react';
import { AppNotification } from '../../types';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: AppNotification[];
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  notifications
}) => {
  const [activeTab, setActiveTab] = useState<'All' | 'Rewards' | 'KYC' | 'Withdrawal' | 'Announcements'>('All');

  if (!isOpen) return null;

  const filtered = notifications.filter((n) => {
    if (activeTab === 'All') return true;
    return n.category === activeTab;
  });

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Rewards':
        return <Trophy className="w-4 h-4 text-amber-400" />;
      case 'KYC':
        return <ShieldCheck className="w-4 h-4 text-purple-400" />;
      case 'Withdrawal':
        return <Landmark className="w-4 h-4 text-blue-400" />;
      default:
        return <Megaphone className="w-4 h-4 text-emerald-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07060e] text-white overflow-y-auto animate-fade-in">
      <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-4 glass-panel border-b border-purple-900/30">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
            <Bell className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">NOTIFICATIONS</h2>
            <p className="text-[10px] text-slate-400">Activity & Platform Updates</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-md mx-auto w-full px-5 py-5 flex-1 space-y-4">
        <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar pb-1">
          {(['All', 'Rewards', 'KYC', 'Withdrawal', 'Announcements'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${
                activeTab === tab
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-black/40 text-slate-400 hover:text-white border border-white/5'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-12 glass-card rounded-2xl border border-white/5 text-slate-500 text-xs">
            No notifications in this category yet.
          </div>
        ) : (
          <div className="space-y-2.5">
            {filtered.map((item) => (
              <div
                key={item.id}
                className="glass-card rounded-2xl p-4 border border-white/5 flex items-start space-x-3.5 hover:border-purple-500/20 transition-colors"
              >
                <div className="w-9 h-9 rounded-xl bg-black/40 border border-white/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  {getCategoryIcon(item.category)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <h4 className="text-xs font-bold text-white truncate">{item.title}</h4>
                    <span className="text-[10px] text-slate-500 font-medium">
                      {new Date(item.createdAt).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric'
                      })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{item.message}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
