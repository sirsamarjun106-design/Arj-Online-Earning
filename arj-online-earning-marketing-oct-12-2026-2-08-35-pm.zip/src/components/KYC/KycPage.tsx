import React, { useState } from 'react';
import {
  ShieldCheck,
  X,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileText,
  Lock
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { KycRecord } from '../../types';
import { submitKycVerification } from '../../services/firestoreService';

interface KycPageProps {
  isOpen: boolean;
  onClose: () => void;
  kycRecord: KycRecord | null;
  onKycSubmitted: () => void;
  pendingWithdrawalAmount?: number | null;
  pendingUpiId?: string | null;
}

export const KycPage: React.FC<KycPageProps> = ({
  isOpen,
  onClose,
  kycRecord,
  onKycSubmitted,
  pendingWithdrawalAmount,
  pendingUpiId
}) => {
  const { currentUser, userProfile } = useAuth();
  const [fullName, setFullName] = useState(userProfile?.name || '');
  const [email, setEmail] = useState(userProfile?.email || '');
  const [phone, setPhone] = useState(userProfile?.phone || '');
  const [identityType, setIdentityType] = useState<'PAN' | 'Aadhaar' | 'Voter ID' | 'Driving License'>('PAN');
  const [identityNumber, setIdentityNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentStatus = userProfile?.kycStatus || kycRecord?.status || 'unverified';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!fullName.trim()) {
      setErrorMessage('Please enter your full legal name as on document.');
      return;
    }
    if (!email.trim()) {
      setErrorMessage('Please enter your email.');
      return;
    }
    if (!phone.trim()) {
      setErrorMessage('Please enter your mobile number.');
      return;
    }
    if (!identityNumber.trim()) {
      setErrorMessage(`Please enter your ${identityType} number.`);
      return;
    }

    if (!currentUser) {
      setErrorMessage('Please log in to submit your KYC.');
      return;
    }

    setLoading(true);

    try {
      const res = await submitKycVerification(currentUser.uid, {
        fullName: fullName.trim(),
        email: email.trim(),
        phone: phone.trim(),
        identityType,
        identityNumber: identityNumber.trim().toUpperCase()
      });

      setLoading(false);

      if (res.success) {
        setSuccessMessage('KYC details submitted successfully! Status is now Pending review.');
        onKycSubmitted();
      } else {
        setErrorMessage(res.message);
      }
    } catch (err: unknown) {
      setLoading(false);
      const msg = err instanceof Error ? err.message : 'Submission failed';
      setErrorMessage(msg);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07060e] text-white overflow-y-auto animate-fade-in">
      {/* Top Header */}
      <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-4 glass-panel border-b border-purple-900/30">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-violet-600/20 border border-violet-500/40 flex items-center justify-center text-violet-300">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">KYC VERIFICATION</h2>
            <p className="text-[10px] text-slate-400">Identity Compliance Verification</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-md mx-auto w-full px-5 py-6 flex-1 space-y-5">
        {pendingWithdrawalAmount && (
          <div className="bg-gradient-to-r from-blue-950/60 via-purple-950/60 to-slate-900 border border-blue-500/30 rounded-2xl p-4 flex items-center justify-between shadow-lg">
            <div>
              <span className="text-[10px] font-bold text-blue-300 uppercase tracking-wider block">
                Pending Withdrawal Request
              </span>
              <span className="text-base font-black text-white">
                ₹{pendingWithdrawalAmount.toFixed(2)} • {pendingUpiId}
              </span>
              <p className="text-[10px] text-slate-300 mt-0.5">
                Submit KYC Details • Free Administrative Review
              </p>
            </div>
            <span className="text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30 px-2.5 py-1 rounded-xl">
              KYC Required
            </span>
          </div>
        )}

        {/* Current Status Card */}
        <div
          className={`rounded-2xl p-4 border flex items-center justify-between ${
            currentStatus === 'approved'
              ? 'bg-emerald-950/40 border-emerald-500/40'
              : currentStatus === 'pending'
              ? 'bg-amber-950/40 border-amber-500/40'
              : currentStatus === 'rejected'
              ? 'bg-red-950/40 border-red-500/40'
              : 'glass-card border-purple-500/20'
          }`}
        >
          <div className="flex items-center space-x-3">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                currentStatus === 'approved'
                  ? 'bg-emerald-500/20 text-emerald-400'
                  : currentStatus === 'pending'
                  ? 'bg-amber-500/20 text-amber-400'
                  : currentStatus === 'rejected'
                  ? 'bg-red-500/20 text-red-400'
                  : 'bg-purple-500/20 text-purple-400'
              }`}
            >
              {currentStatus === 'approved' ? (
                <CheckCircle2 className="w-5 h-5" />
              ) : currentStatus === 'pending' ? (
                <Clock className="w-5 h-5" />
              ) : currentStatus === 'rejected' ? (
                <AlertCircle className="w-5 h-5" />
              ) : (
                <FileText className="w-5 h-5" />
              )}
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                Verification Status
              </span>
              <span className="text-sm font-black capitalize">
                {currentStatus === 'approved'
                  ? 'KYC Verified (Approved)'
                  : currentStatus === 'pending'
                  ? 'Under Administrative Review'
                  : currentStatus === 'rejected'
                  ? 'Verification Rejected'
                  : 'Not Submitted Yet'}
              </span>
            </div>
          </div>
        </div>

        {currentStatus === 'rejected' && kycRecord?.rejectionReason && (
          <div className="p-4 rounded-2xl bg-red-950/50 border border-red-500/30 text-xs text-red-200 space-y-1">
            <span className="font-bold text-red-300 block">Rejection Reason:</span>
            <p>{kycRecord.rejectionReason}</p>
            <p className="text-[11px] text-slate-300 pt-1">
              Please review the feedback and update your identity details below.
            </p>
          </div>
        )}

        {currentStatus === 'approved' ? (
          <div className="glass-card rounded-3xl p-6 border border-emerald-500/30 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/40 shadow-lg shadow-emerald-950/50">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">KYC Verification Active</h3>
              <p className="text-xs text-slate-300 mt-1 max-w-xs mx-auto">
                Your identity has been authenticated. Unlimited UPI withdrawals are fully unlocked on your account.
              </p>
            </div>
            <div className="p-3 bg-black/40 rounded-xl text-xs text-slate-300 text-left space-y-1 border border-white/5">
              <div className="flex justify-between">
                <span className="text-slate-400">Document:</span>
                <span className="font-bold text-white">{kycRecord?.identityType || 'PAN'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Number:</span>
                <span className="font-mono text-white">{kycRecord?.identityNumber || '••••••••'}</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="glass-card rounded-3xl p-5 border border-purple-500/20">
            {errorMessage && (
              <div className="mb-4 flex items-start space-x-2.5 rounded-xl bg-red-950/40 border border-red-500/30 p-3 text-xs text-red-300">
                <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}
            {successMessage && (
              <div className="mb-4 flex items-start space-x-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 p-3 text-xs text-emerald-300">
                <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400 mt-0.5" />
                <span>{successMessage}</span>
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Full Name (as per document)
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Legal name on Government ID"
                  className="w-full px-4 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Mobile Number
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="9876543210"
                    className="w-full px-3 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Identity Document Type
                </label>
                <select
                  value={identityType}
                  onChange={(e) => setIdentityType(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="PAN">PAN Card (Recommended)</option>
                  <option value="Aadhaar">Aadhaar Card</option>
                  <option value="Voter ID">Voter ID</option>
                  <option value="Driving License">Driving License</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {identityType} Number
                </label>
                <input
                  type="text"
                  value={identityNumber}
                  onChange={(e) => setIdentityNumber(e.target.value.toUpperCase())}
                  placeholder={`Enter your ${identityType} number`}
                  className="w-full px-4 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs sm:text-sm uppercase tracking-wider font-mono text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm uppercase tracking-wide rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>SUBMIT KYC & PROCEED</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-2 text-slate-400 text-xs">
          <div className="flex items-center space-x-2 text-purple-300 font-bold text-[11px]">
            <Lock className="w-3.5 h-3.5" />
            <span>Strict Privacy & Identity Compliance</span>
          </div>
          <p className="text-[11px] leading-relaxed">
            All submitted identity credentials are encrypted and stored in secure Firestore records. Your verification details are strictly used for anti-fraud compliance and legitimate UPI withdrawal authorization.
          </p>
        </div>
      </div>
    </div>
  );
};
