import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, ArrowRight, AlertCircle, Sparkles } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface LoginProps {
  onSwitchToRegister: () => void;
  onOpenForgotPassword: () => void;
}

export const Login: React.FC<LoginProps> = ({ onSwitchToRegister, onOpenForgotPassword }) => {
  const { login } = useAuth();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    if (!identifier.trim()) {
      setErrorMessage('Please enter your email or mobile number.');
      return;
    }
    if (!password) {
      setErrorMessage('Please enter your password.');
      return;
    }
    setLoading(true);
    const res = await login(identifier, password);
    setLoading(false);
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to login. Please try again.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-gradient-to-b from-[#080712] via-[#0d0b1d] to-[#06060c] px-5 py-8 text-white max-w-md mx-auto">
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-64 h-64 bg-purple-600/15 rounded-full blur-[80px] pointer-events-none" />

      {/* Header & Logo */}
      <div className="flex flex-col items-center text-center pt-4">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-purple-700 via-indigo-600 to-amber-500 p-0.5 shadow-xl shadow-purple-600/25 mb-4">
          <div className="w-full h-full bg-[#0b0a16] rounded-[14px] flex flex-col items-center justify-center">
            <span className="text-2xl font-black tracking-tight bg-gradient-to-r from-amber-300 via-purple-300 to-indigo-200 bg-clip-text text-transparent">
              ARJ
            </span>
            <span className="text-[9px] font-bold text-amber-400 uppercase tracking-widest">
              EARN
            </span>
          </div>
        </div>
        <h1 className="text-xl font-extrabold tracking-tight text-white">
          ARJ Online Earning Marketing
        </h1>
        <p className="text-xs text-slate-400 mt-1 font-medium">
          Earn • Watch • Refer • Rewards
        </p>
      </div>

      {/* Main Login Card */}
      <div className="my-auto py-6">
        <div className="glass-card rounded-3xl p-6 sm:p-7 shadow-2xl shadow-black/50 border border-purple-500/20">
          <div className="mb-5">
            <h2 className="text-lg font-bold text-slate-100">Welcome Back</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Enter your credentials to access your rewards wallet
            </p>
          </div>

          {errorMessage && (
            <div className="mb-4 flex items-start space-x-2.5 rounded-xl bg-red-950/40 border border-red-500/30 p-3 text-xs text-red-300">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Email or Mobile Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="name@example.com or 9876543210"
                  className="w-full pl-10 pr-4 py-3 bg-[#0d0c1c]/90 border border-purple-900/40 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-11 py-3 bg-[#0d0c1c]/90 border border-purple-900/40 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200 focus:outline-none"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded bg-[#0d0c1c] border-purple-900/50 text-purple-600 focus:ring-0 focus:ring-offset-0"
                />
                <span className="font-medium text-slate-300">Remember Me</span>
              </label>
              <button
                type="button"
                onClick={onOpenForgotPassword}
                className="font-medium text-amber-400 hover:text-amber-300 hover:underline"
              >
                Forgot Password?
              </button>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3.5 px-4 bg-gradient-to-r from-purple-600 via-indigo-600 to-amber-500 hover:from-purple-500 hover:to-amber-400 text-white font-bold text-sm rounded-xl shadow-lg shadow-purple-600/30 transition-all duration-200 flex items-center justify-center space-x-2 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>LOGIN</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/10" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-[#141226] px-3 text-slate-400 font-medium">or</span>
            </div>
          </div>

          <button
            type="button"
            onClick={onSwitchToRegister}
            className="w-full py-3 px-4 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 font-semibold text-xs tracking-wider uppercase rounded-xl transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>CREATE ACCOUNT</span>
          </button>
        </div>
      </div>

      <div className="text-center text-[11px] text-slate-500 pb-2">
        Protected by Firebase Cloud Security • Genuine Rewards Portal
      </div>
    </div>
  );
};
