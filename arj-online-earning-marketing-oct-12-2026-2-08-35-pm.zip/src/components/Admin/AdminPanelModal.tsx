import React, { useState, useEffect } from 'react';
import {
  X,
  Shield,
  Settings,
  Layers,
  Landmark,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Plus,
  Edit2,
  DollarSign,
  Users,
  Save,
  Search,
  Eye,
  FileText
} from 'lucide-react';
import {
  AppSettingsConfig,
  TaskItem,
  WithdrawalRequest,
  KycRecord
} from '../../types';
import {
  updateAppSettingsByAdmin,
  getAllTasksForAdmin,
  saveTaskByAdmin,
  subscribeAllWithdrawals,
  processWithdrawalByAdmin,
  subscribeAllKyc,
  reviewKycByAdmin,
  adjustUserWalletByAdmin,
  setUserVerificationStatusByAdmin
} from '../../services/firestoreService';
import { useAuth } from '../../context/AuthContext';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  appSettings: AppSettingsConfig;
  onSettingsUpdated: () => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  appSettings,
  onSettingsUpdated
}) => {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'settings' | 'tasks' | 'withdrawals' | 'kyc' | 'adjustments'>('withdrawals');

  // Settings State
  const [minWd, setMinWd] = useState(appSettings.minimumWithdrawal);
  const [refReward, setRefReward] = useState(appSettings.referralReward);
  const [refEligibility, setRefEligibility] = useState(appSettings.referralEligibility);
  const [dailySpinLimit, setDailySpinLimit] = useState(appSettings.dailySpinLimit);
  const [dailyScratchLimit, setDailyScratchLimit] = useState(appSettings.dailyScratchLimit || 5);
  const [spinWheelEnabled, setSpinWheelEnabled] = useState(appSettings.spinWheelEnabled !== false);
  const [scratchCardsEnabled, setScratchCardsEnabled] = useState(appSettings.scratchCardsEnabled !== false);
  const [demoTicker, setDemoTicker] = useState(appSettings.liveWithdrawalsDemoEnabled);
  const [settingsSaving, setSettingsSaving] = useState(false);
  const [settingsMsg, setSettingsMsg] = useState<string | null>(null);

  // Tasks State
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [editingTask, setEditingTask] = useState<Partial<TaskItem> | null>(null);
  const [isNewTask, setIsNewTask] = useState(false);
  const [taskMsg, setTaskMsg] = useState<string | null>(null);

  // Withdrawals State
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [wdFilter, setWdFilter] = useState<'all' | 'pending' | 'paid' | 'rejected'>('pending');
  const [processingWdId, setProcessingWdId] = useState<string | null>(null);
  const [rejectionModalWd, setRejectionModalWd] = useState<WithdrawalRequest | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [wdMsg, setWdMsg] = useState<string | null>(null);

  // KYC State
  const [kycRecords, setKycRecords] = useState<KycRecord[]>([]);

  // Adjustment State
  const [adjUid, setAdjUid] = useState('');
  const [adjAmount, setAdjAmount] = useState('');
  const [adjType, setAdjType] = useState<'credit' | 'debit'>('credit');
  const [adjReason, setAdjReason] = useState('');
  const [adjLoading, setAdjLoading] = useState(false);
  const [adjMsg, setAdjMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      getAllTasksForAdmin().then(setTasks);
      const unsubWd = subscribeAllWithdrawals(setWithdrawals);
      const unsubKyc = subscribeAllKyc(setKycRecords);
      return () => {
        unsubWd();
        unsubKyc();
      };
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Handle Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsSaving(true);
    setSettingsMsg(null);
    const res = await updateAppSettingsByAdmin({
      minimumWithdrawal: Number(minWd),
      referralReward: Number(refReward),
      referrerRewardAmount: Number(refReward),
      referralEligibility: refEligibility,
      dailySpinLimit: Number(dailySpinLimit),
      dailyScratchLimit: Number(dailyScratchLimit),
      spinWheelEnabled,
      scratchCardsEnabled,
      liveWithdrawalsDemoEnabled: demoTicker
    });
    setSettingsSaving(false);
    if (res.success) {
      setSettingsMsg('Settings updated successfully!');
      onSettingsUpdated();
      setTimeout(() => setSettingsMsg(null), 3000);
    } else {
      setSettingsMsg(`Error: ${res.message}`);
    }
  };

  // Handle Task Save
  const handleSaveTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTask || !editingTask.title?.trim()) return;
    setTaskMsg(null);
    const taskToSave: Partial<TaskItem> = {
      ...editingTask,
      rewardAmount: Number(editingTask.rewardAmount) || 10,
      watchDuration: Number(editingTask.watchDuration) || 8,
      order: Number(editingTask.order) || 1,
      active: editingTask.active ?? true,
      category: 'story',
      mediaType: editingTask.mediaType || 'image',
      completionRequired: true
    };
    const res = await saveTaskByAdmin(taskToSave);
    if (res.success) {
      setTaskMsg('Task updated successfully!');
      setEditingTask(null);
      setIsNewTask(false);
      const updated = await getAllTasksForAdmin();
      setTasks(updated);
      setTimeout(() => setTaskMsg(null), 3000);
    } else {
      setTaskMsg(`Error: ${res.message}`);
    }
  };

  // Handle Withdrawal Process
  const handleApproveWd = async (wd: WithdrawalRequest) => {
    setProcessingWdId(wd.id);
    setWdMsg(null);
    const res = await processWithdrawalByAdmin(wd.id, 'paid');
    setProcessingWdId(null);
    setWdMsg(res.message);
    setTimeout(() => setWdMsg(null), 4000);
  };

  const handleRejectWdConfirm = async () => {
    if (!rejectionModalWd) return;
    setProcessingWdId(rejectionModalWd.id);
    const res = await processWithdrawalByAdmin(rejectionModalWd.id, 'rejected', rejectionReason || 'KYC verification mismatch.');
    setProcessingWdId(null);
    setRejectionModalWd(null);
    setRejectionReason('');
    setWdMsg(res.message);
    setTimeout(() => setWdMsg(null), 4000);
  };

  // Handle Wallet Adjustment
  const handleWalletAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdjMsg(null);
    if (!adjUid.trim()) {
      setAdjMsg({ type: 'error', text: 'Please enter target User UID.' });
      return;
    }
    const num = parseFloat(adjAmount);
    if (isNaN(num) || num <= 0) {
      setAdjMsg({ type: 'error', text: 'Please enter a valid positive adjustment amount.' });
      return;
    }
    if (!adjReason.trim()) {
      setAdjMsg({ type: 'error', text: 'A detailed reason note is mandatory for audit logging.' });
      return;
    }
    if (!currentUser) return;
    setAdjLoading(true);
    const finalAmount = adjType === 'credit' ? num : -num;
    const res = await adjustUserWalletByAdmin(currentUser.uid, adjUid.trim(), finalAmount, adjReason.trim());
    setAdjLoading(false);
    if (res.success) {
      setAdjMsg({ type: 'success', text: res.message });
      setAdjAmount('');
      setAdjReason('');
    } else {
      setAdjMsg({ type: 'error', text: res.message });
    }
  };

  const filteredWd = withdrawals.filter((w) => {
    if (wdFilter === 'all') return true;
    return w.status === wdFilter;
  });

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07060e] text-white overflow-y-auto animate-fade-in">
      {/* Top Header */}
      <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-3.5 glass-panel border-b border-purple-900/30">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-amber-500 flex items-center justify-center text-white shadow-md">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white tracking-wide">ADMINISTRATOR CONTROL PANEL</h2>
            <p className="text-[10px] text-amber-400 font-semibold">ARJ Online Earning Operations</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-xl mx-auto w-full px-4 py-4 flex-1 space-y-4">
        {/* Navigation Tabs */}
        <div className="flex p-1 bg-black/40 rounded-2xl border border-white/10 text-xs font-bold overflow-x-auto no-scrollbar">
          {[
            { id: 'withdrawals', label: `Withdrawals (${withdrawals.filter((w) => w.status === 'pending').length})`, icon: Landmark },
            { id: 'tasks', label: `Tasks (${tasks.length})`, icon: Layers },
            { id: 'kyc', label: `KYC (${kycRecords.filter((k) => k.status === 'pending').length})`, icon: Shield },
            { id: 'settings', label: 'Settings', icon: Settings },
            { id: 'adjustments', label: 'Adjustments', icon: DollarSign }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* 1. WITHDRAWALS TAB */}
        {activeTab === 'withdrawals' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-1 bg-black/40 p-1 rounded-xl border border-white/5 text-[11px]">
                {(['pending', 'paid', 'rejected', 'all'] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setWdFilter(f)}
                    className={`px-2.5 py-1 rounded-lg font-bold capitalize transition-colors ${
                      wdFilter === f ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
              <span className="text-xs text-slate-400">Total: {filteredWd.length}</span>
            </div>

            {wdMsg && (
              <div className="p-3 bg-purple-950/60 border border-purple-500/30 rounded-xl text-xs text-purple-200">
                {wdMsg}
              </div>
            )}

            {filteredWd.length === 0 ? (
              <div className="p-8 text-center glass-card rounded-2xl border border-white/5 text-slate-500 text-xs">
                No withdrawal requests under this filter.
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredWd.map((w) => (
                  <div
                    key={w.id}
                    className="glass-card rounded-2xl p-4 border border-white/5 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-base font-black text-amber-300">₹{w.amount.toFixed(2)}</span>
                        <span className="text-xs text-slate-300 ml-2 font-mono">UPI: {w.payoutDetails.upiId}</span>
                      </div>
                      <span
                        className={`text-[10px] font-bold uppercase px-2.5 py-0.5 rounded-full ${
                          w.status === 'paid'
                            ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/30'
                            : w.status === 'pending'
                            ? 'bg-amber-950/60 text-amber-400 border border-amber-500/30'
                            : 'bg-red-950/60 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {w.status}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-400 flex items-center justify-between">
                      <span>User ID: {w.uid.substring(0, 10)}...</span>
                      <span>{new Date(w.createdAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}</span>
                    </div>

                    {w.status === 'pending' && (
                      <div className="flex items-center space-x-2 pt-1 border-t border-white/5">
                        <button
                          onClick={() => handleApproveWd(w)}
                          disabled={processingWdId === w.id}
                          className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center justify-center space-x-1.5 transition-colors disabled:opacity-50"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>APPROVE & MARK PAID</span>
                        </button>
                        <button
                          onClick={() => setRejectionModalWd(w)}
                          disabled={processingWdId === w.id}
                          className="py-2 px-3 bg-red-600/30 hover:bg-red-600/50 text-red-300 border border-red-500/30 font-bold text-xs rounded-xl flex items-center justify-center space-x-1 transition-colors"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>REJECT</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 2. TASKS MANAGEMENT TAB */}
        {activeTab === 'tasks' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">Active Tasks & Stories</h3>
                <p className="text-[10px] text-slate-400">Configure rewards and watch requirements</p>
              </div>
              <button
                onClick={() => {
                  setEditingTask({
                    id: `task_${Date.now()}`,
                    title: 'New Promotional Task',
                    description: 'Complete task to earn reward.',
                    rewardAmount: 10,
                    watchDuration: 8,
                    active: true,
                    order: tasks.length + 1,
                    mediaUrl: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=1080&q=80',
                    thumbnailUrl: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=300&q=80'
                  });
                  setIsNewTask(true);
                }}
                className="py-2 px-3 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl flex items-center space-x-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>ADD TASK</span>
              </button>
            </div>

            {taskMsg && (
              <div className="p-3 bg-purple-950/60 border border-purple-500/30 rounded-xl text-xs text-purple-200">
                {taskMsg}
              </div>
            )}

            {/* Editing Form Modal */}
            {editingTask && (
              <div className="glass-card-gold rounded-2xl p-4 border border-amber-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-amber-300 uppercase">
                    {isNewTask ? 'Create New Task' : 'Edit Task'}
                  </h4>
                  <button onClick={() => setEditingTask(null)} className="text-slate-400 hover:text-white">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <form onSubmit={handleSaveTask} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Task Title</label>
                    <input
                      type="text"
                      value={editingTask.title || ''}
                      onChange={(e) => setEditingTask({ ...editingTask, title: e.target.value })}
                      className="w-full px-3 py-2 bg-[#0d0c1c] border border-white/10 rounded-xl text-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Description</label>
                    <input
                      type="text"
                      value={editingTask.description || ''}
                      onChange={(e) => setEditingTask({ ...editingTask, description: e.target.value })}
                      className="w-full px-3 py-2 bg-[#0d0c1c] border border-white/10 rounded-xl text-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Reward (₹)</label>
                      <input
                        type="number"
                        min="1"
                        value={editingTask.rewardAmount || 10}
                        onChange={(e) => setEditingTask({ ...editingTask, rewardAmount: Number(e.target.value) })}
                        className="w-full px-3 py-2 bg-[#0d0c1c] border border-white/10 rounded-xl text-white font-bold text-amber-300"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Watch Duration (sec)</label>
                      <input
                        type="number"
                        min="1"
                        value={editingTask.watchDuration || 8}
                        onChange={(e) => setEditingTask({ ...editingTask, watchDuration: Number(e.target.value) })}
                        className="w-full px-3 py-2 bg-[#0d0c1c] border border-white/10 rounded-xl text-white"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Media URL (Image or Video)</label>
                    <input
                      type="text"
                      value={editingTask.mediaUrl || ''}
                      onChange={(e) => setEditingTask({ ...editingTask, mediaUrl: e.target.value })}
                      className="w-full px-3 py-2 bg-[#0d0c1c] border border-white/10 rounded-xl text-white font-mono text-[11px]"
                    />
                  </div>
                  <div className="flex items-center space-x-2 pt-1">
                    <input
                      type="checkbox"
                      id="activeTask"
                      checked={editingTask.active ?? true}
                      onChange={(e) => setEditingTask({ ...editingTask, active: e.target.checked })}
                      className="w-4 h-4 rounded bg-[#0d0c1c] text-purple-600"
                    />
                    <label htmlFor="activeTask" className="text-slate-200 font-bold">Active for Users</label>
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-extrabold text-xs uppercase rounded-xl transition-all"
                  >
                    SAVE TASK
                  </button>
                </form>
              </div>
            )}

            {/* Tasks list */}
            <div className="space-y-2">
              {tasks.map((t) => (
                <div
                  key={t.id}
                  className="glass-card rounded-2xl p-3.5 border border-white/5 flex items-center justify-between"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-950/40 border border-purple-500/20 overflow-hidden flex-shrink-0">
                      <img src={t.thumbnailUrl || t.mediaUrl} alt={t.title} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white flex items-center space-x-1.5">
                        <span>{t.title}</span>
                        {!t.active && (
                          <span className="text-[9px] bg-red-950 text-red-300 px-1 rounded">Inactive</span>
                        )}
                      </h4>
                      <p className="text-[10px] text-slate-400">
                        Reward: <strong className="text-amber-300">₹{t.rewardAmount}</strong> • {t.watchDuration}s watch
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setEditingTask(t);
                      setIsNewTask(false);
                    }}
                    className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 3. SETTINGS TAB */}
        {activeTab === 'settings' && (
          <form onSubmit={handleSaveSettings} className="glass-card rounded-3xl p-5 border border-purple-500/20 space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-2">
              Reward & System Rules Configuration
            </h3>

            {settingsMsg && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">
                {settingsMsg}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Minimum Withdrawal (₹)
              </label>
              <input
                type="number"
                min="10"
                value={minWd}
                onChange={(e) => setMinWd(Number(e.target.value))}
                className="w-full px-4 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Referral Reward Per Invite (₹)
              </label>
              <input
                type="number"
                min="0"
                value={refReward}
                onChange={(e) => setRefReward(Number(e.target.value))}
                className="w-full px-4 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs text-white font-bold text-amber-300"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Referral Eligibility Condition
              </label>
              <select
                value={refEligibility}
                onChange={(e) => setRefEligibility(e.target.value as any)}
                className="w-full px-4 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs text-white"
              >
                <option value="first_task_completion">When friend completes first task (Anti-Abuse Recommended)</option>
                <option value="instant_on_register">Instant on friend registration</option>
                <option value="kyc_approved">When friend's KYC is approved</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Daily Spin Limit
                </label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={dailySpinLimit}
                  onChange={(e) => setDailySpinLimit(Number(e.target.value))}
                  className="w-full px-4 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Daily Scratch Limit
                </label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={dailyScratchLimit}
                  onChange={(e) => setDailyScratchLimit(Number(e.target.value))}
                  className="w-full px-4 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs text-white font-bold text-pink-300"
                />
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-black/40 rounded-xl border border-white/5">
              <div>
                <span className="text-xs font-bold text-white block">Spin Wheel Feature Enabled</span>
                <span className="text-[10px] text-slate-400">Allow users to play 8-sector Spin Wheel (₹1 to ₹20)</span>
              </div>
              <input
                type="checkbox"
                checked={spinWheelEnabled}
                onChange={(e) => setSpinWheelEnabled(e.target.checked)}
                className="w-5 h-5 rounded bg-[#0d0c1c] text-purple-600"
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-black/40 rounded-xl border border-white/5">
              <div>
                <span className="text-xs font-bold text-white block">Scratch Cards Feature Enabled</span>
                <span className="text-[10px] text-slate-400">Allow users to play interactive Scratch Cards (₹1 to ₹20)</span>
              </div>
              <input
                type="checkbox"
                checked={scratchCardsEnabled}
                onChange={(e) => setScratchCardsEnabled(e.target.checked)}
                className="w-5 h-5 rounded bg-[#0d0c1c] text-purple-600"
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-black/40 rounded-xl border border-white/5">
              <div>
                <span className="text-xs font-bold text-white block">LIVE Withdrawal Demo Ticker Mode</span>
                <span className="text-[10px] text-slate-400">Shows labeled demo ticker only if database has zero withdrawals</span>
              </div>
              <input
                type="checkbox"
                checked={demoTicker}
                onChange={(e) => setDemoTicker(e.target.checked)}
                className="w-5 h-5 rounded bg-[#0d0c1c] text-purple-600"
              />
            </div>

            <button
              type="submit"
              disabled={settingsSaving}
              className="w-full py-3.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wide rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>SAVE APP SETTINGS</span>
            </button>
          </form>
        )}

        {/* 4. KYC TAB */}
        {activeTab === 'kyc' && (
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">KYC Submissions ({kycRecords.length})</h3>
            {kycRecords.length === 0 ? (
              <div className="p-8 text-center glass-card rounded-2xl border border-white/5 text-slate-500 text-xs">
                No KYC documents submitted yet.
              </div>
            ) : (
              kycRecords.map((k) => (
                <div key={k.uid} className="glass-card rounded-2xl p-4 border border-white/5 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-white">{k.fullName}</h4>
                      <p className="text-[10px] text-slate-400">{k.identityType}: {k.identityNumber}</p>
                    </div>
                    <span
                      className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-full ${
                        k.status === 'approved'
                          ? 'bg-emerald-950/60 text-emerald-400'
                          : k.status === 'pending'
                          ? 'bg-amber-950/60 text-amber-400'
                          : 'bg-red-950/60 text-red-400'
                      }`}
                    >
                      {k.status}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px] bg-black/30 p-2.5 rounded-xl border border-white/5">
                    <div>
                      <span className="text-slate-500 block text-[9px] uppercase">Email</span>
                      <span className="text-white truncate block">{k.email || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px] uppercase">Mobile</span>
                      <span className="text-white block">{k.phone || 'N/A'}</span>
                    </div>
                  </div>
                  {k.documentUrl ? (
                    <div className="pt-1">
                      <a
                        href={k.documentUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-purple-400 hover:underline flex items-center space-x-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Document Attachment</span>
                      </a>
                    </div>
                  ) : (
                    <div className="pt-1 text-[10px] text-slate-400 flex items-center space-x-1">
                      <CheckCircle2 className="w-3 h-3 text-violet-400" />
                      <span>Verified ID Number Submission (No file required)</span>
                    </div>
                  )}
                  {k.status === 'pending' && (
                    <div className="flex items-center space-x-2 pt-2 border-t border-white/5">
                      <button
                        onClick={async () => {
                          await reviewKycByAdmin(k.uid, 'approved');
                          const updated = await subscribeAllKyc(setKycRecords);
                        }}
                        className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl"
                      >
                        Approve KYC
                      </button>
                      <button
                        onClick={async () => {
                          const r = prompt('Reason for rejection:');
                          if (r) {
                            await reviewKycByAdmin(k.uid, 'rejected', r);
                          }
                        }}
                        className="py-1.5 px-3 bg-red-600/30 text-red-300 border border-red-500/30 font-bold text-xs rounded-xl"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* 5. AUDITABLE ADJUSTMENTS TAB */}
        {activeTab === 'adjustments' && (
          <div className="glass-card rounded-3xl p-5 border border-purple-500/20">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-1">
              Auditable Manual Balance Adjustment
            </h3>
            <p className="text-[11px] text-slate-400 mb-4">
              Allows administrators to correct verified transaction errors. Every adjustment is recorded in the ledger with your administrator signature and reason note.
            </p>

            {adjMsg && (
              <div
                className={`mb-4 p-3 rounded-xl text-xs ${
                  adjMsg.type === 'success'
                    ? 'bg-emerald-950/40 border border-emerald-500/30 text-emerald-300'
                    : 'bg-red-950/40 border border-red-500/30 text-red-300'
                }`}
              >
                {adjMsg.text}
              </div>
            )}

            <form onSubmit={handleWalletAdjustment} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Target User UID</label>
                <input
                  type="text"
                  value={adjUid}
                  onChange={(e) => setAdjUid(e.target.value)}
                  placeholder="Paste User UID (e.g. kldsf...)"
                  className="w-full px-3.5 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-white font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Adjustment Type</label>
                  <select
                    value={adjType}
                    onChange={(e) => setAdjType(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-white font-bold"
                  >
                    <option value="credit">Credit Balance (+)</option>
                    <option value="debit">Debit Balance (-)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Amount (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={adjAmount}
                    onChange={(e) => setAdjAmount(e.target.value)}
                    placeholder="e.g. 100"
                    className="w-full px-3.5 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-white font-bold text-amber-300"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Mandatory Audit Reason Note</label>
                <textarea
                  rows={2}
                  value={adjReason}
                  onChange={(e) => setAdjReason(e.target.value)}
                  placeholder="e.g. Correction for missed task credit on 2026-10-10"
                  className="w-full px-3.5 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-white"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={adjLoading}
                className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-yellow-600 text-black font-extrabold text-xs uppercase tracking-wide rounded-xl shadow-lg transition-all"
              >
                {adjLoading ? 'PROCESSING ADJUSTMENT...' : 'APPLY AUDITED ADJUSTMENT'}
              </button>
            </form>

            {/* Blue Verified Badge Approval Tool */}
            <div className="mt-6 pt-5 border-t border-white/10">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-1 flex items-center space-x-1.5">
                <span className="w-4 h-4 rounded-full bg-blue-500 text-white inline-flex items-center justify-center text-[10px]">✓</span>
                <span>Profile Blue Verified Badge Management</span>
              </h4>
              <p className="text-[11px] text-slate-400 mb-3">
                Authorized administrators can approve or revoke the blue tick badge for verified accounts. Separate from KYC verification.
              </p>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  placeholder="Target User UID to verify/unverify"
                  value={adjUid}
                  onChange={(e) => setAdjUid(e.target.value)}
                  className="flex-1 px-3.5 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-white font-mono text-xs"
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      if (!adjUid.trim()) {
                        setAdjMsg({ type: 'error', text: 'Enter target user UID first' });
                        return;
                      }
                      const res = await setUserVerificationStatusByAdmin(adjUid.trim(), true);
                      setAdjMsg({ type: res.success ? 'success' : 'error', text: res.message });
                    }}
                    className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors"
                  >
                    Grant Blue Tick
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      if (!adjUid.trim()) {
                        setAdjMsg({ type: 'error', text: 'Enter target user UID first' });
                        return;
                      }
                      const res = await setUserVerificationStatusByAdmin(adjUid.trim(), false);
                      setAdjMsg({ type: res.success ? 'success' : 'error', text: res.message });
                    }}
                    className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-slate-300 font-bold text-xs rounded-xl transition-colors"
                  >
                    Revoke
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Withdrawal Rejection Reason Modal */}
      {rejectionModalWd && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm glass-card rounded-2xl p-5 border border-red-500/30 space-y-3">
            <h3 className="text-xs font-bold text-red-300 uppercase">Reject Withdrawal Request</h3>
            <p className="text-xs text-slate-300">
              Rejecting withdrawal of ₹{rejectionModalWd.amount} will automatically refund the funds to the user's available balance.
            </p>
            <textarea
              rows={3}
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              placeholder="State reason for rejection (e.g. Invalid UPI ID / KYC name mismatch)"
              className="w-full p-2.5 bg-[#0d0c1c] border border-white/10 rounded-xl text-xs text-white"
            />
            <div className="flex space-x-2 pt-1">
              <button
                onClick={() => setRejectionModalWd(null)}
                className="flex-1 py-2 bg-white/10 text-slate-300 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleRejectWdConfirm}
                className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl"
              >
                Confirm Reject
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
