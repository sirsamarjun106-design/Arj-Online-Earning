import React from 'react';
import {
  User,
  Settings,
  Bell,
  KeyRound,
  FileText,
  Shield,
  HelpCircle,
  LogOut,
  ChevronRight,
  ShieldCheck,
  Tag,
  Phone,
  Mail,
  Lock
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface ProfilePageProps {
  onOpenSettings: () => void;
  onOpenNotifications: () => void;
  onOpenChangePassword: () => void;
  onOpenTerms: () => void;
  onOpenPrivacy: () => void;
  onOpenSupport: () => void;
  onOpenKyc: () => void;
  onOpenAdmin?: () => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({
  onOpenSettings,
  onOpenNotifications,
  onOpenChangePassword,
  onOpenTerms,
  onOpenPrivacy,
  onOpenSupport,
  onOpenKyc,
  onOpenAdmin
}) => {
  const { userProfile, logout, isAdmin } = useAuth();
  const referralCode = userProfile?.referralCode || 'ARJ50X';

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
  };

  const menuItems = [
    ...(isAdmin && onOpenAdmin
      ? [{ label: '👑 Administrator Control Panel', icon: Shield, onClick: onOpenAdmin, highlight: true }]
      : []),
    { label: 'Account Settings', icon: Settings, onClick: onOpenSettings },
    { label: 'Notification Center', icon: Bell, onClick: onOpenNotifications },
    { label: 'Change Password', icon: KeyRound, onClick: onOpenChangePassword },
    { label: 'KYC Document Verification', icon: ShieldCheck, onClick: onOpenKyc },
    { label: 'Terms & Conditions', icon: FileText, onClick: onOpenTerms },
    { label: 'Privacy Policy', icon: Shield, onClick: onOpenPrivacy },
    { label: 'Help & Support', icon: HelpCircle, onClick: onOpenSupport }
  ];

  const displayName =
    userProfile?.name?.trim() ||
    userProfile?.email?.split('@')[0] ||
    'Member';

  // Verification status is determined strictly from trusted database properties
  const isVerifiedUser = Boolean(
    userProfile?.isVerified === true ||
    userProfile?.verified === true ||
    userProfile?.role === 'admin'
  );

  return (
    <div className="space-y-5 pb-6">
      {/* Profile Header Card */}
      <div className="glass-card rounded-3xl p-6 border border-purple-500/25 relative overflow-hidden">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-amber-500 p-0.5 shadow-xl shadow-purple-950/50 flex-shrink-0">
            <div className="w-full h-full bg-[#100e22] rounded-[14px] flex items-center justify-center overflow-hidden">
              {userProfile?.avatarUrl ? (
                <img src={userProfile.avatarUrl} alt={displayName} className="w-full h-full object-cover" />
              ) : (
                <span className="text-2xl font-black text-amber-300">
                  {displayName.charAt(0).toUpperCase()}
                </span>
              )}
            </div>
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center space-x-1.5 flex-wrap">
              <h2 className="text-lg font-bold text-white tracking-tight inline-flex items-center">
                <span className="truncate max-w-[190px] sm:max-w-[260px]">{displayName}</span>
              </h2>

              {/* Professional Blue Verified Tick Badge (🔵✓) immediately after the user's name */}
              {isVerifiedUser && (
                <span
                  title="Verified Account"
                  className="inline-flex items-center justify-center w-[18px] h-[18px] rounded-full bg-[#1d9bf0] text-white shadow-md shadow-[#1d9bf0]/40 flex-shrink-0 select-none"
                  aria-label="Verified user"
                >
                  <svg
                    className="w-2.5 h-2.5"
                    viewBox="0 0 16 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M13.5 4.5L6.5 11.5L3 8"
                      stroke="#ffffff"
                      strokeWidth="2.3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </span>
              )}

              {isAdmin && (
                <span className="text-[9px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/40 px-2 py-0.5 rounded-full ml-1">
                  ADMIN
                </span>
              )}
            </div>

            <div className="flex items-center space-x-1.5 text-xs text-slate-400 mt-1 truncate">
              <Mail className="w-3.5 h-3.5 flex-shrink-0" />
              <span className="truncate">{userProfile?.email}</span>
            </div>
            {userProfile?.phone && (
              <div className="flex items-center space-x-1.5 text-xs text-slate-400 mt-0.5">
                <Phone className="w-3.5 h-3.5 flex-shrink-0" />
                <span>{userProfile.phone}</span>
              </div>
            )}
          </div>
        </div>

        {/* Status Pills */}
        <div className="grid grid-cols-2 gap-2 mt-5 pt-4 border-t border-white/10 text-xs">
          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between">
            <span className="text-slate-400 text-[11px]">KYC Status</span>
            <span
              className={`font-bold uppercase text-[10px] px-2 py-0.5 rounded-full ${
                userProfile?.kycStatus === 'approved'
                  ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/30'
                  : userProfile?.kycStatus === 'pending'
                  ? 'bg-amber-950/60 text-amber-400 border border-amber-500/30'
                  : 'bg-slate-800 text-slate-300'
              }`}
            >
              {userProfile?.kycStatus || 'Unverified'}
            </span>
          </div>
          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between">
            <span className="text-slate-400 text-[11px]">Account</span>
            <span className="font-bold uppercase text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/60 text-emerald-400 border border-emerald-500/30">
              {userProfile?.accountStatus || 'Active'}
            </span>
          </div>
        </div>

        {/* Referral Code Mini Banner */}
        <div className="mt-3 p-2.5 rounded-xl bg-purple-950/40 border border-purple-500/30 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-1.5 text-purple-300">
            <Tag className="w-3.5 h-3.5 text-amber-400" />
            <span>Referral: <strong className="text-amber-300 font-mono">{referralCode}</strong></span>
          </div>
          <button
            onClick={handleCopyCode}
            className="text-[10px] font-bold text-amber-400 hover:text-amber-300 bg-amber-400/10 px-2.5 py-1 rounded-md"
          >
            Copy
          </button>
        </div>
      </div>

      {/* Profile Menu List */}
      <div className="glass-card rounded-3xl p-3 border border-purple-500/20 divide-y divide-white/5">
        {menuItems.map((item, idx) => {
          const Icon = item.icon;
          return (
            <button
              key={idx}
              onClick={item.onClick}
              className={`w-full p-3.5 flex items-center justify-between text-left text-xs font-semibold rounded-2xl transition-colors group ${
                (item as any).highlight
                  ? 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 my-1'
                  : 'text-slate-200 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors ${
                    (item as any).highlight
                      ? 'bg-amber-500/20 text-amber-400'
                      : 'bg-purple-950/50 border border-purple-500/20 text-purple-300 group-hover:text-amber-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <span>{item.label}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-slate-300 transition-colors" />
            </button>
          );
        })}
      </div>

      {/* Logout Button */}
      <button
        onClick={logout}
        className="w-full py-3.5 px-4 rounded-2xl bg-red-950/30 hover:bg-red-950/50 border border-red-500/30 text-red-400 font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 transition-colors"
      >
        <LogOut className="w-4 h-4" />
        <span>LOGOUT</span>
      </button>
    </div>
  );
};
