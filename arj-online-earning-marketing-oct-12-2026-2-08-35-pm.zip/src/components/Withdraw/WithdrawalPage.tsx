import React, { useState } from 'react';
import {
  Landmark,
  X,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  Clock,
  ShieldCheck,
  CreditCard,
  HelpCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { AppSettingsConfig, WithdrawalRequest, PaymentSettingsConfig } from '../../types';
import { submitWithdrawalRequest } from '../../services/firestoreService';

interface WithdrawalPageProps {
  isOpen: boolean;
  onClose: () => void;
  appSettings: AppSettingsConfig;
  paymentSettings: PaymentSettingsConfig;
  withdrawals: WithdrawalRequest[];
  onRequireKyc: (amount: number, upiId: string) => void;
  onOpenPaymentFee?: () => void;
}

export const WithdrawalPage: React.FC<WithdrawalPageProps> = ({
  isOpen,
  onClose,
  appSettings,
  paymentSettings,
  withdrawals,
  onRequireKyc
}) => {
  const { currentUser, userProfile, wallet } = useAuth();
  const [amount, setAmount] = useState('');
  const [upiId, setUpiId] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const availableBalance = wallet?.availableBalance ?? 0;
  const pendingBalance = wallet?.pendingBalance ?? 0;
  const minWithdrawal = appSettings.minimumWithdrawal || 149;
  const maxWithdrawal = appSettings.maximumWithdrawal || 100000;

  // Check if there is an active pending withdrawal
  const hasPendingWithdrawal = withdrawals.some((w) => w.status === 'pending' || w.status === 'processing');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const numAmount = parseFloat(amount) || minWithdrawal;

    if (isNaN(numAmount) || numAmount < minWithdrawal) {
      setErrorMessage(`Please enter a valid withdrawal amount. Minimum is ₹${minWithdrawal}.`);
      return;
    }

    if (numAmount > maxWithdrawal) {
      setErrorMessage(`Maximum withdrawal amount per request is ₹${maxWithdrawal}.`);
      return;
    }

    if (!upiId.trim() || !upiId.includes('@')) {
      setErrorMessage('Please enter a valid UPI ID (e.g. mobile@upi or username@okaxis).');
      return;
    }

    if (hasPendingWithdrawal) {
      setErrorMessage('You already have a withdrawal request in progress. Please wait for it to be confirmed.');
      return;
    }

    // Step Check: KYC must be approved
    if (userProfile?.kycStatus !== 'approved') {
      onRequireKyc(numAmount, upiId.trim());
      return;
    }

    // Balance check
    if (numAmount > availableBalance) {
      setErrorMessage(`Insufficient withdrawable balance. Your available balance is ₹${availableBalance.toFixed(2)}.`);
      return;
    }

    if (!currentUser) return;

    setLoading(true);
    const res = await submitWithdrawalRequest(
      currentUser.uid,
      numAmount,
      upiId.trim(),
      userProfile?.name,
      userProfile?.phone
    );
    setLoading(false);

    if (res.success) {
      setSuccessMessage(res.message);
      setAmount('');
      setUpiId('');
    } else {
      setErrorMessage(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07060e] text-white overflow-y-auto animate-fade-in">
      {/* Top Header */}
      <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-4 glass-panel border-b border-purple-900/30">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-300">
            <Landmark className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">UPI WITHDRAWAL</h2>
            <p className="text-[10px] text-slate-400">Direct Bank / UPI Payout</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-md mx-auto w-full px-5 py-6 flex-1 space-y-5">
        {/* Available Balance Box */}
        <div className="glass-card rounded-2xl p-4 border border-purple-500/25 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
              Withdrawable Balance
            </span>
            <span className="text-2xl font-black text-amber-300">
              ₹{availableBalance.toFixed(2)}
            </span>
            {pendingBalance > 0 && (
              <span className="text-[10px] text-slate-400 block mt-0.5">
                (₹{pendingBalance.toFixed(2)} pending in processing)
              </span>
            )}
          </div>
          <div className="text-right text-[11px] text-slate-400">
            <span className="block">Min: ₹{minWithdrawal}</span>
            <span className="block">Max: ₹{maxWithdrawal}</span>
          </div>
        </div>

        {/* Error & Success Messages */}
        {errorMessage && (
          <div className="flex items-start space-x-2.5 rounded-xl bg-red-950/40 border border-red-500/30 p-3 text-xs text-red-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="flex items-start space-x-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 p-3 text-xs text-emerald-300">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400 mt-0.5" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Main Withdrawal Form */}
        <div className="glass-card rounded-3xl p-5 border border-purple-500/20">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-200 mb-1.5">
                Withdrawal Amount (₹)
              </label>
              <input
                type="number"
                min={minWithdrawal}
                max={maxWithdrawal}
                step="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder={`Minimum ₹${minWithdrawal}`}
                className="w-full px-4 py-3 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-base font-bold text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
              <div className="flex justify-between items-center mt-1.5 text-[10px] text-slate-400">
                <span>Fee: ₹0 (No deduction)</span>
                <button
                  type="button"
                  onClick={() => setAmount(String(Math.max(minWithdrawal, Math.floor(availableBalance))))}
                  className="text-amber-400 font-bold hover:underline"
                >
                  Withdraw All Available
                </button>
              </div>

              {/* Quick Preset Amount Chips */}
              <div className="flex items-center space-x-2 mt-2.5">
                {[149, 200, 500, 1000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setAmount(String(preset))}
                    className="flex-1 py-1.5 px-2 bg-purple-900/30 hover:bg-purple-900/50 border border-purple-500/20 rounded-lg text-xs font-bold text-purple-200 transition-colors"
                  >
                    ₹{preset}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-200 mb-1.5">
                Payout Method
              </label>
              <div className="px-4 py-2.5 bg-black/40 border border-white/10 rounded-xl text-xs font-bold text-slate-200 flex items-center justify-between">
                <span>UPI (Google Pay / PhonePe / Paytm / BHIM)</span>
                <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-950/40 px-2 py-0.5 rounded-md border border-emerald-500/20">
                  Instant Transfer
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-200 mb-1.5">
                Registered UPI ID
              </label>
              <input
                type="text"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="mobile@paytm or username@okhdfcbank"
                className="w-full px-4 py-3 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
            </div>

            <button
              type="submit"
              disabled={loading || hasPendingWithdrawal}
              className="w-full py-4 px-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-extrabold text-sm uppercase tracking-wide rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>REQUEST WITHDRAWAL</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>

        {/* Withdrawal History */}
        <div>
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
            Withdrawal History ({withdrawals.length})
          </h3>
          {withdrawals.length === 0 ? (
            <div className="text-center py-6 glass-card rounded-2xl border border-white/5 text-slate-500 text-xs">
              No withdrawal requests placed yet.
            </div>
          ) : (
            <div className="space-y-2.5">
              {withdrawals.map((w) => (
                <div
                  key={w.id}
                  className="glass-card rounded-2xl p-3.5 border border-white/5 flex items-center justify-between"
                >
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-bold text-white">₹{w.amount.toFixed(2)}</span>
                      <span className="text-[10px] text-slate-400">via {w.payoutDetails?.upiId}</span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      {new Date(w.createdAt).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </p>
                    {w.rejectionReason && (
                      <p className="text-[10px] text-red-400 mt-1">Reason: {w.rejectionReason}</p>
                    )}
                  </div>
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
                      w.status === 'paid'
                        ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/30'
                        : w.status === 'processing'
                        ? 'bg-blue-950/60 text-blue-400 border border-blue-500/30'
                        : w.status === 'pending'
                        ? 'bg-amber-950/60 text-amber-400 border border-amber-500/30'
                        : 'bg-red-950/60 text-red-400 border border-red-500/30'
                    }`}
                  >
                    {w.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
