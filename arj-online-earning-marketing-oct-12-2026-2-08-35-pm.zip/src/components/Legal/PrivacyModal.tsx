import React from 'react';
import { X, Shield } from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07060e] text-white overflow-y-auto animate-fade-in">
      <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-4 glass-panel border-b border-purple-900/30">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">PRIVACY POLICY</h2>
            <p className="text-[10px] text-slate-400">Data Protection & Privacy Standards</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-md mx-auto w-full px-5 py-6 flex-1 space-y-6 text-xs text-slate-300 leading-relaxed">
        <div className="p-4 rounded-2xl bg-black/40 border border-white/5 text-slate-400 text-[11px]">
          ARJ Online Earning Marketing respects your privacy and is committed to protecting your personal data in compliance with IT and financial data security guidelines.
        </div>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">1. Information We Collect</h3>
          <p>We collect only the minimum information necessary to provide legitimate reward services:</p>
          <ul className="list-disc list-inside space-y-1 pl-2 text-slate-400">
            <li><strong>Personal Identity:</strong> Full Name, Email Address, and Mobile Phone Number.</li>
            <li><strong>Referral Data:</strong> Referral codes, inviter associations, and reward linkages.</li>
            <li><strong>Transaction Ledger:</strong> Wallet credits, debits, UPI IDs, withdrawal requests, and payment UTRs.</li>
            <li><strong>KYC Documents:</strong> PAN card number, identity document type, and uploaded document scans.</li>
          </ul>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">2. How We Use Your Data</h3>
          <p>Your information is utilized solely to:</p>
          <ul className="list-disc list-inside space-y-1 pl-2 text-slate-400">
            <li>Authenticate user login and safeguard wallet security.</li>
            <li>Prevent duplicate account creation, sybil attacks, and unauthorized bots.</li>
            <li>Verify identity compliance prior to releasing bank/UPI withdrawals.</li>
            <li>Deliver transactional notifications and essential customer service assistance.</li>
          </ul>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">3. Data Security & Storage</h3>
          <p>
            All sensitive assets, including uploaded KYC documents, are stored securely within private Firebase Cloud Storage buckets protected by strict role-based access rules. Documents are never made publicly accessible.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">4. Third-Party Disclosures</h3>
          <p>
            We do not sell, rent, or trade your personal information to third-party marketing companies. Data is shared exclusively with verified banking and payment gateway partners (such as ZapUPI) strictly for processing requested payouts and verification charges.
          </p>
        </section>
      </div>
    </div>
  );
};
