import React from 'react';
import { X, FileText } from 'lucide-react';

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TermsModal: React.FC<TermsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07060e] text-white overflow-y-auto animate-fade-in">
      <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-4 glass-panel border-b border-purple-900/30">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
            <FileText className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">TERMS & CONDITIONS</h2>
            <p className="text-[10px] text-slate-400">ARJ Online Earning Marketing</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-md mx-auto w-full px-5 py-6 flex-1 space-y-6 text-xs text-slate-300 leading-relaxed">
        <div className="p-4 rounded-2xl bg-black/40 border border-white/5 text-slate-400 text-[11px]">
          Last Updated: October 2026 • Please read these terms carefully before registering or using ARJ Online Earning Marketing services.
        </div>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">1. Introduction</h3>
          <p>
            Welcome to ARJ Online Earning Marketing (&quot;Platform&quot;, &quot;we&quot;, &quot;us&quot;, or &quot;our&quot;). By creating an account or accessing our services, you agree to comply with and be bound by these Terms and Conditions in full.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">2. Platform Usage</h3>
          <p>
            Users must be at least 18 years of age or possess legal capacity in their jurisdiction. You agree to use the platform solely for lawful reward participation and marketing promotional viewing.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">3. Reward Rules</h3>
          <p>
            Rewards credited to your available balance represent promotional incentives earned through genuine engagement. No rewards represent a guaranteed return or investment income.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">4. Spin Rules</h3>
          <p>
            Users are allocated up to 10 daily spins by default. Reward outcomes (ranging between ₹1 to ₹20) are generated randomly. Daily spin counters reset strictly at 00:00 AM IST.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">5. Story Watch Rules</h3>
          <p>
            Promotional status stories must be watched in their entirety until the countdown completes. Automated scripts, accelerated video bypasses, or headless browsers will void reward claims.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">6. Referral Rules</h3>
          <p>
            Referral rewards are credited only when the invited individual completes legitimate registration and initial task eligibility. Self-referrals or emulator accounts are strictly prohibited.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">7. Withdrawal Rules</h3>
          <p>
            The minimum withdrawal threshold is ₹149. Payouts are made directly to the user's verified UPI ID. Processing typically takes between 2 to 24 hours following audit.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">8. KYC Requirements</h3>
          <p>
            To prevent money laundering, financial deception, and duplicate accounts, users must complete Know Your Customer (KYC) identity verification with a recognized government ID (such as PAN).
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">9. Zero Verification Fees</h3>
          <p>
            KYC identity verification is 100% free of cost on ARJ Online Earning. No administrative or verification fee is charged to users for verifying accounts or requesting withdrawals.
          </p>
        </section>

        <section className="space-y-1.5">
          <h3 className="text-sm font-bold text-white">10. Fraud & Duplicate Account Policy</h3>
          <p>
            Only one account is permitted per individual and device. Creating multiple fake accounts, using VPNs, or utilizing automated bot traffic will result in immediate permanent account suspension.
          </p>
        </section>
      </div>
    </div>
  );
};
