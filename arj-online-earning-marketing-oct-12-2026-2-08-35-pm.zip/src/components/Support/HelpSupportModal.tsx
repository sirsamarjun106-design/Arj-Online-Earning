import React, { useState } from 'react';
import {
  X,
  HelpCircle,
  MessageCircle,
  Mail,
  ChevronDown,
  ChevronUp,
  Send,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { submitSupportTicket } from '../../services/firestoreService';
import { SupportTicket, AppSettingsConfig } from '../../types';

interface HelpSupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  appSettings: AppSettingsConfig;
  userTickets: SupportTicket[];
  onTicketSubmitted: () => void;
}

export const HelpSupportModal: React.FC<HelpSupportModalProps> = ({
  isOpen,
  onClose,
  appSettings,
  userTickets,
  onTicketSubmitted
}) => {
  const { currentUser, userProfile } = useAuth();
  const [activeTab, setActiveTab] = useState<'faq' | 'ticket' | 'my-tickets'>('faq');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState('Withdrawal');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isOpen) return null;

  const faqs = [
    {
      q: 'When do daily spins and story rewards reset?',
      a: 'All daily earning tasks, including your 10 spins and story viewing limits, reset automatically every midnight at 00:00 AM IST.'
    },
    {
      q: 'How long does UPI withdrawal processing take?',
      a: 'Withdrawal requests are processed via automated banking and administrative approval. Most verified requests are credited within 2 to 24 hours.'
    },
    {
      q: 'Why is KYC identity verification required?',
      a: 'To comply with financial regulations and eliminate bot fraud, users must complete a one-time KYC verification before requesting payouts.'
    },
    {
      q: 'Is there any fee for KYC verification or withdrawals?',
      a: 'No. KYC identity verification and UPI payouts on ARJ Online Earning are completely free of charge. You do not need to pay any fee to activate withdrawals.'
    },
    {
      q: 'How does the Refer & Earn program work?',
      a: 'Share your referral code. When your invited contact registers and completes their initial eligible task, you receive a referral reward credited to your wallet.'
    }
  ];

  const handleOpenWhatsApp = () => {
    const phone = appSettings.supportWhatsApp || '+919876543210';
    window.open(`https://api.whatsapp.com/send?phone=${phone.replace(/[^0-9]/g, '')}&text=Hello%20ARJ%20Support,%20I%20need%20assistance.`, '_blank');
  };

  const handleEmailSupport = () => {
    const email = appSettings.supportEmail || 'support@arjonline.com';
    window.location.href = `mailto:${email}?subject=ARJ Support Request - User: ${userProfile?.name || ''}`;
  };

  const handleTicketSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);

    if (!subject.trim()) {
      setStatusMsg({ type: 'error', text: 'Please enter a ticket subject.' });
      return;
    }
    if (!description.trim()) {
      setStatusMsg({ type: 'error', text: 'Please describe your inquiry in detail.' });
      return;
    }

    if (!currentUser) return;
    setLoading(true);

    const res = await submitSupportTicket({
      uid: currentUser.uid,
      userName: userProfile?.name || 'Member',
      userEmail: userProfile?.email || '',
      subject: subject.trim(),
      category,
      description: description.trim()
    });

    setLoading(false);

    if (res.success) {
      setStatusMsg({ type: 'success', text: res.message });
      setSubject('');
      setDescription('');
      onTicketSubmitted();
      setTimeout(() => setActiveTab('my-tickets'), 1200);
    } else {
      setStatusMsg({ type: 'error', text: res.message });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07060e] text-white overflow-y-auto animate-fade-in">
      <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-4 glass-panel border-b border-purple-900/30">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
            <HelpCircle className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wide">HELP & SUPPORT</h2>
            <p className="text-[10px] text-slate-400">24/7 Member Care</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-w-md mx-auto w-full px-5 py-5 flex-1 space-y-5">
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleOpenWhatsApp}
            className="p-3.5 glass-card rounded-2xl border border-emerald-500/30 flex items-center space-x-3 text-left hover:border-emerald-400 transition-colors"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">WhatsApp Help</span>
              <span className="text-[10px] text-emerald-400">Instant Chat</span>
            </div>
          </button>
          <button
            onClick={handleEmailSupport}
            className="p-3.5 glass-card rounded-2xl border border-blue-500/30 flex items-center space-x-3 text-left hover:border-blue-400 transition-colors"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center flex-shrink-0">
              <Mail className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">Email Support</span>
              <span className="text-[10px] text-blue-400">Official Desk</span>
            </div>
          </button>
        </div>

        <div className="flex p-1 bg-black/40 rounded-2xl border border-white/5 text-xs font-bold">
          <button
            onClick={() => setActiveTab('faq')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              activeTab === 'faq' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            FAQ
          </button>
          <button
            onClick={() => setActiveTab('ticket')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              activeTab === 'ticket' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Submit Ticket
          </button>
          <button
            onClick={() => setActiveTab('my-tickets')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              activeTab === 'my-tickets' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            My Tickets ({userTickets.length})
          </button>
        </div>

        {activeTab === 'faq' && (
          <div className="space-y-2.5">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="glass-card rounded-2xl border border-white/5 overflow-hidden transition-all"
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                  className="w-full p-4 flex items-center justify-between text-left text-xs font-bold text-slate-100 hover:text-white"
                >
                  <span>{faq.q}</span>
                  {expandedFaq === idx ? (
                    <ChevronUp className="w-4 h-4 text-purple-400 flex-shrink-0 ml-2" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 flex-shrink-0 ml-2" />
                  )}
                </button>
                {expandedFaq === idx && (
                  <div className="px-4 pb-4 pt-1 text-xs text-slate-300 leading-relaxed border-t border-white/5">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {activeTab === 'ticket' && (
          <div className="glass-card rounded-3xl p-5 border border-purple-500/20">
            {statusMsg && (
              <div
                className={`mb-4 flex items-start space-x-2.5 rounded-xl p-3 text-xs ${
                  statusMsg.type === 'success'
                    ? 'bg-emerald-950/40 border border-emerald-500/30 text-emerald-300'
                    : 'bg-red-950/40 border border-red-500/30 text-red-300'
                }`}
              >
                {statusMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400 mt-0.5" />
                )}
                <span>{statusMsg.text}</span>
              </div>
            )}
            <form onSubmit={handleTicketSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="Withdrawal">Withdrawal & Payout</option>
                  <option value="KYC Verification">KYC Verification</option>
                  <option value="Rewards & Spin">Daily Tasks & Rewards</option>
                  <option value="Referral Bonus">Referral Program</option>
                  <option value="Other">Other Query</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Subject
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Summary of issue"
                  className="w-full px-3.5 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Description
                </label>
                <textarea
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Please provide complete details so our support team can assist you."
                  className="w-full px-3.5 py-2.5 bg-[#0d0c1c] border border-purple-900/40 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wide rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2 disabled:opacity-60"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>SUBMIT TICKET</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        {activeTab === 'my-tickets' && (
          <div className="space-y-3">
            {userTickets.length === 0 ? (
              <div className="text-center py-10 glass-card rounded-2xl border border-white/5 text-slate-500 text-xs">
                You have not submitted any support tickets yet.
              </div>
            ) : (
              userTickets.map((ticket) => (
                <div
                  key={ticket.id}
                  className="glass-card rounded-2xl p-4 border border-white/5 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 bg-purple-950/40 px-2 py-0.5 rounded-md border border-purple-500/20">
                      {ticket.category}
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        ticket.status === 'Resolved'
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/30'
                          : ticket.status === 'In Progress'
                          ? 'bg-blue-950/60 text-blue-400 border border-blue-500/30'
                          : 'bg-amber-950/60 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {ticket.status}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-white">{ticket.subject}</h4>
                  <p className="text-xs text-slate-300 leading-relaxed">{ticket.description}</p>
                  <div className="pt-1 text-[10px] text-slate-500 flex items-center justify-between">
                    <span>
                      Submitted on{' '}
                      {new Date(ticket.createdAt).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      })}
                    </span>
                    <span>Ticket #{ticket.id.substring(0, 6)}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
