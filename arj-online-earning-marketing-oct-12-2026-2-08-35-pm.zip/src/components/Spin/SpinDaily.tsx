import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  X,
  RotateCw,
  Trophy,
  Sparkles,
  AlertCircle,
  Coins,
  Volume2,
  VolumeX
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SpinResult, AppSettingsConfig } from '../../types';
import { recordSpinResult } from '../../services/firestoreService';
import { useAuth } from '../../context/AuthContext';

interface SpinDailyProps {
  isOpen: boolean;
  onClose: () => void;
  spinsRemaining: number;
  spinHistory: SpinResult[];
  appSettings: AppSettingsConfig;
  onSpinCompleted: () => void;
}

// Exactly 8 sectors with exact requested rewards: ₹1, ₹5, ₹8, ₹10, ₹12, ₹15, ₹17, ₹20
const EXACT_8_SPIN_REWARDS = [1, 5, 8, 10, 12, 15, 17, 20];

// 8 distinct, vibrant casino colors with maximum adjacent contrast
const SECTOR_COLORS = [
  '#2563eb', // Sector 0 (₹1): Royal Blue
  '#059669', // Sector 1 (₹5): Emerald Green
  '#9333ea', // Sector 2 (₹8): Vivid Purple
  '#ea580c', // Sector 3 (₹10): Rich Orange
  '#0284c7', // Sector 4 (₹12): Sky Azure
  '#e11d48', // Sector 5 (₹15): Ruby Red
  '#7c3aed', // Sector 6 (₹17): Electric Violet
  '#d97706'  // Sector 7 (₹20): Regal Gold (Jackpot)
];

export const SpinDaily: React.FC<SpinDailyProps> = ({
  isOpen,
  onClose,
  spinsRemaining,
  spinHistory,
  appSettings,
  onSpinCompleted
}) => {
  const { currentUser, wallet } = useAuth();
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [lastWon, setLastWon] = useState<number | null>(null);
  const [showWinModal, setShowWinModal] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [resetTimeLeft, setResetTimeLeft] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const segments = EXACT_8_SPIN_REWARDS;

  const playSound = (type: 'tick' | 'win') => {
    if (!soundEnabled) return;
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioCtx();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      if (type === 'tick') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.05);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.05);
      } else if (type === 'win') {
        const notes = [523.25, 659.25, 783.99, 1046.5];
        notes.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.1);
          gain.gain.setValueAtTime(0.25, ctx.currentTime + idx * 0.1);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.1 + 0.35);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(ctx.currentTime + idx * 0.1);
          osc.stop(ctx.currentTime + idx * 0.1 + 0.35);
        });
      }
    } catch {
      // Audio not supported
    }
  };

  // Sound ticking during spinning
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (spinning) {
      interval = setInterval(() => {
        playSound('tick');
      }, 125);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [spinning]);

  // Reset countdown to midnight IST
  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      const diff = tomorrow.getTime() - now.getTime();
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const mins = Math.floor((diff / 1000 / 60) % 60);
      const secs = Math.floor((diff / 1000) % 60);
      setResetTimeLeft(
        `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
      );
    };
    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  // Pre-calculate SVG sector geometries (8 equal sectors, 45 deg each)
  const sectorData = useMemo(() => {
    const cx = 200;
    const cy = 200;
    const r = 185;
    const num = 8;
    const angleStep = 360 / num;

    return segments.map((reward, i) => {
      const startDeg = i * angleStep;
      const endDeg = (i + 1) * angleStep;
      const midDeg = startDeg + angleStep / 2;

      const startRad = (startDeg * Math.PI) / 180;
      const endRad = (endDeg * Math.PI) / 180;

      const x1 = cx + r * Math.cos(startRad);
      const y1 = cy + r * Math.sin(startRad);
      const x2 = cx + r * Math.cos(endRad);
      const y2 = cy + r * Math.sin(endRad);

      // SVG path wedge from center (200, 200) to outer arc
      const pathD = `M ${cx} ${cy} L ${x1.toFixed(2)} ${y1.toFixed(2)} A ${r} ${r} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)} Z`;

      return {
        reward,
        index: i,
        color: SECTOR_COLORS[i % SECTOR_COLORS.length],
        pathD,
        midDeg,
        x1,
        y1,
        x2,
        y2
      };
    });
  }, [segments]);

  // 24 perimeter casino bulbs
  const perimeterBulbs = useMemo(() => {
    const cx = 200;
    const cy = 200;
    const bulbR = 191;
    const numBulbs = 24;
    const bulbs = [];

    for (let b = 0; b < numBulbs; b++) {
      const rad = (b * (360 / numBulbs) * Math.PI) / 180;
      const bx = cx + bulbR * Math.cos(rad);
      const by = cy + bulbR * Math.sin(rad);
      bulbs.push({
        x: bx.toFixed(2),
        y: by.toFixed(2),
        color: b % 2 === 0 ? '#ffffff' : '#facc15'
      });
    }
    return bulbs;
  }, []);

  if (!isOpen) return null;

  // Spin handling with mathematically exact sector alignment under top pointer
  const handleSpin = async () => {
    if (spinning || spinsRemaining <= 0 || !currentUser) return;
    setErrorMsg(null);
    setSpinning(true);
    setLastWon(null);
    setShowWinModal(false);

    // Pick winning index from the 8 segments
    const selectedIndex = Math.floor(Math.random() * segments.length);
    const wonReward = segments[selectedIndex];

    // Sector angle math:
    // Sector i has center at (i * 45 + 22.5) degrees in wheel space.
    // The yellow pointer is fixed at top (270 degrees in trigonometric space).
    // When wheel rotates clockwise by R degrees, sector center reaches (center + R) % 360.
    // For it to land exactly at 270 degrees: (center + R) % 360 == 270.
    const sectorCenter = selectedIndex * 45 + 22.5;
    const targetOffset = (((270 - sectorCenter) % 360) + 360) % 360;
    const currentNormalized = ((rotation % 360) + 360) % 360;

    let angleDiff = targetOffset - currentNormalized;
    if (angleDiff <= 0) {
      angleDiff += 360;
    }

    // 6 to 7 full spins for excitement
    const extraTurns = 360 * (6 + Math.floor(Math.random() * 2));
    const finalRotation = rotation + extraTurns + angleDiff;
    setRotation(finalRotation);

    setTimeout(async () => {
      setSpinning(false);
      setLastWon(wonReward);
      setShowWinModal(true);
      playSound('win');

      // Colorful Confetti Animation on Win
      try {
        confetti({
          particleCount: 130,
          spread: 85,
          origin: { y: 0.6 },
          colors: ['#facc15', '#ec4899', '#3b82f6', '#10b981', '#8b5cf6', '#ef4444', '#ffffff']
        });
      } catch {
        // Confetti optional
      }

      // Record in backend & Firestore
      const res = await recordSpinResult(currentUser.uid, wonReward);
      if (!res.success) {
        setErrorMsg(res.message);
      }
      onSpinCompleted();
    }, 4500);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07060e] text-white overflow-y-auto animate-fade-in">
      {/* Top Header */}
      <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-3.5 glass-panel border-b border-purple-900/30">
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-amber-500 flex items-center justify-center text-white shadow-md shadow-purple-600/30">
            <RotateCw className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white tracking-wide flex items-center">
              SPIN WHEEL <Sparkles className="w-3.5 h-3.5 text-amber-400 ml-1.5" />
            </h2>
            <p className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
              Win ₹1, ₹5, ₹8, ₹10, ₹12, ₹15, ₹17, ₹20
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
            title={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-amber-400" />
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
          </button>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="max-w-md mx-auto w-full px-4 py-5 flex-1 flex flex-col items-center">
        {/* Wallet Balance Bar at Top */}
        <div className="w-full flex items-center justify-between bg-black/50 border border-white/10 rounded-2xl p-3.5 mb-4 shadow-inner">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-300">
              <Coins className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
                Your Wallet Balance
              </span>
              <span className="text-xl font-black text-amber-300">
                ₹{(wallet?.availableBalance ?? 0).toFixed(2)}
              </span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-400 uppercase font-bold flex items-center justify-end space-x-1">
              <RotateCw className="w-3 h-3 text-emerald-400" />
              <span>Spins Left</span>
            </span>
            <span className="text-base font-black text-emerald-400 mt-0.5 block">
              {spinsRemaining} / {appSettings.dailySpinLimit || 10}
            </span>
          </div>
        </div>

        {errorMsg && (
          <div className="w-full mb-3 flex items-center space-x-2 bg-red-950/40 border border-red-500/30 p-3 rounded-xl text-xs text-red-300">
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* LARGE CIRCULAR 8-SECTOR SPIN WHEEL WITH FIXED YELLOW POINTER AT TOP */}
        <div className="relative my-4 flex items-center justify-center">
          {/* Fixed Yellow Pointer at Top (Points down at 12 o'clock sector) */}
          <div
            className="absolute -top-4 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center pointer-events-none drop-shadow-[0_4px_16px_rgba(250,204,21,0.95)]"
            aria-hidden="true"
          >
            {/* Top golden circular pin */}
            <div className="w-6 h-6 rounded-full bg-gradient-to-b from-yellow-300 via-amber-400 to-yellow-500 border-2 border-amber-600 shadow-md flex items-center justify-center">
              <div className="w-2.5 h-2.5 rounded-full bg-amber-900 border border-yellow-200" />
            </div>
            {/* Downward pointing yellow needle */}
            <div className="w-0 h-0 border-l-[14px] border-l-transparent border-r-[14px] border-r-transparent border-t-[26px] border-t-yellow-400 -mt-1 drop-shadow-md" />
          </div>

          {/* Golden Bordered Glowing Container for the Wheel */}
          <div className="relative p-1 rounded-full border-4 border-amber-400/80 shadow-[0_0_45px_rgba(234,179,8,0.4),0_0_90px_rgba(168,85,247,0.3)] ring-4 ring-amber-500/25 ring-offset-4 ring-offset-[#07060e]">
            {/* Smooth Rotating Wheel Element */}
            <div
              className="w-72 h-72 sm:w-80 sm:h-80 md:w-88 md:h-88 rounded-full relative flex items-center justify-center overflow-hidden"
              style={{
                transform: `rotate(${rotation}deg)`,
                transition: spinning ? 'transform 4.5s cubic-bezier(0.15, 0.9, 0.25, 1)' : 'none'
              }}
            >
              <svg
                viewBox="0 0 400 400"
                className="w-full h-full block rounded-full select-none"
              >
                <defs>
                  {/* Hub Golden Radial Gradient */}
                  <radialGradient id="goldHubGrad" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#fef08a" />
                    <stop offset="60%" stopColor="#eab308" />
                    <stop offset="100%" stopColor="#ca8a04" />
                  </radialGradient>
                  {/* Shadow filter for reward text */}
                  <filter id="svgTextShadow" x="-20%" y="-20%" width="140%" height="140%">
                    <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#000000" floodOpacity="0.95" />
                  </filter>
                </defs>

                {/* 1. All 8 Colorful Sectors filling from center to edge */}
                {sectorData.map((sector) => (
                  <path
                    key={sector.index}
                    d={sector.pathD}
                    fill={sector.color}
                    stroke="#facc15"
                    strokeWidth="2.5"
                    strokeLinejoin="round"
                  />
                ))}

                {/* 2. Clear Golden Sector Dividing Lines from Center */}
                {sectorData.map((sector) => (
                  <line
                    key={`line-${sector.index}`}
                    x1="200"
                    y1="200"
                    x2={sector.x1}
                    y2={sector.y1}
                    stroke="#facc15"
                    strokeWidth="2.5"
                  />
                ))}

                {/* 3. Reward Labels Inside Each of the 8 Sectors */}
                {sectorData.map((sector) => (
                  <g
                    key={`label-${sector.index}`}
                    transform={`rotate(${sector.midDeg} 200 200)`}
                  >
                    {/* Bold Reward Text (₹1, ₹5, ₹8, ₹10, ₹12, ₹15, ₹17, ₹20) */}
                    <text
                      x="346"
                      y="207"
                      fill="#ffffff"
                      fontSize="22"
                      fontWeight="900"
                      fontFamily="'Plus Jakarta Sans', system-ui, sans-serif"
                      textAnchor="end"
                      filter="url(#svgTextShadow)"
                    >
                      ₹{sector.reward}
                    </text>

                    {/* Badge Icon (Crown for ₹20 Jackpot, star for others) */}
                    {sector.reward === 20 ? (
                      <text
                        x="373"
                        y="206"
                        fontSize="13"
                        textAnchor="end"
                      >
                        👑
                      </text>
                    ) : (
                      <text
                        x="371"
                        y="205"
                        fontSize="11"
                        fill="#fef08a"
                        textAnchor="end"
                      >
                        ★
                      </text>
                    )}
                  </g>
                ))}

                {/* 4. Golden Rim Accent Ring */}
                <circle
                  cx="200"
                  cy="200"
                  r="185"
                  fill="none"
                  stroke="rgba(234, 179, 8, 0.45)"
                  strokeWidth="2"
                />

                {/* 5. Heavy Outer Casino Golden Rim */}
                <circle
                  cx="200"
                  cy="200"
                  r="191"
                  fill="none"
                  stroke="#eab308"
                  strokeWidth="9"
                />

                {/* 6. Outer Bright Gold Thin Highlight */}
                <circle
                  cx="200"
                  cy="200"
                  r="197"
                  fill="none"
                  stroke="#fde047"
                  strokeWidth="2.5"
                />

                {/* 7. 24 Glowing Casino Perimeter Bulbs */}
                {perimeterBulbs.map((bulb, bi) => (
                  <circle
                    key={`bulb-${bi}`}
                    cx={bulb.x}
                    cy={bulb.y}
                    r="3.2"
                    fill={bulb.color}
                  />
                ))}

                {/* 8. Center Golden Hub */}
                {/* Outer dark hub circle */}
                <circle
                  cx="200"
                  cy="200"
                  r="32"
                  fill="#0c0a1a"
                  stroke="#eab308"
                  strokeWidth="4"
                />
                {/* Inner gold metallic disc */}
                <circle
                  cx="200"
                  cy="200"
                  r="20"
                  fill="url(#goldHubGrad)"
                  stroke="#fde047"
                  strokeWidth="1.5"
                />
                {/* Center sparkling gem */}
                <circle
                  cx="200"
                  cy="200"
                  r="7"
                  fill="#ffffff"
                />
              </svg>
            </div>
          </div>
        </div>

        {/* Spin Button */}
        <button
          onClick={handleSpin}
          disabled={spinning || spinsRemaining <= 0}
          className="w-full mt-4 py-4 px-6 bg-gradient-to-r from-amber-500 via-purple-600 to-amber-500 hover:from-amber-400 hover:to-amber-400 text-white font-black text-base tracking-wider rounded-2xl shadow-xl shadow-purple-900/50 transition-all transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
        >
          {spinning ? (
            <>
              <RotateCw className="w-5 h-5 animate-spin text-amber-300" />
              <span>SPINNING WHEEL...</span>
            </>
          ) : spinsRemaining > 0 ? (
            <>
              <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
              <span>SPIN NOW ({spinsRemaining} LEFT)</span>
            </>
          ) : (
            <span>DAILY LIMIT REACHED (0 LEFT)</span>
          )}
        </button>

        {/* Today's Spin History */}
        <div className="w-full mt-5">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Today's Spin History
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">
              Reset in {resetTimeLeft}
            </span>
          </div>
          {spinHistory.length === 0 ? (
            <div className="text-center py-4 bg-black/25 rounded-2xl border border-white/5 text-slate-500 text-xs">
              No spins used today yet. Tap "SPIN NOW" to claim your first reward!
            </div>
          ) : (
            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
              {spinHistory.map((spin) => (
                <div
                  key={spin.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-black/35 border border-white/5 text-xs"
                >
                  <div className="flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="font-extrabold text-white">Won ₹{spin.rewardAmount}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-400 text-[11px]">
                    <span>
                      {new Date(spin.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                    <span className="text-emerald-400 font-bold uppercase text-[9px] bg-emerald-950/50 px-2 py-0.5 rounded-md border border-emerald-500/20">
                      CREDITED
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* WINNING AMOUNT POPUP MODAL */}
      {showWinModal && lastWon !== null && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-sm glass-card rounded-3xl p-6 border-2 border-amber-400 text-center space-y-4 shadow-2xl relative overflow-hidden animate-scale-up">
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-500 text-black flex items-center justify-center mx-auto shadow-lg shadow-amber-500/30 animate-bounce">
              <Trophy className="w-9 h-9" />
            </div>

            <div>
              <span className="text-xs font-black text-amber-300 uppercase tracking-widest block">
                CONGRATULATIONS!
              </span>
              <div className="flex items-baseline justify-center space-x-1 my-1">
                <span className="text-4xl sm:text-5xl font-black text-white">₹{lastWon}</span>
              </div>
              <p className="text-xs text-emerald-300 font-bold mt-1">
                Amount automatically credited to your wallet!
              </p>
              <div className="mt-3 p-2.5 bg-black/40 rounded-xl border border-white/10 text-xs flex items-center justify-between text-slate-300">
                <span>Updated Available Balance:</span>
                <span className="text-amber-300 font-black">
                  ₹{(wallet?.availableBalance ?? 0).toFixed(2)}
                </span>
              </div>
            </div>

            <button
              onClick={() => setShowWinModal(false)}
              className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-black text-sm uppercase rounded-xl shadow-lg transition-all"
            >
              COLLECT REWARD
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
