import React, { useState, useEffect } from 'react';
import { useAuth } from './context/AuthContext';
import { Splash } from './components/Splash';
import { Navbar } from './components/Navbar';
import { BottomNav, NavTab } from './components/BottomNav';
import { Login } from './components/Auth/Login';
import { Register } from './components/Auth/Register';
import { ForgotPasswordModal } from './components/Auth/ForgotPasswordModal';
import { HomeDashboard } from './components/Dashboard/HomeDashboard';
import { EarnPage } from './components/Earn/EarnPage';
import { SpinDaily } from './components/Spin/SpinDaily';
import { ScratchCards } from './components/Scratch/ScratchCards';
import { StoryViewer } from './components/Story/StoryViewer';
import { ReferAndEarn } from './components/Refer/ReferAndEarn';
import { WalletPage } from './components/Wallet/WalletPage';
import { WithdrawalPage } from './components/Withdraw/WithdrawalPage';
import { KycPage } from './components/KYC/KycPage';
import { ProfilePage } from './components/Profile/ProfilePage';
import { AccountSettingsModal } from './components/Profile/AccountSettingsModal';
import { NotificationCenter } from './components/Notifications/NotificationCenter';
import { HelpSupportModal } from './components/Support/HelpSupportModal';
import { TermsModal } from './components/Legal/TermsModal';
import { PrivacyModal } from './components/Legal/PrivacyModal';
import { LiveWithdrawalTicker } from './components/Notifications/LiveWithdrawalTicker';
import { AdminPanelModal } from './components/Admin/AdminPanelModal';
import {
  AppSettingsConfig,
  PaymentSettingsConfig,
  TaskItem,
  WalletTransaction,
  WithdrawalRequest,
  KycRecord,
  AppNotification,
  SupportTicket,
  SpinResult
} from './types';
import {
  DEFAULT_APP_SETTINGS,
  DEFAULT_PAYMENT_SETTINGS,
  subscribeAppSettings,
  subscribePaymentSettings,
  subscribeStories,
  subscribeUserTransactions,
  subscribeUserWithdrawals,
  subscribeUserKyc,
  subscribeNotifications,
  subscribeSupportTickets,
  getUserSpinsToday,
  getUserScratchStatus,
  getUserStoryClaimsToday,
  getReferralStats
} from './services/firestoreService';

export default function App() {
  const { currentUser, userProfile, wallet, isAdmin } = useAuth();

  // App-level state
  const [showSplash, setShowSplash] = useState(true);
  const [authView, setAuthView] = useState<'login' | 'register'>('login');
  const [activeTab, setActiveTab] = useState<NavTab>('home');

  // Modals & Full-screen views
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
  const [isSpinOpen, setIsSpinOpen] = useState(false);
  const [isScratchOpen, setIsScratchOpen] = useState(false);
  const [isStoryViewerOpen, setIsStoryViewerOpen] = useState(false);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [isKycOpen, setIsKycOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [pendingWithdrawal, setPendingWithdrawal] = useState<{ amount: number; upiId: string } | null>(null);
  const [isAccountSettingsOpen, setIsAccountSettingsOpen] = useState(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);

  // Real-time Firestore state
  const [appSettings, setAppSettings] = useState<AppSettingsConfig>(DEFAULT_APP_SETTINGS);
  const [paymentSettings, setPaymentSettings] = useState<PaymentSettingsConfig>(DEFAULT_PAYMENT_SETTINGS);
  const [stories, setStories] = useState<TaskItem[]>([]);
  const [claimedStoryIds, setClaimedStoryIds] = useState<string[]>([]);
  const [todaySpins, setTodaySpins] = useState<SpinResult[]>([]);
  const [scratchesRemaining, setScratchesRemaining] = useState(appSettings.dailyScratchLimit || 5);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [kycRecord, setKycRecord] = useState<KycRecord | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>([]);
  const [referralStats, setReferralStats] = useState({
    totalCount: 0,
    eligibleCount: 0,
    pendingCount: 0,
    earnings: 0
  });

  // Check URL params for referral code (e.g. ?ref=ARJ123)
  const [initialRefCode, setInitialRefCode] = useState('');

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    if (ref) {
      setInitialRefCode(ref);
      setAuthView('register');
    }
  }, []);

  // Subscribe to App Settings & Payment Settings & Stories
  useEffect(() => {
    const unsubApp = subscribeAppSettings(setAppSettings);
    const unsubPay = subscribePaymentSettings(setPaymentSettings);
    const unsubStories = subscribeStories(setStories);
    return () => {
      unsubApp();
      unsubPay();
      unsubStories();
    };
  }, []);

  // When user is authenticated, subscribe to user-specific Firestore streams
  useEffect(() => {
    if (!currentUser) return;

    const unsubTx = subscribeUserTransactions(currentUser.uid, setTransactions);
    const unsubWd = subscribeUserWithdrawals(currentUser.uid, setWithdrawals);
    const unsubKyc = subscribeUserKyc(currentUser.uid, setKycRecord);
    const unsubNotif = subscribeNotifications(currentUser.uid, setNotifications);
    const unsubTickets = subscribeSupportTickets(currentUser.uid, setSupportTickets);

    // Fetch today's spin history
    getUserSpinsToday(currentUser.uid).then(setTodaySpins);

    // Fetch today's scratch card status
    getUserScratchStatus(currentUser.uid).then((st) => {
      setScratchesRemaining(st.scratchesRemaining);
    });

    // Fetch today's story claims
    getUserStoryClaimsToday(currentUser.uid).then(setClaimedStoryIds);

    // Fetch referral stats with both UID and referralCode
    if (userProfile?.referralCode) {
      getReferralStats(currentUser.uid, userProfile.referralCode).then((s) => {
        setReferralStats({
          totalCount: s.totalCount,
          eligibleCount: s.eligibleCount,
          pendingCount: s.pendingCount,
          earnings: s.earnings
        });
      });
    }

    return () => {
      unsubTx();
      unsubWd();
      unsubKyc();
      unsubNotif();
      unsubTickets();
    };
  }, [currentUser, userProfile?.referralCode]);

  // Refresh daily tasks
  const refreshDailySpins = () => {
    if (currentUser) {
      getUserSpinsToday(currentUser.uid).then(setTodaySpins);
    }
  };

  const refreshScratchCards = () => {
    if (currentUser) {
      getUserScratchStatus(currentUser.uid).then((st) => {
        setScratchesRemaining(st.scratchesRemaining);
      });
    }
  };

  const refreshStoryClaims = () => {
    if (currentUser) {
      getUserStoryClaimsToday(currentUser.uid).then(setClaimedStoryIds);
      if (userProfile?.referralCode) {
        getReferralStats(currentUser.uid, userProfile.referralCode).then((s) => {
          setReferralStats({
            totalCount: s.totalCount,
            eligibleCount: s.eligibleCount,
            pendingCount: s.pendingCount,
            earnings: s.earnings
          });
        });
      }
    }
  };

  // Calculations
  const dailySpinLimit = appSettings.dailySpinLimit || 10;
  const spinsRemaining = Math.max(0, dailySpinLimit - todaySpins.length);
  const storiesRemaining = Math.max(0, stories.length - claimedStoryIds.length);

  // Today's total earnings
  const todayEarnings =
    typeof wallet?.todayEarnings === 'number' && wallet.todayEarnings > 0
      ? wallet.todayEarnings
      : todaySpins.reduce((sum, s) => sum + (s.rewardAmount || 0), 0) +
        claimedStoryIds.length * 10;

  // Unread notifications count
  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleWithdrawClick = () => {
    setIsWithdrawOpen(true);
  };

  // 1. Splash Screen
  if (showSplash) {
    return (
      <Splash
        isLoggedIn={!!currentUser}
        onFinish={() => setShowSplash(false)}
      />
    );
  }

  // 2. Auth Screens
  if (!currentUser) {
    if (authView === 'login') {
      return (
        <>
          <Login
            onSwitchToRegister={() => setAuthView('register')}
            onOpenForgotPassword={() => setIsForgotPasswordOpen(true)}
          />
          <ForgotPasswordModal
            isOpen={isForgotPasswordOpen}
            onClose={() => setIsForgotPasswordOpen(false)}
          />
        </>
      );
    } else {
      return (
        <>
          <Register
            initialReferralCode={initialRefCode}
            onSwitchToLogin={() => setAuthView('login')}
            onOpenTerms={() => setIsTermsOpen(true)}
            onOpenPrivacy={() => setIsPrivacyOpen(true)}
          />
          <TermsModal isOpen={isTermsOpen} onClose={() => setIsTermsOpen(false)} />
          <PrivacyModal isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
        </>
      );
    }
  }

  // 3. Authenticated App Layout
  return (
    <div className="min-h-screen bg-[#06060c] text-slate-100 flex flex-col justify-between selection:bg-purple-600 selection:text-white pb-20">
      {/* Top Navbar */}
      <Navbar
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenProfile={() => setActiveTab('profile')}
        onOpenAdmin={() => setIsAdminOpen(true)}
        unreadCount={unreadCount}
      />

      {/* LIVE WITHDRAWAL NOTIFICATION (Upper side / Top ticker) */}
      <LiveWithdrawalTicker
        appSettings={appSettings}
        onOpenWithdraw={handleWithdrawClick}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-lg mx-auto w-full px-4 pt-3 sm:px-6">
        {activeTab === 'home' && (
          <HomeDashboard
            onOpenSpin={() => setIsSpinOpen(true)}
            onOpenScratch={() => setIsScratchOpen(true)}
            onOpenStories={() => setIsStoryViewerOpen(true)}
            onOpenRefer={() => setActiveTab('refer')}
            onOpenWallet={() => setActiveTab('wallet')}
            onOpenWithdraw={handleWithdrawClick}
            onOpenKyc={() => setIsKycOpen(true)}
            appSettings={appSettings}
            paymentSettings={paymentSettings}
            spinsRemaining={spinsRemaining}
            scratchesRemaining={scratchesRemaining}
            storiesRemaining={storiesRemaining}
            todayEarnings={todayEarnings}
            referralCount={referralStats.totalCount}
            referralPendingCount={referralStats.pendingCount}
            referralEarnings={referralStats.earnings}
          />
        )}

        {activeTab === 'earn' && (
          <EarnPage
            onOpenSpin={() => setIsSpinOpen(true)}
            onOpenScratch={() => setIsScratchOpen(true)}
            onOpenStories={() => setIsStoryViewerOpen(true)}
            spinsRemaining={spinsRemaining}
            scratchesRemaining={scratchesRemaining}
            storiesRemaining={storiesRemaining}
            totalStoriesCount={stories.length}
            appSettings={appSettings}
            todayEarnings={todayEarnings}
          />
        )}

        {activeTab === 'wallet' && (
          <WalletPage
            onOpenWithdraw={handleWithdrawClick}
            transactions={transactions}
          />
        )}

        {activeTab === 'refer' && (
          <ReferAndEarn
            appSettings={appSettings}
            referralCount={referralStats.totalCount}
            referralEarnings={referralStats.earnings}
          />
        )}

        {activeTab === 'profile' && (
          <ProfilePage
            onOpenSettings={() => setIsAccountSettingsOpen(true)}
            onOpenNotifications={() => setIsNotificationsOpen(true)}
            onOpenChangePassword={() => setIsChangePasswordOpen(true)}
            onOpenTerms={() => setIsTermsOpen(true)}
            onOpenPrivacy={() => setIsPrivacyOpen(true)}
            onOpenSupport={() => setIsSupportOpen(true)}
            onOpenKyc={() => setIsKycOpen(true)}
            onOpenAdmin={() => setIsAdminOpen(true)}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation */}
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Modals & Dialogs */}
      <SpinDaily
        isOpen={isSpinOpen}
        onClose={() => setIsSpinOpen(false)}
        spinsRemaining={spinsRemaining}
        spinHistory={todaySpins}
        appSettings={appSettings}
        onSpinCompleted={refreshDailySpins}
      />

      <ScratchCards
        isOpen={isScratchOpen}
        onClose={() => setIsScratchOpen(false)}
        appSettings={appSettings}
        onRewardClaimed={refreshScratchCards}
      />

      <StoryViewer
        isOpen={isStoryViewerOpen}
        onClose={() => setIsStoryViewerOpen(false)}
        stories={stories}
        claimedStoryIds={claimedStoryIds}
        onRewardClaimed={refreshStoryClaims}
      />

      <WithdrawalPage
        isOpen={isWithdrawOpen}
        onClose={() => setIsWithdrawOpen(false)}
        appSettings={appSettings}
        paymentSettings={paymentSettings}
        withdrawals={withdrawals}
        onRequireKyc={(amount, upiId) => {
          setPendingWithdrawal({ amount, upiId });
          setIsWithdrawOpen(false);
          setIsKycOpen(true);
        }}
      />

      <KycPage
        isOpen={isKycOpen}
        onClose={() => setIsKycOpen(false)}
        kycRecord={kycRecord}
        pendingWithdrawalAmount={pendingWithdrawal?.amount}
        pendingUpiId={pendingWithdrawal?.upiId}
        onKycSubmitted={() => {}}
      />

      {/* Administrator Control Panel */}
      <AdminPanelModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        appSettings={appSettings}
        onSettingsUpdated={() => {
          // Trigger settings refresh
        }}
      />

      <AccountSettingsModal
        isOpen={isAccountSettingsOpen}
        onClose={() => setIsAccountSettingsOpen(false)}
      />

      <AccountSettingsModal
        isOpen={isChangePasswordOpen}
        onClose={() => setIsChangePasswordOpen(false)}
        isPasswordOnly={true}
      />

      <NotificationCenter
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
      />

      <HelpSupportModal
        isOpen={isSupportOpen}
        onClose={() => setIsSupportOpen(false)}
        appSettings={appSettings}
        userTickets={supportTickets}
        onTicketSubmitted={() => {}}
      />

      <TermsModal isOpen={isTermsOpen} onClose={() => setIsTermsOpen(false)} />
      <PrivacyModal isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
    </div>
  );
}
