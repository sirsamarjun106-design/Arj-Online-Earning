import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updatePassword as fbUpdatePassword
} from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, onSnapshot, getDoc, updateDoc, setDoc } from 'firebase/firestore';
import { UserProfile, UserWallet } from '../types';
import { initializeNewUser, subscribeUserWallet, ADMIN_EMAILS } from '../services/firestoreService';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  wallet: UserWallet | null;
  isAdmin: boolean;
  loading: boolean;
  login: (emailOrPhone: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  register: (data: {
    name: string;
    email: string;
    phone: string;
    password: string;
    referralCode?: string;
  }) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string }>;
  changePassword: (newPass: string) => Promise<{ success: boolean; error?: string }>;
  updateProfileDetails: (details: { name?: string; phone?: string }) => Promise<{ success: boolean; error?: string }>;
  refreshData: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [wallet, setWallet] = useState<UserWallet | null>(null);
  const [loading, setLoading] = useState(true);

  // Subscribe to Firebase Auth state
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        const isEmailAdmin = Boolean(
          user.email && ADMIN_EMAILS.includes(user.email.toLowerCase().trim())
        );

        // 1. Immediately create fallback user profile so user dashboard opens without lag
        const emailPrefix = user.email ? user.email.split('@')[0] : '';
        const fallbackName =
          user.displayName?.trim() ||
          (emailPrefix ? emailPrefix.charAt(0).toUpperCase() + emailPrefix.slice(1) : 'Member');

        let cachedProfile: UserProfile | null = null;
        try {
          const raw = localStorage.getItem(`arj_profile_${user.uid}`);
          if (raw) cachedProfile = JSON.parse(raw);
        } catch (_) {}

        const initialProfile: UserProfile = cachedProfile || {
          uid: user.uid,
          name: fallbackName,
          email: user.email || '',
          phone: user.phoneNumber || '',
          referralCode: 'ARJ' + user.uid.substring(0, 5).toUpperCase(),
          createdAt: Date.now(),
          kycStatus: 'unverified',
          accountStatus: 'active',
          role: isEmailAdmin ? 'admin' : 'user',
          isVerified: isEmailAdmin,
          verified: isEmailAdmin
        };

        setUserProfile(initialProfile);
        setLoading(false);

        // 2. Subscribe to user doc in Firestore (with clean error resilience)
        const userDocRef = doc(db, 'users', user.uid);
        let unsubscribeProfile = () => {};

        try {
          unsubscribeProfile = onSnapshot(
            userDocRef,
            (snap) => {
              if (snap.exists()) {
                const data = snap.data() as UserProfile;
                const updated: UserProfile = {
                  ...data,
                  role: isEmailAdmin ? 'admin' : (data.role || 'user')
                };
                setUserProfile(updated);
                try {
                  localStorage.setItem(`arj_profile_${user.uid}`, JSON.stringify(updated));
                } catch (_) {}
              } else {
                // If doc doesn't exist yet, attempt to persist to Firestore
                setDoc(userDocRef, initialProfile, { merge: true }).catch(() => {});
              }
            },
            (err) => {
              // Non-blocking notice if Firestore database is offline or not yet initialized
              console.warn('Firestore user profile sync warning (operating in resilient mode):', err.message);
            }
          );
        } catch (_) {}

        // 3. Subscribe to wallet (combines authoritative backend API and Firestore)
        const unsubscribeWallet = subscribeUserWallet(user.uid, (w) => {
          setWallet(w);
        });

        return () => {
          unsubscribeProfile();
          unsubscribeWallet();
        };
      } else {
        setCurrentUser(null);
        setUserProfile(null);
        setWallet(null);
        setLoading(false);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Format Firebase Auth errors into clear, actionable user messages
  const formatAuthError = (err: unknown): string => {
    if (!err || typeof err !== 'object') return 'An unexpected authentication error occurred.';
    const code = (err as { code?: string }).code || '';
    const rawMessage = (err as Error).message || '';

    switch (code) {
      case 'auth/operation-not-allowed':
        return 'Email/Password sign-in provider is disabled in Firebase Console. Please go to Firebase Console > Authentication > Sign-in method and enable Email/Password.';
      case 'auth/invalid-credential':
      case 'auth/wrong-password':
        return 'Invalid email or password. Please verify your credentials and try again.';
      case 'auth/user-not-found':
        return 'No account found with this email or mobile number. Please register first.';
      case 'auth/email-already-in-use':
        return 'An account with this email address already exists. Please log in instead.';
      case 'auth/weak-password':
        return 'Password must be at least 6 characters long.';
      case 'auth/invalid-email':
        return 'Please enter a valid email address (e.g. name@example.com).';
      case 'auth/user-disabled':
        return 'This account has been suspended by administration. Please contact support.';
      case 'auth/too-many-requests':
        return 'Too many failed login attempts. Access has been temporarily locked for security. Please try again later or reset your password.';
      case 'auth/network-request-failed':
        return 'Network connection error. Please verify your internet connection and try again.';
      case 'auth/popup-closed-by-user':
        return 'The authentication popup was closed before completing the sign-in.';
      case 'auth/internal-error':
        return 'An internal authentication error occurred. Please try again.';
      default:
        if (rawMessage.includes('operation-not-allowed')) {
          return 'Email/Password sign-in provider is disabled in Firebase Console. Please go to Firebase Console > Authentication > Sign-in method and enable Email/Password.';
        }
        return rawMessage || 'Authentication failed. Please verify your details.';
    }
  };

  // Login handler using signInWithEmailAndPassword SDK method
  const login = async (emailOrPhone: string, pass: string) => {
    try {
      let email = emailOrPhone.trim();
      if (!email.includes('@')) {
        // Formatted mobile identifier for phone logins
        email = `${email.replace(/[^0-9]/g, '')}@arjmarketing.app`;
      }

      const cred = await signInWithEmailAndPassword(auth, email, pass);

      // Verify accountStatus
      try {
        const profileSnap = await getDoc(doc(db, 'users', cred.user.uid));
        if (profileSnap.exists()) {
          const prof = profileSnap.data() as UserProfile;
          if (prof.accountStatus === 'blocked') {
            await signOut(auth);
            return {
              success: false,
              error: 'Your account has been suspended by administration. Contact support.'
            };
          }
        }
      } catch (_) {}

      return { success: true };
    } catch (err) {
      return { success: false, error: formatAuthError(err) };
    }
  };

  // Register handler using createUserWithEmailAndPassword SDK method
  const register = async (data: {
    name: string;
    email: string;
    phone: string;
    password: string;
    referralCode?: string;
  }) => {
    try {
      let email = data.email.trim();
      if (!email.includes('@')) {
        email = `${data.phone.replace(/[^0-9]/g, '')}@arjmarketing.app`;
      }

      // Create user in Firebase Authentication
      const cred = await createUserWithEmailAndPassword(auth, email, data.password);

      const randomSuffix = Math.random().toString(36).substring(2, 7).toUpperCase();
      const uniqueReferralCode = `ARJ${randomSuffix}`;
      const isEmailAdmin = ADMIN_EMAILS.includes(data.email.toLowerCase().trim());

      const initialProfile: UserProfile = {
        uid: cred.user.uid,
        name: data.name.trim(),
        email: data.email.trim(),
        phone: data.phone.trim(),
        referralCode: uniqueReferralCode,
        referredBy: data.referralCode?.trim() || null,
        createdAt: Date.now(),
        kycStatus: 'unverified',
        accountStatus: 'active',
        role: isEmailAdmin ? 'admin' : 'user',
        feePaid: false,
        tasksCompletedCount: 0
      };

      // Save to localStorage for instant UI rendering
      try {
        localStorage.setItem(`arj_profile_${cred.user.uid}`, JSON.stringify(initialProfile));
      } catch (_) {}

      setUserProfile(initialProfile);

      // Async initialize database records & wallet in background
      initializeNewUser(cred.user.uid, {
        name: data.name.trim(),
        email: data.email.trim(),
        phone: data.phone.trim(),
        referralCode: uniqueReferralCode,
        referredBy: data.referralCode?.trim() || null
      })
        .then(({ wallet: newWallet }) => {
          setWallet(newWallet);
        })
        .catch((e) => {
          console.warn('initializeNewUser notice:', e);
        });

      return { success: true };
    } catch (err) {
      return { success: false, error: formatAuthError(err) };
    }
  };

  const logout = async () => {
    await signOut(auth);
    setCurrentUser(null);
    setUserProfile(null);
    setWallet(null);
  };

  const resetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email.trim());
      return { success: true };
    } catch (err) {
      return { success: false, error: formatAuthError(err) };
    }
  };

  const changePassword = async (newPass: string) => {
    if (!auth.currentUser) return { success: false, error: 'Not authenticated' };
    try {
      await fbUpdatePassword(auth.currentUser, newPass);
      return { success: true };
    } catch (err) {
      return { success: false, error: formatAuthError(err) };
    }
  };

  const updateProfileDetails = async (details: { name?: string; phone?: string }) => {
    if (!currentUser) return { success: false, error: 'Not authenticated' };
    try {
      await updateDoc(doc(db, 'users', currentUser.uid), {
        ...details,
        updatedAt: Date.now()
      });
      setUserProfile((prev) => (prev ? { ...prev, ...details } : null));
      return { success: true };
    } catch (err) {
      return { success: false, error: formatAuthError(err) };
    }
  };

  const refreshData = async () => {
    if (currentUser) {
      try {
        const snap = await getDoc(doc(db, 'users', currentUser.uid));
        if (snap.exists()) {
          setUserProfile(snap.data() as UserProfile);
        }
        const wSnap = await getDoc(doc(db, 'wallets', currentUser.uid));
        if (wSnap.exists()) {
          setWallet(wSnap.data() as UserWallet);
        }
      } catch (_) {}
    }
  };

  const isAdmin = Boolean(
    userProfile?.role === 'admin' ||
      (currentUser?.email && ADMIN_EMAILS.includes(currentUser.email.toLowerCase().trim()))
  );

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        wallet,
        isAdmin,
        loading,
        login,
        register,
        logout,
        resetPassword,
        changePassword,
        updateProfileDetails,
        refreshData
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
